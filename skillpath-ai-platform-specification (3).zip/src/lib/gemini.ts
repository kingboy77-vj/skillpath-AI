import { db } from "@/db";
import { systemSettings } from "@/db/schema";
import { eq } from "drizzle-orm";

export interface GeminiCallOptions {
  systemPrompt?: string;
  userPrompt: string;
  temperature?: number;
  jsonMode?: boolean;
}

export async function getApiKey(): Promise<{ apiKey: string | null; model: string; isDemoMode: boolean }> {
  try {
    const settings = await db.select().from(systemSettings).where(eq(systemSettings.id, "system_default"));
    const dbKey = settings[0]?.geminiApiKey;
    const dbModel = settings[0]?.preferredModel || "gemini-1.5-flash";
    const forceDemo = settings[0]?.demoModeOverride || false;

    const apiKey = dbKey || process.env.GEMINI_API_KEY || null;

    if (forceDemo || !apiKey) {
      return { apiKey: null, model: dbModel, isDemoMode: true };
    }

    return { apiKey, model: dbModel, isDemoMode: false };
  } catch (e) {
    console.error("Error fetching system settings:", e);
    return { apiKey: process.env.GEMINI_API_KEY || null, model: "gemini-1.5-flash", isDemoMode: !process.env.GEMINI_API_KEY };
  }
}

export async function callGemini(options: GeminiCallOptions): Promise<{ text: string; isDemo: boolean }> {
  const { apiKey, model, isDemoMode } = await getApiKey();

  if (isDemoMode || !apiKey) {
    return { text: "", isDemo: true };
  }

  const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${apiKey}`;

  const contents: any[] = [];
  if (options.systemPrompt) {
    contents.push({
      role: "user",
      parts: [{ text: `System Instruction: ${options.systemPrompt}` }],
    });
    contents.push({
      role: "model",
      parts: [{ text: "Understood. I will follow your instructions precisely." }],
    });
  }

  contents.push({
    role: "user",
    parts: [{ text: options.userPrompt }],
  });

  try {
    const response = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        contents,
        generationConfig: {
          temperature: options.temperature ?? 0.3,
          maxOutputTokens: 2048,
          responseMimeType: options.jsonMode ? "application/json" : "text/plain",
        },
      }),
    });

    if (!response.ok) {
      const errText = await response.text();
      console.warn("Gemini API call failed with status", response.status, errText);
      return { text: "", isDemo: true };
    }

    const data = await response.json();
    const candidateText = data?.candidates?.[0]?.content?.parts?.[0]?.text || "";
    return { text: candidateText, isDemo: false };
  } catch (error) {
    console.error("Error executing Gemini API fetch:", error);
    return { text: "", isDemo: true };
  }
}
