import { callGemini } from "../gemini";

export interface RoadmapTaskItem {
  id?: string;
  phaseNumber: number;
  phaseTitle: string;
  phaseDescription: string;
  title: string;
  skillsToLearn: string[];
  topics: string[];
  practicalTasks: string[];
  resourceTitle?: string;
  resourceUrl?: string;
  assessmentTitle?: string;
  completed?: boolean;
}

export interface RoadmapAgentInput {
  targetCareer: string;
  missingSkills: string[];
  currentSkills: string[];
  learningStyle?: string;
  weeksAvailable?: number;
}

export interface RoadmapAgentOutput {
  careerTitle: string;
  totalPhases: number;
  estimatedWeeks: number;
  phases: {
    phaseNumber: number;
    phaseTitle: string;
    phaseDescription: string;
    tasks: RoadmapTaskItem[];
  }[];
  source: "gemini" | "deterministic-engine";
}

export async function runRoadmapAgent(input: RoadmapAgentInput): Promise<RoadmapAgentOutput> {
  const prompt = `You are the LEARNING ROADMAP AGENT for King Skill AI.
Target Career: "${input.targetCareer}"
Current Skills: ${JSON.stringify(input.currentSkills)}
Missing/Target Skills: ${JSON.stringify(input.missingSkills)}
Learning Style: "${input.learningStyle || "Hands-on Projects"}"

Generate a personalized 5-phase learning roadmap:
Phase 1: Beginner fundamentals
Phase 2: Intermediate concepts
Phase 3: Advanced skills
Phase 4: Practical projects
Phase 5: Career preparation

Each phase must contain 1-2 structured tasks with:
- title
- skillsToLearn (string array)
- topics (string array)
- practicalTasks (string array)
- resourceTitle (string)
- resourceUrl (valid URL string)
- assessmentTitle (string or null)

Return strictly valid JSON with this exact schema:
{
  "estimatedWeeks": number,
  "phases": [
    {
      "phaseNumber": 1,
      "phaseTitle": "Phase 1: Beginner Fundamentals",
      "phaseDescription": "string",
      "tasks": [
        {
          "title": "string",
          "skillsToLearn": ["string"],
          "topics": ["string", "string"],
          "practicalTasks": ["string"],
          "resourceTitle": "string",
          "resourceUrl": "string",
          "assessmentTitle": "string"
        }
      ]
    }
  ]
}`;

  const aiResult = await callGemini({
    systemPrompt: "You are an engineering curriculum architect. Output only raw JSON.",
    userPrompt: prompt,
    jsonMode: true,
  });

  if (!aiResult.isDemo && aiResult.text) {
    try {
      const parsed = JSON.parse(aiResult.text);
      if (Array.isArray(parsed.phases) && parsed.phases.length >= 4) {
        return {
          careerTitle: input.targetCareer,
          totalPhases: 5,
          estimatedWeeks: parsed.estimatedWeeks || 14,
          phases: parsed.phases,
          source: "gemini",
        };
      }
    } catch (e) {
      console.warn("Failed to parse Gemini roadmap response:", e);
    }
  }

  // Deterministic 5-phase roadmap customized to career
  const deterministicPhases = [
    {
      phaseNumber: 1,
      phaseTitle: "Phase 1: Beginner Fundamentals",
      phaseDescription: `Master essential syntax, toolchains, and environment setups required for ${input.targetCareer}.`,
      tasks: [
        {
          phaseNumber: 1,
          phaseTitle: "Phase 1: Beginner Fundamentals",
          phaseDescription: "Semantic HTML5, CSS layout systems and version control",
          title: "Master Semantic HTML5 & Responsive CSS Layouts",
          skillsToLearn: ["HTML", "CSS"],
          topics: ["HTML5 semantic tags", "CSS Box Model", "Flexbox alignment", "CSS Grid template areas"],
          practicalTasks: ["Build a multi-page responsive personal portfolio", "Implement fluid responsive navigation drawer"],
          resourceTitle: "Responsive Web Layouts: Flexbox, CSS Grid & Tailwind Mastery",
          resourceUrl: "https://web.dev/learn/css",
          completed: true,
        },
        {
          phaseNumber: 1,
          phaseTitle: "Phase 1: Beginner Fundamentals",
          phaseDescription: "Git and repository collaboration workflows",
          title: "Git Essentials & Collaborative Version Control",
          skillsToLearn: ["Git"],
          topics: ["Git init, stage, commit", "Feature branches", "Merge vs Rebase", "Pull request reviews"],
          practicalTasks: ["Initialize GitHub repo with README and branch protection", "Resolve a simulated merge conflict"],
          resourceTitle: "Git & Collaborative GitHub Workflows for Engineers",
          resourceUrl: "https://git-scm.com/book/en/v2",
          completed: true,
        },
      ],
    },
    {
      phaseNumber: 2,
      phaseTitle: "Phase 2: Intermediate Concepts",
      phaseDescription: "Deep dive into language mechanics, asynchronous execution, and server-side runtime APIs.",
      tasks: [
        {
          phaseNumber: 2,
          phaseTitle: "Phase 2: Intermediate Concepts",
          phaseDescription: "Core JavaScript mechanics & async programming",
          title: "JavaScript Deep Dive: Async/Await, Closures & Event Loop",
          skillsToLearn: ["JavaScript"],
          topics: ["Scope chain and closures", "Prototypes and this keyword", "Promises and async/await", "Array methods"],
          practicalTasks: ["Build an interactive weather dashboard consuming open weather API", "Write custom polyfill for Array reduce"],
          resourceTitle: "Modern JavaScript Deep Dive: From Fundamentals to ESNext",
          resourceUrl: "https://javascript.info",
          assessmentTitle: "JavaScript Core & Asynchronous Mechanics",
          completed: false,
        },
        {
          phaseNumber: 2,
          phaseTitle: "Phase 2: Intermediate Concepts",
          phaseDescription: "Backend runtime & RESTful architectural styles",
          title: "Node.js & Express Architecture Fundamentals",
          skillsToLearn: ["Node.js", "Express.js", "REST APIs"],
          topics: ["Node.js event loop & libuv", "Express middleware stack", "Request parsing & CORS", "HTTP status codes"],
          practicalTasks: ["Create a REST API with CRUD operations and error handling middleware", "Write unit tests for endpoints"],
          resourceTitle: "Building Production-Ready REST APIs with Node.js & Express",
          resourceUrl: "https://nodejs.org/en/learn",
          assessmentTitle: "Node.js & RESTful API Engineering",
          completed: false,
        },
      ],
    },
    {
      phaseNumber: 3,
      phaseTitle: "Phase 3: Advanced Skills",
      phaseDescription: "Component lifecycle, state management, relational database indexing, and ORM pipelines.",
      tasks: [
        {
          phaseNumber: 3,
          phaseTitle: "Phase 3: Advanced Skills",
          phaseDescription: "Declarative UI engineering with React 19",
          title: "React Component Lifecycle, Custom Hooks & Global State",
          skillsToLearn: ["React", "JavaScript"],
          topics: ["Component composition", "useState and useReducer state machines", "useEffect lifecycle", "Context API"],
          practicalTasks: ["Build an interactive Kanban board with drag-and-drop state", "Create custom hook for debounced search"],
          resourceTitle: "Interactive React 19: Full Architecture & Hooks",
          resourceUrl: "https://react.dev/learn",
          assessmentTitle: "React Component Architecture & Hooks",
          completed: false,
        },
        {
          phaseNumber: 3,
          phaseTitle: "Phase 3: Advanced Skills",
          phaseDescription: "Relational database modeling and ORM integration",
          title: "PostgreSQL Database Design & Drizzle/Prisma ORM Integration",
          skillsToLearn: ["SQL", "Node.js", "REST APIs"],
          topics: ["Relational schema normalization", "ACID transactions & foreign keys", "B-Tree indexes", "ORM migrations"],
          practicalTasks: ["Design relational schema for e-commerce catalog with orders", "Write performant multi-table JOINs"],
          resourceTitle: "Advanced PostgreSQL: Indexing, Transactions & Query Tuning",
          resourceUrl: "https://www.postgresql.org/docs/current/tutorial.html",
          completed: false,
        },
      ],
    },
    {
      phaseNumber: 4,
      phaseTitle: "Phase 4: Practical Projects",
      phaseDescription: "Synthesize full stack frontend and backend into an enterprise-ready capstone application.",
      tasks: [
        {
          phaseNumber: 4,
          phaseTitle: "Phase 4: Practical Projects",
          phaseDescription: "End-to-end full stack web application",
          title: "End-to-End SaaS Web App: E-Commerce / LMS Platform",
          skillsToLearn: ["React", "Node.js", "Express.js", "SQL", "REST APIs", "Git"],
          topics: ["JWT authentication and session cookies", "Role-based access control", "Stripe payment integration", "File storage"],
          practicalTasks: ["Build complete e-commerce store with catalog, auth, cart, and admin dashboard", "Implement integration tests"],
          resourceTitle: "Full Stack Mini-Project: E-Commerce Store with Cart & Auth",
          resourceUrl: "https://github.com/topics/fullstack-ecommerce",
          completed: false,
        },
      ],
    },
    {
      phaseNumber: 5,
      phaseTitle: "Phase 5: Career Preparation",
      phaseDescription: "Production deployments, CI/CD pipelines, system design interviews, and resume refinement.",
      tasks: [
        {
          phaseNumber: 5,
          phaseTitle: "Phase 5: Career Preparation",
          phaseDescription: "DevOps, deployment, and live technical interviews",
          title: "Portfolio Deployment, System Design & Technical Interviews",
          skillsToLearn: ["Git", "REST APIs", "Docker"],
          topics: ["CI/CD pipelines with GitHub Actions", "Cloud container deployments", "System design fundamentals", "Mock technical interviews"],
          practicalTasks: ["Deploy 2 production applications with live custom domains", "Complete 5 mock technical interview coding sessions"],
          completed: false,
        },
      ],
    },
  ];

  return {
    careerTitle: input.targetCareer,
    totalPhases: 5,
    estimatedWeeks: 12,
    phases: deterministicPhases,
    source: "deterministic-engine",
  };
}
