import { callGemini } from "../gemini";

export interface SkillAnalysisInput {
  userSkills: { name: string; proficiency: string; score: number }[];
  targetCareer: string;
  requiredSkills: { name: string; requiredProficiency: string; importance: string }[];
  education?: string;
  projects?: { title: string; tech: string[] }[];
}

export interface SkillAnalysisOutput {
  existingSkills: { name: string; proficiency: string; score: number }[];
  strengths: string[];
  weaknesses: string[];
  missingSkills: string[];
  skillGapPercentage: number;
  overallProficiencySummary: string;
  source: "gemini" | "deterministic-engine";
}

export async function runSkillAnalysisAgent(input: SkillAnalysisInput): Promise<SkillAnalysisOutput> {
  const existingSkillNames = input.userSkills.map((s) => s.name.toLowerCase());
  const requiredSkillNames = input.requiredSkills.map((r) => r.name);

  const missingList = input.requiredSkills
    .filter((req) => !existingSkillNames.includes(req.name.toLowerCase()))
    .map((r) => r.name);

  const totalRequired = Math.max(input.requiredSkills.length, 1);
  const gapPercentage = Math.round((missingList.length / totalRequired) * 100);

  // Try Gemini AI first
  const prompt = `You are the SKILL ANALYSIS AGENT for King Skill AI.
Analyze the following student profile for their target career: "${input.targetCareer}".
Existing Skills: ${JSON.stringify(input.userSkills)}
Required Skills: ${JSON.stringify(input.requiredSkills)}
Education: ${input.education || "Computer Science"}
Projects: ${JSON.stringify(input.projects || [])}

Analyze their strengths, weaknesses, missing skills, and calculate the skill gap percentage.
Return strictly valid JSON with this exact schema:
{
  "strengths": ["string", "string"],
  "weaknesses": ["string", "string"],
  "missingSkills": ["string"],
  "skillGapPercentage": number,
  "overallProficiencySummary": "string"
}`;

  const aiResult = await callGemini({
    systemPrompt: "You are an expert technical evaluator. Output only raw JSON.",
    userPrompt: prompt,
    jsonMode: true,
  });

  if (!aiResult.isDemo && aiResult.text) {
    try {
      const parsed = JSON.parse(aiResult.text);
      return {
        existingSkills: input.userSkills,
        strengths: parsed.strengths || ["Procedural coding logic", "Relational database fundamentals"],
        weaknesses: parsed.weaknesses || ["Frontend component reactivity", "Modern API async patterns"],
        missingSkills: parsed.missingSkills || missingList,
        skillGapPercentage: typeof parsed.skillGapPercentage === "number" ? parsed.skillGapPercentage : gapPercentage,
        overallProficiencySummary: parsed.overallProficiencySummary || `Learner possesses core foundations in ${input.userSkills.map(s => s.name).join(", ")}, with significant opportunities in target framework stacks.`,
        source: "gemini",
      };
    } catch (e) {
      console.warn("Failed to parse Gemini skill analysis response, falling back to deterministic engine:", e);
    }
  }

  // Deterministic fallback engine
  const strengths: string[] = [];
  const weaknesses: string[] = [];

  input.userSkills.forEach((skill) => {
    if (skill.proficiency === "Advanced" || skill.proficiency === "Expert" || skill.score >= 70) {
      strengths.push(`Solid grasp of ${skill.name} fundamentals and implementation`);
    } else {
      weaknesses.push(`${skill.name} proficiency is at ${skill.proficiency} stage; requires deeper asynchronous/architectural practice`);
    }
  });

  if (missingList.length > 0) {
    weaknesses.push(`Lacks essential industry prerequisites: ${missingList.slice(0, 3).join(", ")}`);
  }

  return {
    existingSkills: input.userSkills,
    strengths: strengths.length ? strengths : ["Demonstrated foundation in computer science and problem solving"],
    weaknesses: weaknesses.length ? weaknesses : ["Needs real-world full-stack deployment experience"],
    missingSkills: missingList,
    skillGapPercentage: gapPercentage,
    overallProficiencySummary: `Learner has demonstrated baseline competence in ${input.userSkills.map((s) => s.name).join(", ") || "core subjects"}, but has a ${gapPercentage}% gap against market expectations for ${input.targetCareer}.`,
    source: "deterministic-engine",
  };
}
