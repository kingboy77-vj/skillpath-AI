import { callGemini } from "../gemini";

export interface CareerMatchingInput {
  targetCareer: string;
  careerDescription?: string;
  userSkills: { name: string; proficiency: string; score: number }[];
  careerRequirements: { skillName: string; requiredProficiency: string; importance: string; weight: number }[];
}

export interface CareerMatchingOutput {
  targetCareer: string;
  requiredSkills: string[];
  availableSkills: string[];
  missingSkills: string[];
  careerReadinessScore: number;
  recommendations: string[];
  marketDemandInsight: string;
  source: "gemini" | "deterministic-engine";
}

export async function runCareerMatchingAgent(input: CareerMatchingInput): Promise<CareerMatchingOutput> {
  const userSkillMap = new Map(
    input.userSkills.map((s) => [s.name.toLowerCase(), s])
  );

  let totalWeight = 0;
  let earnedScore = 0;

  const requiredSkillNames: string[] = [];
  const availableSkillNames: string[] = [];
  const missingSkillNames: string[] = [];

  for (const req of input.careerRequirements) {
    requiredSkillNames.push(req.skillName);
    const weight = req.weight || 10;
    totalWeight += weight;

    const matchingUserSkill = userSkillMap.get(req.skillName.toLowerCase());
    if (matchingUserSkill) {
      availableSkillNames.push(req.skillName);
      // calculate earned proportion
      const profMultiplier =
        matchingUserSkill.proficiency === "Expert" ? 1.0 :
        matchingUserSkill.proficiency === "Advanced" ? 0.9 :
        matchingUserSkill.proficiency === "Intermediate" ? 0.65 : 0.4;
      earnedScore += weight * profMultiplier;
    } else {
      missingSkillNames.push(req.skillName);
    }
  }

  const baselineReadiness = totalWeight > 0 ? Math.round((earnedScore / totalWeight) * 100) : 35;

  // Try Gemini AI
  const prompt = `You are the CAREER MATCHING AGENT for King Skill AI.
Target Career: "${input.targetCareer}"
Career Requirements: ${JSON.stringify(input.careerRequirements)}
Learner's Available Skills: ${JSON.stringify(input.userSkills)}
Calculated Weighted Score: ${baselineReadiness}%

Evaluate the learner's readiness for this career.
Return strictly valid JSON with this exact schema:
{
  "careerReadinessScore": number (0-100),
  "recommendations": ["recommendation 1", "recommendation 2", "recommendation 3"],
  "marketDemandInsight": "detailed explanation of current job market demand and hiring manager expectations for this role"
}`;

  const aiResult = await callGemini({
    systemPrompt: "You are an expert career placement auditor. Output only raw JSON.",
    userPrompt: prompt,
    jsonMode: true,
  });

  if (!aiResult.isDemo && aiResult.text) {
    try {
      const parsed = JSON.parse(aiResult.text);
      return {
        targetCareer: input.targetCareer,
        requiredSkills: requiredSkillNames,
        availableSkills: availableSkillNames,
        missingSkills: missingSkillNames,
        careerReadinessScore: typeof parsed.careerReadinessScore === "number" ? parsed.careerReadinessScore : baselineReadiness,
        recommendations: parsed.recommendations || [
          `Prioritize acquiring ${missingSkillNames.slice(0, 2).join(" and ")} immediately.`,
          "Build an end-to-end portfolio project highlighting full-stack data flow.",
        ],
        marketDemandInsight: parsed.marketDemandInsight || `Strong industry hiring velocity for ${input.targetCareer}. Candidates with verified full-stack project experience enjoy high placement rates.`,
        source: "gemini",
      };
    } catch (e) {
      console.warn("Failed to parse Gemini career matching response, using deterministic engine:", e);
    }
  }

  // Deterministic fallback
  const recs = [
    `Prioritize core missing skills: ${missingSkillNames.slice(0, 3).join(", ") || "Advanced System Design"}.`,
    `Solidify intermediate skills with hands-on capstone projects rather than passive tutorial consumption.`,
    `Complete verified topic assessments to validate skill acquisition for hiring managers.`,
  ];

  return {
    targetCareer: input.targetCareer,
    requiredSkills: requiredSkillNames,
    availableSkills: availableSkillNames,
    missingSkills: missingSkillNames,
    careerReadinessScore: baselineReadiness,
    recommendations: recs,
    marketDemandInsight: `${input.targetCareer} roles are experiencing 20%+ annual growth. Hiring managers prioritize developers who can articulate design tradeoffs and build secure, end-to-end APIs.`,
    source: "deterministic-engine",
  };
}
