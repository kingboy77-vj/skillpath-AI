import { db } from "@/db";
import {
  profiles,
  careers,
  careerRequirements,
  userSkills,
  userProgress,
  aiAgentLogs,
  learningRoadmaps,
  roadmapTasks,
  learningResources,
} from "@/db/schema";
import { eq, and } from "drizzle-orm";
import { runSkillAnalysisAgent, SkillAnalysisOutput } from "./skill-analysis-agent";
import { runCareerMatchingAgent, CareerMatchingOutput } from "./career-matching-agent";
import { runLearningRecommendationAgent, LearningRecommendationOutput } from "./learning-recommendation-agent";
import { runRoadmapAgent, RoadmapAgentOutput } from "./roadmap-agent";

export interface OrchestrationResult {
  userId: string;
  targetCareer: string;
  stepResults: {
    skillAnalysis: SkillAnalysisOutput;
    careerMatching: CareerMatchingOutput;
    learningRecommendations: LearningRecommendationOutput;
    roadmap: RoadmapAgentOutput;
  };
  persistedRoadmapId: string;
  careerReadinessScore: number;
  orchestrationSummary: string;
}

export async function orchestrateFullLearningPipeline(
  userId: string,
  targetCareerId?: string
): Promise<OrchestrationResult> {
  const startTime = Date.now();

  // 1. Fetch User Profile
  const profileList = await db.select().from(profiles).where(eq(profiles.id, userId));
  if (profileList.length === 0) {
    throw new Error(`Profile not found for userId: ${userId}`);
  }
  const user = profileList[0];

  const effectiveCareerId = targetCareerId || user.targetCareerId || "full-stack-developer";

  // Fetch Career
  const careerList = await db.select().from(careers).where(eq(careers.id, effectiveCareerId));
  const career = careerList[0] || {
    id: "full-stack-developer",
    title: "Full Stack Developer",
    description: "Builds web interfaces and backend services",
    category: "Software Engineering",
  };

  // Fetch Career Requirements
  const reqs = await db.select().from(careerRequirements).where(eq(careerRequirements.careerId, effectiveCareerId));

  // Fetch Current User Skills
  const uSkills = await db.select().from(userSkills).where(eq(userSkills.userId, userId));

  const formattedUserSkills = uSkills.map((s) => ({
    name: s.skillName,
    proficiency: s.proficiencyLevel,
    score: s.score,
  }));

  const formattedReqs = reqs.map((r) => ({
    name: r.skillName,
    skillName: r.skillName,
    requiredProficiency: r.requiredProficiency,
    importance: r.importance,
    weight: r.weight,
  }));

  // Step 1: Execute Skill Analysis Agent
  const step1Start = Date.now();
  const skillAnalysis = await runSkillAnalysisAgent({
    userSkills: formattedUserSkills,
    targetCareer: career.title,
    requiredSkills: formattedReqs,
    education: user.educationLevel || undefined,
    projects: user.completedProjects as any,
  });
  await db.insert(aiAgentLogs).values({
    id: `log_orch_sa_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
    userId,
    agentName: "Skill Analysis Agent",
    agentRole: "Analyze user competencies against baseline prerequisites",
    inputPayload: { userSkills: formattedUserSkills, targetCareer: career.title },
    outputPayload: skillAnalysis as any,
    durationMs: Date.now() - step1Start,
  });

  // Step 2: Execute Career Matching Agent with Skill Analysis Output
  const step2Start = Date.now();
  const careerMatching = await runCareerMatchingAgent({
    targetCareer: career.title,
    careerDescription: career.description,
    userSkills: formattedUserSkills,
    careerRequirements: formattedReqs,
  });
  await db.insert(aiAgentLogs).values({
    id: `log_orch_cm_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
    userId,
    agentName: "Career Matching Agent",
    agentRole: "Compute market readiness and target career alignment",
    inputPayload: { career: career.title, skillAnalysisGaps: skillAnalysis.missingSkills },
    outputPayload: careerMatching as any,
    durationMs: Date.now() - step2Start,
  });

  // Step 3: Execute Learning Recommendation Agent with Missing Skills
  const step3Start = Date.now();
  const dbResources = await db.select().from(learningResources);
  const formattedResources = dbResources.map((r) => ({
    id: r.id,
    title: r.title,
    skillCovered: r.skillName,
    difficultyLevel: r.difficultyLevel as any,
    estimatedDuration: r.estimatedDuration,
    resourceUrl: r.resourceUrl,
    learningObjective: r.learningObjective,
    type: r.type as any,
    provider: r.provider,
  }));

  const learningRecommendations = await runLearningRecommendationAgent({
    targetCareer: career.title,
    missingSkills: careerMatching.missingSkills,
    weakSkills: skillAnalysis.weaknesses,
    learningStyle: user.preferredLearningStyle || undefined,
    existingResources: formattedResources,
  });
  await db.insert(aiAgentLogs).values({
    id: `log_orch_lr_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
    userId,
    agentName: "Learning Recommendation Agent",
    agentRole: "Curate tailored learning path & prioritize missing skills",
    inputPayload: { missingSkills: careerMatching.missingSkills },
    outputPayload: learningRecommendations as any,
    durationMs: Date.now() - step3Start,
  });

  // Step 4: Execute Learning Roadmap Agent
  const step4Start = Date.now();
  const roadmapOutput = await runRoadmapAgent({
    targetCareer: career.title,
    missingSkills: careerMatching.missingSkills,
    currentSkills: formattedUserSkills.map((s) => s.name),
    learningStyle: user.preferredLearningStyle || undefined,
  });
  await db.insert(aiAgentLogs).values({
    id: `log_orch_rm_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
    userId,
    agentName: "Learning Roadmap Agent",
    agentRole: "Synthesize 5-phase progressive personalized syllabus",
    inputPayload: { targetCareer: career.title, gaps: careerMatching.missingSkills.length },
    outputPayload: roadmapOutput as any,
    durationMs: Date.now() - step4Start,
  });

  // Persist or Update Roadmap in DB
  const existingRoadmap = await db
    .select()
    .from(learningRoadmaps)
    .where(and(eq(learningRoadmaps.userId, userId), eq(learningRoadmaps.careerId, effectiveCareerId)));

  let roadmapId = `rdm_${userId}_${Date.now()}`;
  if (existingRoadmap.length > 0) {
    roadmapId = existingRoadmap[0].id;
    await db
      .update(learningRoadmaps)
      .set({
        readinessScore: careerMatching.careerReadinessScore,
        careerTitle: career.title,
        updatedAt: new Date(),
      })
      .where(eq(learningRoadmaps.id, roadmapId));
  } else {
    await db.insert(learningRoadmaps).values({
      id: roadmapId,
      userId,
      careerId: effectiveCareerId,
      careerTitle: career.title,
      readinessScore: careerMatching.careerReadinessScore,
      status: "active",
      totalPhases: 5,
    });
  }

  // Update or insert tasks if none exist
  const existingTasks = await db.select().from(roadmapTasks).where(eq(roadmapTasks.roadmapId, roadmapId));
  if (existingTasks.length === 0) {
    let orderCounter = 1;
    for (const phase of roadmapOutput.phases) {
      for (const t of phase.tasks) {
        await db.insert(roadmapTasks).values({
          id: `tsk_${roadmapId}_${orderCounter}`,
          roadmapId,
          phaseNumber: phase.phaseNumber,
          phaseTitle: phase.phaseTitle,
          phaseDescription: phase.phaseDescription,
          title: t.title,
          skillsToLearn: t.skillsToLearn || [],
          topics: t.topics || [],
          practicalTasks: t.practicalTasks || [],
          resourceTitle: t.resourceTitle || null,
          resourceUrl: t.resourceUrl || null,
          completed: !!t.completed,
          orderIndex: orderCounter++,
        });
      }
    }
  }

  // Step 5: Update User Progress & Profile
  await db
    .update(profiles)
    .set({
      targetCareerId: effectiveCareerId,
      targetCareerName: career.title,
      updatedAt: new Date(),
    })
    .where(eq(profiles.id, userId));

  const readiness = careerMatching.careerReadinessScore;
  const missingCount = careerMatching.missingSkills.length;
  const acquiredCount = formattedUserSkills.length;

  const existingProgress = await db.select().from(userProgress).where(eq(userProgress.userId, userId));
  if (existingProgress.length > 0) {
    await db
      .update(userProgress)
      .set({
        careerReadiness: readiness,
        totalSkillsAcquired: acquiredCount,
        missingSkillsCount: missingCount,
        lastActiveAt: new Date(),
      })
      .where(eq(userProgress.userId, userId));
  } else {
    await db.insert(userProgress).values({
      id: `prog_${userId}`,
      userId,
      careerReadiness: readiness,
      totalSkillsAcquired: acquiredCount,
      missingSkillsCount: missingCount,
      roadmapCompletionPct: 20,
    });
  }

  return {
    userId,
    targetCareer: career.title,
    stepResults: {
      skillAnalysis,
      careerMatching,
      learningRecommendations,
      roadmap: roadmapOutput,
    },
    persistedRoadmapId: roadmapId,
    careerReadinessScore: readiness,
    orchestrationSummary: `Successfully orchestrated 4 AI agents in ${Date.now() - startTime}ms. Identified ${missingCount} skill gaps, mapped readiness to ${readiness}%, and refreshed personalized syllabus.`,
  };
}
