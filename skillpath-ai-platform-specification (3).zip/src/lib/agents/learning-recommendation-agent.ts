import { callGemini } from "../gemini";

export interface ResourceItem {
  id?: string;
  title: string;
  skillCovered: string;
  difficultyLevel: "Beginner" | "Intermediate" | "Advanced";
  estimatedDuration: string;
  resourceUrl: string;
  learningObjective: string;
  type: "Course" | "Video Tutorial" | "Documentation" | "Coding Exercise" | "Mini-Project";
  provider?: string;
}

export interface LearningRecommendationInput {
  targetCareer: string;
  missingSkills: string[];
  weakSkills?: string[];
  learningStyle?: string;
  existingResources?: ResourceItem[];
}

export interface LearningRecommendationOutput {
  recommendations: ResourceItem[];
  priorityFocusSkill: string;
  pedagogicalRationale: string;
  source: "gemini" | "deterministic-engine";
}

export async function runLearningRecommendationAgent(
  input: LearningRecommendationInput
): Promise<LearningRecommendationOutput> {
  const primaryGap = input.missingSkills[0] || "JavaScript";

  // If existing curated resources are provided from DB, we can prioritize matching ones
  const filteredFromDb = (input.existingResources || []).filter((r) =>
    input.missingSkills.some((s) => s.toLowerCase() === r.skillCovered.toLowerCase())
  );

  // Try Gemini AI for dynamic recommendation enhancement
  const prompt = `You are the LEARNING RECOMMENDATION AGENT for King Skill AI.
Target Career: "${input.targetCareer}"
Skill Gaps: ${JSON.stringify(input.missingSkills)}
Preferred Learning Style: "${input.learningStyle || "Hands-on Projects"}"

Recommend 4 highly targeted learning items (courses, tutorials, coding exercises, mini-projects) tailored to close these specific skill gaps.
Return strictly valid JSON with this exact schema:
{
  "priorityFocusSkill": "string",
  "pedagogicalRationale": "string",
  "recommendations": [
    {
      "title": "string",
      "skillCovered": "string",
      "difficultyLevel": "Beginner" | "Intermediate" | "Advanced",
      "estimatedDuration": "string",
      "resourceUrl": "string (valid URL)",
      "learningObjective": "string",
      "type": "Course" | "Video Tutorial" | "Documentation" | "Coding Exercise" | "Mini-Project"
    }
  ]
}`;

  const aiResult = await callGemini({
    systemPrompt: "You are an expert technical curriculum designer. Output only raw JSON.",
    userPrompt: prompt,
    jsonMode: true,
  });

  if (!aiResult.isDemo && aiResult.text) {
    try {
      const parsed = JSON.parse(aiResult.text);
      if (Array.isArray(parsed.recommendations) && parsed.recommendations.length > 0) {
        return {
          priorityFocusSkill: parsed.priorityFocusSkill || primaryGap,
          pedagogicalRationale: parsed.pedagogicalRationale || `Focused on bridging foundational gaps in ${primaryGap} before moving to framework abstractions.`,
          recommendations: parsed.recommendations,
          source: "gemini",
        };
      }
    } catch (e) {
      console.warn("Failed to parse Gemini learning recommendation response:", e);
    }
  }

  // Deterministic fallback using curated resources
  const defaultRecs: ResourceItem[] = [
    {
      title: "Modern JavaScript Deep Dive: From Fundamentals to ESNext",
      skillCovered: "JavaScript",
      difficultyLevel: "Beginner",
      estimatedDuration: "14 hours",
      resourceUrl: "https://javascript.info",
      learningObjective: "Master closures, lexical scoping, event loop, promises, and modern ES6+ functional paradigms.",
      type: "Course",
      provider: "King Skill Academy",
    },
    {
      title: "Interactive React 19: Full Architecture & Hooks",
      skillCovered: "React",
      difficultyLevel: "Intermediate",
      estimatedDuration: "18 hours",
      resourceUrl: "https://react.dev/learn",
      learningObjective: "Understand component trees, hooks lifecycle, server state caching, and client performance.",
      type: "Course",
      provider: "React Official Core Curriculum",
    },
    {
      title: "Building Production-Ready REST APIs with Node.js & Express",
      skillCovered: "Node.js",
      difficultyLevel: "Intermediate",
      estimatedDuration: "16 hours",
      resourceUrl: "https://nodejs.org/en/learn",
      learningObjective: "Architect scalable Express routers, error handlers, authentication middleware, and input validators.",
      type: "Course",
      provider: "Backend Pro",
    },
    {
      title: "Full Stack Mini-Project: E-Commerce Store with Cart & Auth",
      skillCovered: "React",
      difficultyLevel: "Intermediate",
      estimatedDuration: "20 hours",
      resourceUrl: "https://github.com/topics/fullstack-ecommerce",
      learningObjective: "Integrate React frontend with Express REST backend and PostgreSQL database storage.",
      type: "Mini-Project",
      provider: "King Skill Project Lab",
    },
  ];

  return {
    priorityFocusSkill: primaryGap,
    pedagogicalRationale: `Given the learner's target of ${input.targetCareer}, closing ${primaryGap} and reactive UI fundamentals provides the steepest trajectory to career readiness.`,
    recommendations: filteredFromDb.length >= 3 ? filteredFromDb.slice(0, 4) : defaultRecs,
    source: "deterministic-engine",
  };
}
