import { callGemini } from "../gemini";

export interface MentorAgentInput {
  userMessage: string;
  chatHistory?: { sender: "user" | "ai_mentor"; message: string }[];
  profile: {
    fullName: string;
    education: string;
    targetCareer: string;
    learningStyle: string;
    skills: { name: string; proficiency: string }[];
  };
  progress: {
    careerReadiness: number;
    totalSkillsAcquired: number;
    missingSkillsCount: number;
    roadmapCompletionPct: number;
  };
  activeRoadmapTask?: string;
}

export interface MentorAgentOutput {
  reply: string;
  recommendedSkills?: string[];
  suggestedActions?: { label: string; action: string; payload?: Record<string, any> }[];
  source: "gemini" | "deterministic-engine";
}

export async function runMentorAgent(input: MentorAgentInput): Promise<MentorAgentOutput> {
  const currentSkillNames = input.profile.skills.map((s) => `${s.name} (${s.proficiency})`).join(", ");

  const systemPrompt = `You are the AI MENTOR AGENT for King Skill AI, an elite, encouraging technical coach.
Learner Context:
- Name: ${input.profile.fullName}
- Target Career: ${input.profile.targetCareer}
- Current Skills: ${currentSkillNames || "None listed"}
- Preferred Learning Style: ${input.profile.learningStyle}
- Career Readiness: ${input.progress.careerReadiness}%
- Roadmap Progress: ${input.progress.roadmapCompletionPct}%
- Current Focus Task: ${input.activeRoadmapTask || "General Preparation"}

Guidelines:
1. Always give technically rigorous, succinct, and motivating advice tailored to their target career (${input.profile.targetCareer}).
2. When they ask questions like "I want to become a Full Stack Developer", acknowledge their current skills (${currentSkillNames}) and state their immediate next priorities (e.g. JavaScript, CSS, React, Node.js).
3. When asked "What should I learn first?", guide them step-by-step (e.g. start with JavaScript fundamentals, complete lessons, take short assessments to update their roadmap).
4. Provide structured JSON with your reply, optional recommendedSkills array, and suggestedActions array.`;

  const userPrompt = `User asks: "${input.userMessage}"
Recent conversation context:
${(input.chatHistory || []).slice(-4).map((m) => `${m.sender}: ${m.message}`).join("\n")}

Respond in strictly valid JSON:
{
  "reply": "your conversational response here",
  "recommendedSkills": ["skill1", "skill2"],
  "suggestedActions": [
    { "label": "Action button text", "action": "NAVIGATE_ROADMAP" | "START_ASSESSMENT" | "VIEW_SKILLS" | "EXPLORE_CAREERS" }
  ]
}`;

  const aiResult = await callGemini({
    systemPrompt,
    userPrompt,
    jsonMode: true,
  });

  if (!aiResult.isDemo && aiResult.text) {
    try {
      const parsed = JSON.parse(aiResult.text);
      return {
        reply: parsed.reply || "I am here to guide your technical journey. What area would you like to explore today?",
        recommendedSkills: parsed.recommendedSkills || [],
        suggestedActions: parsed.suggestedActions || [
          { label: "View Learning Roadmap", action: "NAVIGATE_ROADMAP" },
        ],
        source: "gemini",
      };
    } catch (e) {
      console.warn("Failed to parse Gemini mentor response, falling back:", e);
    }
  }

  // Deterministic contextual response
  const query = input.userMessage.toLowerCase();
  let reply = "";
  let actions: { label: string; action: string; payload?: Record<string, any> }[] = [];
  let recSkills: string[] = [];

  if (query.includes("full stack") || query.includes("career") || query.includes("become")) {
    reply = `You already have ${currentSkillNames}. For your target as a ${input.profile.targetCareer}, your next learning priorities are JavaScript, CSS, React, and Node.js. Following a structured roadmap will accelerate your progress significantly.`;
    recSkills = ["JavaScript", "CSS", "React", "Node.js"];
    actions = [
      { label: "View Recommended Roadmap", action: "NAVIGATE_ROADMAP" },
      { label: "Take JavaScript Assessment", action: "START_ASSESSMENT", payload: { assessmentId: "asm_javascript_101" } },
    ];
  } else if (query.includes("first") || query.includes("start") || query.includes("begin")) {
    reply = `Start with JavaScript fundamentals. After completing the lessons, take a short assessment. Your roadmap will update based on your performance, unlocking intermediate backend and framework modules!`;
    recSkills = ["JavaScript"];
    actions = [
      { label: "Start JavaScript 101 Assessment", action: "START_ASSESSMENT", payload: { assessmentId: "asm_javascript_101" } },
      { label: "View JavaScript Resources", action: "OPEN_RESOURCE", payload: { skill: "JavaScript" } },
    ];
  } else if (query.includes("react") || query.includes("frontend")) {
    reply = `React is the core frontend engine for modern web apps. Focus on state immutability, the component lifecycle, and hook dependencies (useState, useEffect, custom hooks). Would you like to test your React knowledge with our assessment?`;
    recSkills = ["React", "JavaScript"];
    actions = [
      { label: "Take React Assessment", action: "START_ASSESSMENT", payload: { assessmentId: "asm_react_101" } },
    ];
  } else if (query.includes("node") || query.includes("backend") || query.includes("api")) {
    reply = `For backend engineering with Node.js and Express, focus on non-blocking I/O, middleware pipelines, RESTful resource design, and PostgreSQL database migrations.`;
    recSkills = ["Node.js", "Express.js", "SQL"];
    actions = [
      { label: "Take Node.js Assessment", action: "START_ASSESSMENT", payload: { assessmentId: "asm_node_101" } },
    ];
  } else {
    reply = `Great question! As an aspiring ${input.profile.targetCareer}, consistency is key. Currently your career readiness is at ${input.progress.careerReadiness}%. Working through your active roadmap tasks and validating them via skill assessments will rapidly bridge remaining gaps. How can I help you break down your next concept?`;
    actions = [
      { label: "Review Roadmap Tasks", action: "NAVIGATE_ROADMAP" },
      { label: "Analyze Skill Gaps", action: "VIEW_SKILLS" },
    ];
  }

  return {
    reply,
    recommendedSkills: recSkills,
    suggestedActions: actions,
    source: "deterministic-engine",
  };
}
