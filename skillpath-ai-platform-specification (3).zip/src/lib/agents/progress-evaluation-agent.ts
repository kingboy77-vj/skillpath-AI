import { callGemini } from "../gemini";

export interface ProgressEvaluationInput {
  assessmentTitle: string;
  skillName: string;
  score: number;
  totalQuestions: number;
  percentage: number;
  questionDetails: {
    questionText: string;
    topic: string;
    isCorrect: boolean;
    userAnswer: string;
    correctAnswer: string;
  }[];
}

export interface ProgressEvaluationOutput {
  summary: string;
  passed: boolean;
  scorePercentage: number;
  strengths: string[];
  topicsToReview: string[];
  recommendedAction: string;
  suggestedResources: { title: string; url: string; reason: string }[];
  proficiencyAdjustment: {
    skillName: string;
    newLevel: "Beginner" | "Intermediate" | "Advanced" | "Expert";
    scoreDelta: number;
  };
  source: "gemini" | "deterministic-engine";
}

export async function runProgressEvaluationAgent(
  input: ProgressEvaluationInput
): Promise<ProgressEvaluationOutput> {
  const passed = input.percentage >= 60;
  const incorrectTopics = input.questionDetails
    .filter((q) => !q.isCorrect)
    .map((q) => q.topic);
  const correctTopics = input.questionDetails
    .filter((q) => q.isCorrect)
    .map((q) => q.topic);

  const prompt = `You are the PROGRESS EVALUATION AGENT for King Skill AI.
Assessment: "${input.assessmentTitle}" (Skill: ${input.skillName})
Score: ${input.score}/${input.totalQuestions} (${input.percentage}%)
Performance breakdown:
${JSON.stringify(input.questionDetails)}

Evaluate this quiz result.
- Identify exact conceptual strengths.
- Identify topics that require urgent revision.
- Provide tailored action recommendations.
- Determine if the learner's proficiency in ${input.skillName} should be adjusted (e.g. to Beginner, Intermediate, or Advanced).

Return strictly valid JSON with this exact schema:
{
  "summary": "string",
  "strengths": ["string"],
  "topicsToReview": ["string"],
  "recommendedAction": "string",
  "suggestedResources": [
    { "title": "string", "url": "string", "reason": "string" }
  ],
  "proficiencyAdjustment": {
    "skillName": "${input.skillName}",
    "newLevel": "Beginner" | "Intermediate" | "Advanced" | "Expert",
    "scoreDelta": number
  }
}`;

  const aiResult = await callGemini({
    systemPrompt: "You are an AI learning diagnostic evaluator. Output only raw JSON.",
    userPrompt: prompt,
    jsonMode: true,
  });

  if (!aiResult.isDemo && aiResult.text) {
    try {
      const parsed = JSON.parse(aiResult.text);
      return {
        summary: parsed.summary || `Learner achieved ${input.percentage}% on ${input.assessmentTitle}.`,
        passed,
        scorePercentage: input.percentage,
        strengths: parsed.strengths || (correctTopics.length ? correctTopics : ["Consistent effort on technical queries"]),
        topicsToReview: parsed.topicsToReview || (incorrectTopics.length ? incorrectTopics : ["Review edge cases"]),
        recommendedAction: parsed.recommendedAction || (passed ? "Ready to proceed to next roadmap milestone." : "Review foundational lessons before retaking."),
        suggestedResources: parsed.suggestedResources || [],
        proficiencyAdjustment: parsed.proficiencyAdjustment || {
          skillName: input.skillName,
          newLevel: input.percentage >= 80 ? "Advanced" : input.percentage >= 50 ? "Intermediate" : "Beginner",
          scoreDelta: input.percentage >= 80 ? 15 : input.percentage >= 50 ? 5 : -5,
        },
        source: "gemini",
      };
    } catch (e) {
      console.warn("Failed to parse Gemini progress evaluation response:", e);
    }
  }

  // Deterministic fallback
  let newProficiency: "Beginner" | "Intermediate" | "Advanced" | "Expert" = "Beginner";
  let delta = 5;

  if (input.percentage >= 85) {
    newProficiency = "Advanced";
    delta = 20;
  } else if (input.percentage >= 60) {
    newProficiency = "Intermediate";
    delta = 10;
  } else {
    newProficiency = "Beginner";
    delta = -5;
  }

  return {
    summary: passed
      ? `Strong performance (${input.percentage}%) on ${input.assessmentTitle}. Demonstrated clear comprehension of core tenets.`
      : `Score of ${input.percentage}% is below the 60% mastery threshold. Targeted revision is recommended before proceeding.`,
    passed,
    scorePercentage: input.percentage,
    strengths: correctTopics.length > 0 ? Array.from(new Set(correctTopics)) : ["Baseline problem comprehension"],
    topicsToReview: incorrectTopics.length > 0 ? Array.from(new Set(incorrectTopics)) : ["Syntax nuances and edge-case behaviors"],
    recommendedAction: passed
      ? `Progress to the next scheduled task in your learning roadmap. You have earned a skill proficiency bump.`
      : `Re-visit the primary documentation and coding exercises for ${incorrectTopics[0] || input.skillName} before retaking this assessment.`,
    suggestedResources: [
      {
        title: `${input.skillName} Official Documentation & Guides`,
        url: `https://developer.mozilla.org/en-US/docs/Web/${input.skillName}`,
        reason: `Targeted review of ${incorrectTopics.slice(0, 2).join(" & ") || input.skillName} key principles.`,
      },
    ],
    proficiencyAdjustment: {
      skillName: input.skillName,
      newLevel: newProficiency,
      scoreDelta: delta,
    },
    source: "deterministic-engine",
  };
}
