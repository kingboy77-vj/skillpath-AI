import { cookies } from "next/headers";
import { db } from "@/db";
import { profiles } from "@/db/schema";
import { eq } from "drizzle-orm";

export const DEFAULT_USER_ID = "usr_alex_001";
const SESSION_COOKIE_NAME = "skillpath_user_id";

export async function getCurrentUserId(): Promise<string> {
  try {
    const cookieStore = await cookies();
    const cookieUser = cookieStore.get(SESSION_COOKIE_NAME)?.value;
    if (cookieUser) {
      return cookieUser;
    }
  } catch (e) {
    // If running in a context where cookies() is unavailable
  }
  return DEFAULT_USER_ID;
}

export async function getCurrentProfile() {
  const userId = await getCurrentUserId();
  const profileList = await db.select().from(profiles).where(eq(profiles.id, userId));
  if (profileList.length > 0) {
    return profileList[0];
  }
  // Fallback to Alex
  const defaultList = await db.select().from(profiles).where(eq(profiles.id, DEFAULT_USER_ID));
  return defaultList[0] || null;
}
