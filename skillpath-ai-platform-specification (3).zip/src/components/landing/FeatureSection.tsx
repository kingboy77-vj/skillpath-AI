"use client";

import React from "react";
import { Compass, Radar, Map, TrendingUp, ArrowUpRight } from "lucide-react";

interface FeatureSectionProps {
  onNavigate: (target: "skills" | "roadmap" | "mentor" | "dashboard" | "careers" | "progress") => void;
}

export const FeatureSection: React.FC<FeatureSectionProps> = ({ onNavigate }) => {
  const features = [
    {
      icon: Compass,
      title: "AI Career Guidance",
      description: "Personalized career recommendations matched to your strengths and market demand.",
      target: "careers" as const,
      accent: "from-cyan-400 to-blue-500",
      glow: "group-hover:shadow-[0_0_36px_rgba(56,189,248,0.25)]",
      border: "group-hover:border-cyan-400/40",
    },
    {
      icon: Radar,
      title: "Skill Assessment",
      description: "Identify strengths and skill gaps with intelligent, evidence-based evaluation.",
      target: "skills" as const,
      accent: "from-blue-400 to-indigo-500",
      glow: "group-hover:shadow-[0_0_36px_rgba(99,102,241,0.25)]",
      border: "group-hover:border-indigo-400/40",
    },
    {
      icon: Map,
      title: "Personalized Learning",
      description: "AI-generated learning roadmaps tailored to your goals, pace, and learning style.",
      target: "roadmap" as const,
      accent: "from-purple-400 to-pink-500",
      glow: "group-hover:shadow-[0_0_36px_rgba(168,85,247,0.25)]",
      border: "group-hover:border-purple-400/40",
    },
    {
      icon: TrendingUp,
      title: "Progress Tracking",
      description: "Monitor learning progress and achievements with real-time analytics and insights.",
      target: "progress" as const,
      accent: "from-emerald-400 to-cyan-500",
      glow: "group-hover:shadow-[0_0_36px_rgba(52,211,153,0.22)]",
      border: "group-hover:border-emerald-400/40",
    },
  ];

  return (
    <section id="features" className="relative py-24 sm:py-32 px-4 sm:px-6 lg:px-8">
      <div className="absolute inset-0 pointer-events-none" aria-hidden="true">
        <div className="absolute left-1/2 top-0 -translate-x-1/2 w-[600px] h-[300px] bg-blue-600/10 blur-[100px] rounded-full" />
      </div>

      <div className="relative max-w-7xl mx-auto">
        <div className="text-center max-w-2xl mx-auto mb-14 sm:mb-20">
          <p className="text-[11px] font-bold tracking-[0.28em] uppercase text-cyan-400 mb-4">
            Intelligent Guidance
          </p>
          <h2 className="text-3xl sm:text-5xl font-extrabold tracking-tight text-white leading-tight">
            Everything you need to{" "}
            <span className="bg-gradient-to-r from-cyan-300 to-purple-400 bg-clip-text text-transparent">
              grow faster
            </span>
          </h2>
          <p className="mt-4 text-slate-400 text-base sm:text-lg font-light leading-relaxed">
            Four pillars powered by six collaborating AI agents — designed to take you from
            where you are to where you want to be.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {features.map((feature, idx) => {
            const Icon = feature.icon;
            return (
              <button
                key={feature.title}
                onClick={() => onNavigate(feature.target)}
                className={`group relative text-left p-7 rounded-3xl bg-white/[0.03] hover:bg-white/[0.06] border border-white/10 ${feature.border} backdrop-blur-xl transition-all duration-500 hover:-translate-y-2 ${feature.glow} animate-fade-up`}
                style={{ animationDelay: `${idx * 120}ms` }}
              >
                <div
                  className={`w-12 h-12 rounded-2xl bg-gradient-to-tr ${feature.accent} flex items-center justify-center shadow-lg mb-6 group-hover:scale-110 transition-transform duration-500`}
                >
                  <Icon className="w-6 h-6 text-white" />
                </div>
                <h3 className="text-lg font-bold text-white tracking-tight mb-2.5">
                  {feature.title}
                </h3>
                <p className="text-sm text-slate-400 leading-relaxed font-light min-h-[60px]">
                  {feature.description}
                </p>
                <span className="mt-5 inline-flex items-center gap-1 text-xs font-semibold text-cyan-300 group-hover:gap-2 transition-all">
                  <span>Explore</span>
                  <ArrowUpRight className="w-3.5 h-3.5" />
                </span>
                {/* Corner glow dot */}
                <span className="absolute top-5 right-5 w-1.5 h-1.5 rounded-full bg-white/40 group-hover:bg-white group-hover:shadow-[0_0_10px_rgba(255,255,255,0.9)] transition-all" />
              </button>
            );
          })}
        </div>

        {/* Stats strip */}
        <div className="mt-16 sm:mt-20 grid grid-cols-2 lg:grid-cols-4 gap-px rounded-3xl overflow-hidden bg-white/10 border border-white/10 backdrop-blur-xl">
          {[
            { value: "6", label: "AI Agents" },
            { value: "7", label: "Career Paths" },
            { value: "5", label: "Phase Roadmaps" },
            { value: "24/7", label: "AI Mentor" },
          ].map((stat) => (
            <div
              key={stat.label}
              className="bg-black/60 backdrop-blur-xl px-6 py-8 text-center hover:bg-white/[0.04] transition-colors"
            >
              <div className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
                {stat.value}
              </div>
              <div className="mt-1.5 text-[11px] tracking-[0.2em] uppercase text-slate-400">
                {stat.label}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
