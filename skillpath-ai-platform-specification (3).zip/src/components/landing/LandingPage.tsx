"use client";

import React from "react";
import { Sparkles, ArrowRight, Bot, Radar, Map, TrendingUp } from "lucide-react";
import { FloatingNav } from "./FloatingNav";
import { HeroSection } from "./HeroSection";
import { FeatureSection } from "./FeatureSection";

interface LandingPageProps {
  onNavigate: (target: "home" | "skills" | "roadmap" | "mentor" | "dashboard" | "careers" | "progress") => void;
  onGetStarted: () => void;
  isLoggedIn: boolean;
  userName?: string;
}

export const LandingPage: React.FC<LandingPageProps> = ({
  onNavigate,
  onGetStarted,
  isLoggedIn,
  userName,
}) => {
  const handleNav = (target: "home" | "skills" | "roadmap" | "mentor" | "dashboard") => {
    if (target === "home") {
      window.scrollTo({ top: 0, behavior: "smooth" });
      return;
    }
    onNavigate(target);
  };

  const handleFeatureNav = (target: "skills" | "roadmap" | "mentor" | "dashboard" | "careers" | "progress") => {
    onNavigate(target);
  };

  return (
    <div className="relative min-h-screen bg-black text-slate-100 overflow-x-hidden">
      {/* Global floating particles backdrop */}
      <div className="fixed inset-0 pointer-events-none z-0" aria-hidden="true">
        <span className="absolute left-[8%] top-[18%] w-1 h-1 rounded-full bg-cyan-300/70 animate-twinkle" />
        <span className="absolute left-[88%] top-[12%] w-1.5 h-1.5 rounded-full bg-white/60 animate-twinkle delay-200" />
        <span className="absolute left-[82%] top-[55%] w-1 h-1 rounded-full bg-purple-300/70 animate-twinkle delay-500" />
        <span className="absolute left-[12%] top-[62%] w-1 h-1 rounded-full bg-blue-300/60 animate-twinkle delay-700" />
        <span className="absolute left-[45%] top-[8%] w-1 h-1 rounded-full bg-white/50 animate-twinkle delay-300" />
        <span className="absolute left-[65%] top-[85%] w-1.5 h-1.5 rounded-full bg-cyan-200/50 animate-twinkle delay-600" />
        <span className="absolute left-[30%] top-[88%] w-1 h-1 rounded-full bg-purple-200/50 animate-twinkle delay-100" />
      </div>

      <FloatingNav
        onNavigate={handleNav}
        onGetStarted={onGetStarted}
        isLoggedIn={isLoggedIn}
        userName={userName}
      />

      <main className="relative z-10">
        <HeroSection onStartJourney={onGetStarted} onExplorePaths={() => onNavigate("roadmap")} />

        <FeatureSection onNavigate={handleFeatureNav} />

        {/* How it works — minimal strip */}
        <section className="relative py-20 px-4 sm:px-6 lg:px-8 border-t border-white/5">
          <div className="max-w-7xl mx-auto">
            <div className="text-center mb-12">
              <p className="text-[11px] font-bold tracking-[0.28em] uppercase text-purple-400 mb-3">
                How It Works
              </p>
              <h2 className="text-2xl sm:text-4xl font-extrabold tracking-tight text-white">
                From skill gap to career-ready
              </h2>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
              {[
                {
                  step: "01",
                  icon: Radar,
                  title: "Assess",
                  text: "AI analyzes your current skills and maps them against industry requirements.",
                },
                {
                  step: "02",
                  icon: Map,
                  title: "Plan",
                  text: "Get a personalized 5-phase roadmap with courses, projects, and assessments.",
                },
                {
                  step: "03",
                  icon: TrendingUp,
                  title: "Grow",
                  text: "Track progress, validate skills with quizzes, and adapt with your AI Mentor.",
                },
              ].map((item, idx) => {
                const Icon = item.icon;
                return (
                  <div
                    key={item.step}
                    className="relative p-7 rounded-3xl bg-white/[0.03] border border-white/10 backdrop-blur-xl hover:border-cyan-400/30 hover:bg-white/[0.05] transition-all duration-500 hover:-translate-y-1.5 animate-fade-up"
                    style={{ animationDelay: `${idx * 140}ms` }}
                  >
                    <span className="text-5xl font-extrabold text-white/[0.07] absolute top-4 right-6 select-none">
                      {item.step}
                    </span>
                    <div className="w-11 h-11 rounded-xl bg-gradient-to-tr from-cyan-500/20 to-purple-500/20 border border-white/10 flex items-center justify-center mb-5">
                      <Icon className="w-5 h-5 text-cyan-300" />
                    </div>
                    <h3 className="text-base font-bold text-white mb-2">{item.title}</h3>
                    <p className="text-sm text-slate-400 leading-relaxed font-light">{item.text}</p>
                  </div>
                );
              })}
            </div>
          </div>
        </section>

        {/* Final CTA */}
        <section className="relative py-24 px-4 sm:px-6 lg:px-8">
          <div className="absolute inset-0 pointer-events-none" aria-hidden="true">
            <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-[560px] h-[360px] bg-purple-600/15 blur-[110px] rounded-full" />
          </div>
          <div className="relative max-w-3xl mx-auto text-center p-10 sm:p-14 rounded-[32px] bg-white/[0.03] border border-white/10 backdrop-blur-2xl shadow-[0_0_60px_rgba(99,102,241,0.12)]">
            <div className="w-14 h-14 mx-auto rounded-2xl bg-gradient-to-tr from-cyan-400 via-blue-600 to-purple-600 flex items-center justify-center shadow-[0_0_30px_rgba(56,189,248,0.4)] mb-6 animate-float">
              <Bot className="w-7 h-7 text-white" />
            </div>
            <h2 className="text-3xl sm:text-4xl font-extrabold tracking-tight text-white leading-tight">
              Ready to build your path?
            </h2>
            <p className="mt-4 text-slate-400 font-light leading-relaxed max-w-xl mx-auto">
              Join thousands of learners discovering their potential with intelligent AI guidance.
              Your future starts with a single skill.
            </p>
            <div className="mt-8 flex flex-col sm:flex-row items-center justify-center gap-3">
              <button
                onClick={onGetStarted}
                className="group w-full sm:w-auto inline-flex items-center justify-center gap-2 px-8 py-4 rounded-full bg-white text-black font-bold text-sm shadow-[0_0_32px_rgba(255,255,255,0.5)] hover:shadow-[0_0_48px_rgba(255,255,255,0.75)] hover:scale-[1.03] active:scale-95 transition-all"
              >
                <span>{isLoggedIn ? "Open Your Dashboard" : "Start Your Journey"}</span>
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </button>
              <button
                onClick={() => onNavigate("mentor")}
                className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-8 py-4 rounded-full bg-white/5 hover:bg-white/10 border border-white/15 text-white font-semibold text-sm backdrop-blur-md transition-all"
              >
                <Sparkles className="w-4 h-4 text-purple-400" />
                <span>Talk to AI Mentor</span>
              </button>
            </div>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="relative z-10 border-t border-white/10 bg-black/60 backdrop-blur-xl px-4 sm:px-6 lg:px-8 py-10">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-5">
          <div className="flex items-center gap-2.5">
            <span className="w-8 h-8 rounded-lg bg-gradient-to-tr from-cyan-400 via-blue-600 to-purple-600 flex items-center justify-center">
              <Sparkles className="w-4 h-4 text-white" />
            </span>
            <span className="font-bold text-white tracking-tight">
              SkillPath <span className="text-cyan-400">AI</span>
            </span>
          </div>
          <nav className="flex flex-wrap items-center justify-center gap-x-6 gap-y-2 text-xs text-slate-400">
            <button onClick={() => handleNav("home")} className="hover:text-white transition-colors">Home</button>
            <button onClick={() => onNavigate("skills")} className="hover:text-white transition-colors">Explore Skills</button>
            <button onClick={() => onNavigate("roadmap")} className="hover:text-white transition-colors">Learning Paths</button>
            <button onClick={() => onNavigate("mentor")} className="hover:text-white transition-colors">AI Mentor</button>
            <button onClick={() => onNavigate("dashboard")} className="hover:text-white transition-colors">Dashboard</button>
          </nav>
          <p className="text-[11px] text-slate-500">© 2026 SkillPath AI. Your Future. Your Skills. Your Path.</p>
        </div>
      </footer>
    </div>
  );
};
