"use client";

import React, { useEffect, useRef } from "react";

interface Point3D {
  x: number;
  y: number;
  z: number;
  size: number;
  hue: number; // 0 = white, 1 = electric blue, 2 = purple
  pulse: number;
}

export const ConstellationSphere: React.FC<{ className?: string }> = ({ className = "" }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const mouseRef = useRef({ x: 0, y: 0, targetX: 0, targetY: 0, active: false });

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let animationId: number;
    let width = 0;
    let height = 0;
    let dpr = Math.min(window.devicePixelRatio || 1, 2);

    const resize = () => {
      const rect = canvas.getBoundingClientRect();
      width = rect.width;
      height = rect.height;
      canvas.width = width * dpr;
      canvas.height = height * dpr;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    };
    resize();
    window.addEventListener("resize", resize);

    // Generate points on a sphere using Fibonacci distribution + random inner stars
    const points: Point3D[] = [];
    const N = 110;
    const goldenAngle = Math.PI * (3 - Math.sqrt(5));
    for (let i = 0; i < N; i++) {
      const y = 1 - (i / (N - 1)) * 2;
      const radius = Math.sqrt(1 - y * y);
      const theta = goldenAngle * i;
      const r = 0.82 + Math.random() * 0.18;
      points.push({
        x: Math.cos(theta) * radius * r,
        y: y * r,
        z: Math.sin(theta) * radius * r,
        size: 0.8 + Math.random() * 1.6,
        hue: Math.random() < 0.45 ? 0 : Math.random() < 0.6 ? 1 : 2,
        pulse: Math.random() * Math.PI * 2,
      });
    }
    // Extra inner glow points
    for (let i = 0; i < 35; i++) {
      points.push({
        x: (Math.random() - 0.5) * 1.1,
        y: (Math.random() - 0.5) * 1.1,
        z: (Math.random() - 0.5) * 1.1,
        size: 0.5 + Math.random() * 0.9,
        hue: Math.random() < 0.5 ? 1 : 2,
        pulse: Math.random() * Math.PI * 2,
      });
    }

    let rotY = 0;
    let rotX = 0.35;
    let time = 0;

    const onMouseMove = (e: MouseEvent) => {
      const rect = canvas.getBoundingClientRect();
      mouseRef.current.targetX = ((e.clientX - rect.left) / rect.width - 0.5) * 2;
      mouseRef.current.targetY = ((e.clientY - rect.top) / rect.height - 0.5) * 2;
      mouseRef.current.active = true;
    };
    const onMouseLeave = () => {
      mouseRef.current.targetX = 0;
      mouseRef.current.targetY = 0;
      mouseRef.current.active = false;
    };
    window.addEventListener("mousemove", onMouseMove);
    window.addEventListener("mouseleave", onMouseLeave);

    const draw = () => {
      time += 0.008;
      // Smooth mouse influence
      mouseRef.current.x += (mouseRef.current.targetX - mouseRef.current.x) * 0.04;
      mouseRef.current.y += (mouseRef.current.targetY - mouseRef.current.y) * 0.04;

      ctx.clearRect(0, 0, width, height);

      const cx = width / 2;
      const cy = height / 2;
      const sphereR = Math.min(width, height) * 0.36;

      rotY += 0.0035 + Math.abs(mouseRef.current.x) * 0.004;
      rotX += ((0.35 + mouseRef.current.y * 0.35) - rotX) * 0.05;

      const cosY = Math.cos(rotY);
      const sinY = Math.sin(rotY);
      const cosX = Math.cos(rotX);
      const sinX = Math.sin(rotX);

      // Project points
      const projected = points.map((p) => {
        // Rotate around Y
        let x = p.x * cosY - p.z * sinY;
        let z = p.x * sinY + p.z * cosY;
        let y = p.y;
        // Rotate around X
        let y2 = y * cosX - z * sinX;
        let z2 = y * sinX + z * cosX;
        const scale = 1 / (1.6 - z2 * 0.55);
        return {
          sx: cx + x * sphereR * scale,
          sy: cy + y2 * sphereR * scale,
          z: z2,
          scale,
          size: p.size,
          hue: p.hue,
          pulse: p.pulse + time * 2,
        };
      });

      // Draw orbit rings (ellipses)
      ctx.save();
      ctx.translate(cx, cy);
      ctx.rotate(-0.35);
      for (let i = 0; i < 2; i++) {
        ctx.beginPath();
        ctx.ellipse(0, 0, sphereR * (1.35 + i * 0.18), sphereR * (0.42 + i * 0.06), 0, 0, Math.PI * 2);
        ctx.strokeStyle = i === 0 ? "rgba(56,189,248,0.14)" : "rgba(168,85,247,0.10)";
        ctx.lineWidth = 1;
        ctx.stroke();
      }
      ctx.restore();

      // Draw connections between close points (constellation lines)
      for (let i = 0; i < projected.length; i++) {
        for (let j = i + 1; j < projected.length; j++) {
          const a = projected[i];
          const b = projected[j];
          const dx = a.sx - b.sx;
          const dy = a.sy - b.sy;
          const dist = Math.sqrt(dx * dx + dy * dy);
          const threshold = sphereR * 0.32;
          if (dist < threshold && a.z > -0.2 && b.z > -0.2) {
            const alpha = (1 - dist / threshold) * 0.28 * Math.min(a.scale, b.scale);
            ctx.beginPath();
            ctx.moveTo(a.sx, a.sy);
            ctx.lineTo(b.sx, b.sy);
            ctx.strokeStyle = `rgba(125,211,252,${alpha})`;
            ctx.lineWidth = 0.6;
            ctx.stroke();
          }
        }
      }

      // Draw points with glow
      const sorted = [...projected].sort((a, b) => a.z - b.z);
      for (const p of sorted) {
        const depth = (p.z + 1.4) / 2.4; // 0 back, 1 front
        const twinkle = 0.65 + Math.sin(p.pulse) * 0.35;
        const r = p.size * p.scale * (0.7 + depth * 0.6) * twinkle;
        let color: string;
        let glow: string;
        if (p.hue === 0) {
          color = `rgba(255,255,255,${0.55 + depth * 0.45})`;
          glow = "rgba(255,255,255,0.5)";
        } else if (p.hue === 1) {
          color = `rgba(56,189,248,${0.6 + depth * 0.4})`;
          glow = "rgba(56,189,248,0.6)";
        } else {
          color = `rgba(192,132,252,${0.6 + depth * 0.4})`;
          glow = "rgba(192,132,252,0.6)";
        }
        // Glow halo
        const grad = ctx.createRadialGradient(p.sx, p.sy, 0, p.sx, p.sy, r * 4);
        grad.addColorStop(0, glow);
        grad.addColorStop(1, "rgba(0,0,0,0)");
        ctx.fillStyle = grad;
        ctx.beginPath();
        ctx.arc(p.sx, p.sy, r * 4, 0, Math.PI * 2);
        ctx.fill();
        // Core
        ctx.fillStyle = color;
        ctx.beginPath();
        ctx.arc(p.sx, p.sy, Math.max(r, 0.6), 0, Math.PI * 2);
        ctx.fill();
      }

      // Center core glow
      const coreGrad = ctx.createRadialGradient(cx, cy, 0, cx, cy, sphereR * 0.55);
      coreGrad.addColorStop(0, "rgba(56,189,248,0.10)");
      coreGrad.addColorStop(0.6, "rgba(99,102,241,0.05)");
      coreGrad.addColorStop(1, "rgba(0,0,0,0)");
      ctx.fillStyle = coreGrad;
      ctx.beginPath();
      ctx.arc(cx, cy, sphereR * 0.55, 0, Math.PI * 2);
      ctx.fill();

      animationId = requestAnimationFrame(draw);
    };

    animationId = requestAnimationFrame(draw);

    return () => {
      cancelAnimationFrame(animationId);
      window.removeEventListener("resize", resize);
      window.removeEventListener("mousemove", onMouseMove);
      window.removeEventListener("mouseleave", onMouseLeave);
    };
  }, []);

  return <canvas ref={canvasRef} className={`w-full h-full block ${className}`} aria-hidden="true" />;
};
