"use client";

import React from "react";
import { ArrowRight, Map, ChevronDown, Sparkles } from "lucide-react";
import { ConstellationSphere } from "./ConstellationSphere";

interface HeroSectionProps {
  onStartJourney: () => void;
  onExplorePaths: () => void;
}

export const HeroSection: React.FC<HeroSectionProps> = ({ onStartJourney, onExplorePaths }) => {
  return (
    <section className="relative min-h-[100svh] flex flex-col items-center justify-center overflow-hidden px-4 pt-28 pb-16">
      {/* Ambient glows */}
      <div className="absolute inset-0 pointer-events-none" aria-hidden="true">
        <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-[720px] h-[720px] rounded-full bg-blue-600/15 blur-[120px]" />
        <div className="absolute left-[15%] top-[20%] w-72 h-72 rounded-full bg-cyan-500/10 blur-[80px] animate-float-slow" />
        <div className="absolute right-[12%] top-[30%] w-80 h-80 rounded-full bg-purple-600/10 blur-[90px] animate-float-slow" />
        {/* Floating twinkles */}
        <span className="absolute left-[18%] top-[28%] w-1.5 h-1.5 rounded-full bg-white animate-twinkle" />
        <span className="absolute left-[78%] top-[22%] w-1 h-1 rounded-full bg-cyan-300 animate-twinkle delay-300" />
        <span className="absolute left-[70%] top-[68%] w-1.5 h-1.5 rounded-full bg-purple-300 animate-twinkle delay-500" />
        <span className="absolute left-[24%] top-[72%] w-1 h-1 rounded-full bg-white animate-twinkle delay-700" />
        <span className="absolute left-[50%] top-[14%] w-1 h-1 rounded-full bg-cyan-200 animate-twinkle delay-200" />
      </div>

      {/* Constellation Sphere — centered behind text */}
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none" aria-hidden="true">
        <div className="w-[min(92vw,760px)] h-[min(92vw,760px)] max-h-[78vh] opacity-90">
          <ConstellationSphere />
        </div>
      </div>

      {/* Content */}
      <div className="relative z-10 text-center max-w-4xl mx-auto">
        <div className="animate-fade-up inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-white/5 border border-white/10 backdrop-blur-md text-[11px] font-semibold tracking-[0.18em] uppercase text-cyan-300 mb-7">
          <Sparkles className="w-3.5 h-3.5" />
          <span>Agentic AI Learning Platform</span>
          <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-pulse" />
        </div>

        <h1 className="animate-fade-up delay-100 text-[42px] leading-[1.05] sm:text-6xl lg:text-7xl font-extrabold tracking-tight text-white">
          Your Future.{" "}
          <span className="text-shimmer">Your Skills.</span>
          <br />
          <span className="bg-gradient-to-r from-cyan-300 via-blue-400 to-purple-400 bg-clip-text text-transparent">
            Your Path.
          </span>
        </h1>

        <p className="animate-fade-up delay-300 mt-6 text-base sm:text-lg text-slate-300/90 leading-relaxed max-w-2xl mx-auto font-light">
          Discover your potential, develop future-ready skills, and build your career with
          intelligent AI guidance.
        </p>

        <div className="animate-fade-up delay-500 mt-9 flex flex-col sm:flex-row items-center justify-center gap-3.5">
          <button
            onClick={onStartJourney}
            className="group w-full sm:w-auto inline-flex items-center justify-center gap-2 px-8 py-4 rounded-full bg-white text-black font-bold text-sm shadow-[0_0_32px_rgba(255,255,255,0.5)] hover:shadow-[0_0_48px_rgba(255,255,255,0.75)] hover:scale-[1.03] active:scale-95 transition-all"
          >
            <span>Start Your Journey</span>
            <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
          </button>
          <button
            onClick={onExplorePaths}
            className="group w-full sm:w-auto inline-flex items-center justify-center gap-2 px-8 py-4 rounded-full bg-white/5 hover:bg-white/10 border border-white/15 hover:border-cyan-400/50 text-white font-semibold text-sm backdrop-blur-md transition-all hover:shadow-[0_0_28px_rgba(56,189,248,0.25)]"
          >
            <Map className="w-4 h-4 text-cyan-400" />
            <span>Explore Learning Paths</span>
          </button>
        </div>

        <div className="animate-fade-up delay-700 mt-10 flex flex-wrap items-center justify-center gap-x-6 gap-y-2 text-[11px] text-slate-400">
          <span className="flex items-center gap-1.5">
            <span className="w-1.5 h-1.5 rounded-full bg-cyan-400" /> 6 Specialized AI Agents
          </span>
          <span className="flex items-center gap-1.5">
            <span className="w-1.5 h-1.5 rounded-full bg-purple-400" /> 7 Career Paths
          </span>
          <span className="flex items-center gap-1.5">
            <span className="w-1.5 h-1.5 rounded-full bg-white" /> Personalized Roadmaps
          </span>
        </div>
      </div>

      {/* Scroll hint */}
      <a
        href="#features"
        className="absolute bottom-6 left-1/2 -translate-x-1/2 z-10 flex flex-col items-center gap-1 text-slate-500 hover:text-slate-300 transition-colors"
        aria-label="Scroll to features"
      >
        <span className="text-[10px] tracking-[0.25em] uppercase">Scroll</span>
        <ChevronDown className="w-4 h-4 animate-scroll-hint" />
      </a>
    </section>
  );
};
