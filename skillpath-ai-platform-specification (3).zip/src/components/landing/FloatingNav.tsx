"use client";

import React, { useState, useEffect } from "react";
import { Sparkles, Menu, X, ArrowRight } from "lucide-react";

interface FloatingNavProps {
  onNavigate: (target: "home" | "skills" | "roadmap" | "mentor" | "dashboard") => void;
  onGetStarted: () => void;
  isLoggedIn: boolean;
  userName?: string;
}

export const FloatingNav: React.FC<FloatingNavProps> = ({
  onNavigate,
  onGetStarted,
  isLoggedIn,
  userName,
}) => {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const items: { label: string; target: "home" | "skills" | "roadmap" | "mentor" | "dashboard" }[] = [
    { label: "Home", target: "home" },
    { label: "Explore Skills", target: "skills" },
    { label: "Learning Paths", target: "roadmap" },
    { label: "AI Mentor", target: "mentor" },
    { label: "Dashboard", target: "dashboard" },
  ];

  const handleClick = (target: "home" | "skills" | "roadmap" | "mentor" | "dashboard") => {
    setMobileOpen(false);
    onNavigate(target);
  };

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
        scrolled
          ? "bg-black/70 backdrop-blur-xl border-b border-white/10 shadow-[0_8px_40px_rgba(0,0,0,0.6)]"
          : "bg-transparent border-b border-transparent"
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 sm:h-[72px]">
          {/* Logo */}
          <button
            onClick={() => handleClick("home")}
            className="flex items-center gap-2.5 group shrink-0"
            aria-label="SkillPath AI Home"
          >
            <span className="relative w-9 h-9 rounded-xl bg-gradient-to-tr from-cyan-400 via-blue-600 to-purple-600 flex items-center justify-center shadow-[0_0_20px_rgba(56,189,248,0.45)] group-hover:shadow-[0_0_28px_rgba(56,189,248,0.7)] transition-shadow">
              <Sparkles className="w-5 h-5 text-white" />
              <span className="absolute -top-1 -right-1 w-2.5 h-2.5 rounded-full bg-white animate-twinkle" />
            </span>
            <span className="text-left leading-none">
              <span className="block font-bold text-white tracking-tight text-[15px] sm:text-base">
                SkillPath <span className="text-cyan-400">AI</span>
              </span>
              <span className="block text-[9px] tracking-[0.22em] uppercase text-slate-400 mt-0.5">
                Future-Ready Skills
              </span>
            </span>
          </button>

          {/* Desktop Nav */}
          <nav className="hidden md:flex items-center gap-1 lg:gap-2">
            {items.map((item) => (
              <button
                key={item.label}
                onClick={() => handleClick(item.target)}
                className="px-3.5 lg:px-4 py-2 rounded-full text-[13px] font-medium text-slate-300 hover:text-white hover:bg-white/10 transition-all"
              >
                {item.label}
              </button>
            ))}
          </nav>

          <div className="flex items-center gap-2.5">
            {isLoggedIn && userName && (
              <span className="hidden sm:inline-flex items-center gap-1.5 text-xs text-slate-300 bg-white/5 border border-white/10 rounded-full px-3 py-1.5">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                {userName}
              </span>
            )}
            <button
              onClick={onGetStarted}
              className="hidden sm:inline-flex items-center gap-1.5 px-5 py-2.5 rounded-full bg-white text-black text-[13px] font-bold shadow-[0_0_24px_rgba(255,255,255,0.45)] hover:shadow-[0_0_36px_rgba(255,255,255,0.7)] hover:scale-[1.03] active:scale-95 transition-all"
            >
              <span>{isLoggedIn ? "Open Dashboard" : "Get Started"}</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={() => setMobileOpen(!mobileOpen)}
              className="md:hidden p-2 rounded-xl bg-white/5 border border-white/10 text-white"
              aria-label="Toggle menu"
            >
              {mobileOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      {mobileOpen && (
        <div className="md:hidden bg-black/90 backdrop-blur-xl border-t border-white/10 px-4 py-4 space-y-1 animate-fade-in">
          {items.map((item) => (
            <button
              key={item.label}
              onClick={() => handleClick(item.target)}
              className="w-full text-left px-4 py-3 rounded-xl text-sm font-medium text-slate-200 hover:bg-white/10 transition-colors"
            >
              {item.label}
            </button>
          ))}
          <button
            onClick={() => {
              setMobileOpen(false);
              onGetStarted();
            }}
            className="w-full mt-2 px-4 py-3 rounded-xl bg-white text-black text-sm font-bold flex items-center justify-center gap-2 shadow-[0_0_20px_rgba(255,255,255,0.4)]"
          >
            <span>{isLoggedIn ? "Open Dashboard" : "Get Started"}</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      )}
    </header>
  );
};
