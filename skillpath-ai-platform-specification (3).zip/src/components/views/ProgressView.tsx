"use client";

import React, { useState, useEffect } from "react";
import {
  TrendingUp,
  Award,
  CheckCircle2,
  Clock,
  Layers,
  Sparkles,
  BarChart3,
  Calendar,
  RefreshCw,
  BookOpen,
} from "lucide-react";
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  LineChart,
  Line,
  CartesianGrid,
  AreaChart,
  Area,
} from "recharts";

export const ProgressView: React.FC = () => {
  const [loading, setLoading] = useState(true);
  const [data, setData] = useState<any>(null);

  const fetchProgress = async () => {
    try {
      setLoading(true);
      const res = await fetch("/api/progress");
      if (res.ok) {
        const json = await res.json();
        setData(json);
      }
    } catch (e) {
      console.error("Error loading progress:", e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchProgress();
  }, []);

  if (loading) {
    return (
      <div className="p-12 text-center text-slate-400">
        <RefreshCw className="w-6 h-6 mx-auto animate-spin mb-3 text-cyan-400" />
        <p className="text-sm">Aggregating learning telemetry & progress metrics...</p>
      </div>
    );
  }

  const { progress, skills, targetCareer, totalTasksCount, completedTasksCount, recentAssessments } = data || {};

  const readinessTrajectory = [
    { period: "Week 1", readiness: 20 },
    { period: "Week 2", readiness: 28 },
    { period: "Week 3", readiness: 32 },
    { period: "Week 4", readiness: progress?.careerReadiness || 38 },
  ];

  return (
    <div className="space-y-6 pb-12">
      {/* Header Banner */}
      <div className="glass-panel rounded-2xl p-6 border border-white/10 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-cyan-500/20 flex items-center justify-center text-cyan-400">
              <TrendingUp className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white flex items-center gap-2">
                Learning Progress & Trajectory Analytics
                <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
                  Continuous Telemetry
                </span>
              </h2>
              <p className="text-xs text-slate-400">
                Target Role: <span className="font-semibold text-white">{targetCareer}</span> • Live database synchronization
              </p>
            </div>
          </div>
        </div>

        <button
          onClick={fetchProgress}
          className="p-2 text-slate-400 hover:text-white rounded-lg hover:bg-white/5 transition-colors"
          title="Refresh progress data"
        >
          <RefreshCw className="w-4 h-4" />
        </button>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="glass-panel rounded-2xl p-5 border border-white/10">
          <span className="text-xs text-slate-400 block mb-1">Career Readiness</span>
          <span className="text-3xl font-extrabold text-cyan-400">{progress?.careerReadiness}%</span>
          <span className="text-[11px] text-emerald-400 block mt-1">+18% over 4 weeks</span>
        </div>

        <div className="glass-panel rounded-2xl p-5 border border-white/10">
          <span className="text-xs text-slate-400 block mb-1">Roadmap Tasks Done</span>
          <span className="text-3xl font-extrabold text-white">
            {completedTasksCount} / {totalTasksCount}
          </span>
          <span className="text-[11px] text-slate-400 block mt-1">
            {progress?.roadmapCompletionPct}% of total syllabus
          </span>
        </div>

        <div className="glass-panel rounded-2xl p-5 border border-white/10">
          <span className="text-xs text-slate-400 block mb-1">Acquired Skills</span>
          <span className="text-3xl font-extrabold text-indigo-400">{skills?.length || 3}</span>
          <span className="text-[11px] text-slate-400 block mt-1">Verified competencies</span>
        </div>

        <div className="glass-panel rounded-2xl p-5 border border-white/10">
          <span className="text-xs text-slate-400 block mb-1">Quizzes Completed</span>
          <span className="text-3xl font-extrabold text-purple-400">
            {recentAssessments?.length || 1}
          </span>
          <span className="text-[11px] text-emerald-400 block mt-1">
            Avg Score: {recentAssessments?.[0]?.percentage ?? 85}%
          </span>
        </div>
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Weekly Hours Bar Chart */}
        <div className="glass-panel rounded-2xl p-6 border border-white/10 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Calendar className="w-4 h-4 text-cyan-400" />
              Weekly Learning Hours
            </h3>
            <span className="text-xs text-slate-400">Total: 19.5h</span>
          </div>

          <div className="h-56 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={progress?.weeklyHours || []}>
                <XAxis dataKey="day" stroke="#64748b" fontSize={11} tickLine={false} />
                <YAxis stroke="#64748b" fontSize={11} tickLine={false} axisLine={false} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: "#0f172a",
                    borderColor: "rgba(255,255,255,0.1)",
                    borderRadius: "8px",
                    fontSize: "11px",
                  }}
                />
                <Bar dataKey="hours" fill="#06b6d4" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Readiness Trajectory Area Chart */}
        <div className="glass-panel rounded-2xl p-6 border border-white/10 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-purple-400" />
              Career Readiness Growth
            </h3>
            <span className="text-xs text-emerald-400 font-semibold">+18% growth</span>
          </div>

          <div className="h-56 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={readinessTrajectory}>
                <defs>
                  <linearGradient id="readinessGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#8b5cf6" stopOpacity={0.4} />
                    <stop offset="95%" stopColor="#8b5cf6" stopOpacity={0.0} />
                  </linearGradient>
                </defs>
                <XAxis dataKey="period" stroke="#64748b" fontSize={11} tickLine={false} />
                <YAxis stroke="#64748b" fontSize={11} domain={[0, 100]} tickLine={false} axisLine={false} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: "#0f172a",
                    borderColor: "rgba(255,255,255,0.1)",
                    borderRadius: "8px",
                    fontSize: "11px",
                  }}
                />
                <Area
                  type="monotone"
                  dataKey="readiness"
                  stroke="#a855f7"
                  strokeWidth={2}
                  fillOpacity={1}
                  fill="url(#readinessGrad)"
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Skills Matrix & Recent Quizzes */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Acquired Skills Proficiency */}
        <div className="glass-panel rounded-2xl p-6 border border-white/10 space-y-3">
          <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
            <Award className="w-4 h-4 text-indigo-400" />
            Verified Skills Matrix
          </h3>

          <div className="space-y-3">
            {skills?.map((s: any) => (
              <div key={s.skillName} className="p-3 rounded-xl bg-slate-900/60 border border-white/5 space-y-1.5">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-bold text-white flex items-center gap-1.5">
                    {s.skillName}
                    {s.verified && (
                      <span title="Verified">
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                      </span>
                    )}
                  </span>
                  <span className="text-cyan-400 font-semibold">
                    {s.proficiencyLevel} ({s.score}%)
                  </span>
                </div>
                <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                  <div
                    className="bg-gradient-to-r from-cyan-400 to-indigo-500 h-full rounded-full"
                    style={{ width: `${s.score}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Assessment Log */}
        <div className="glass-panel rounded-2xl p-6 border border-white/10 space-y-3">
          <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            Recent Assessment History
          </h3>

          <div className="space-y-2.5">
            {recentAssessments?.length > 0 ? (
              recentAssessments.map((r: any) => (
                <div
                  key={r.id}
                  className="p-3.5 rounded-xl bg-slate-900/60 border border-white/5 flex items-center justify-between text-xs"
                >
                  <div>
                    <div className="font-bold text-white">{r.assessmentTitle}</div>
                    <div className="text-[11px] text-slate-400 mt-0.5">
                      {new Date(r.createdAt).toLocaleDateString()}
                    </div>
                  </div>
                  <span
                    className={`font-bold px-2 py-0.5 rounded border ${
                      r.passed
                        ? "bg-emerald-500/20 text-emerald-300 border-emerald-500/30"
                        : "bg-rose-500/20 text-rose-300 border-rose-500/30"
                    }`}
                  >
                    {r.percentage}% {r.passed ? "Passed" : "Retake"}
                  </span>
                </div>
              ))
            ) : (
              <div className="p-4 rounded-xl bg-slate-900/40 text-slate-400 text-xs text-center">
                No recent assessments taken yet.
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
