"use client";

import React, { useState, useEffect } from "react";
import {
  Settings,
  Key,
  Cpu,
  ShieldCheck,
  RefreshCw,
  Sparkles,
  Check,
  AlertCircle,
  Database,
  Eye,
  EyeOff,
  Video,
} from "lucide-react";

interface SettingsViewProps {
  onSettingsChanged?: () => void;
}

export const SettingsView: React.FC<SettingsViewProps> = ({ onSettingsChanged }) => {
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [resetting, setResetting] = useState(false);
  const [settings, setSettings] = useState<any>({});
  const [geminiKeyInput, setGeminiKeyInput] = useState("");
  const [youtubeKeyInput, setYoutubeKeyInput] = useState("");
  const [preferredModel, setPreferredModel] = useState("gemini-1.5-flash");
  const [demoModeOverride, setDemoModeOverride] = useState(false);
  const [showKey, setShowKey] = useState(false);
  const [message, setMessage] = useState<{ type: "success" | "error"; text: string } | null>(null);

  const fetchSettings = async () => {
    try {
      setLoading(true);
      const res = await fetch("/api/settings");
      if (res.ok) {
        const data = await res.json();
        setSettings(data);
        setPreferredModel(data.preferredModel || "gemini-1.5-flash");
        setDemoModeOverride(Boolean(data.demoModeOverride));
      }
    } catch (e) {
      console.error("Error loading settings:", e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchSettings();
  }, []);

  const handleSaveSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    setMessage(null);
    try {
      const payload: any = {
        preferredModel,
        demoModeOverride,
      };
      if (geminiKeyInput.trim()) {
        payload.geminiApiKey = geminiKeyInput.trim();
      }
      if (youtubeKeyInput.trim()) {
        payload.youtubeApiKey = youtubeKeyInput.trim();
      }

      const res = await fetch("/api/settings", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      if (!res.ok) throw new Error("Failed to save settings");

      setMessage({ type: "success", text: "Settings saved successfully!" });
      setGeminiKeyInput("");
      setYoutubeKeyInput("");
      await fetchSettings();
      if (onSettingsChanged) onSettingsChanged();
    } catch (err: any) {
      setMessage({ type: "error", text: err.message || "Error saving configuration" });
    } finally {
      setSaving(false);
    }
  };

  const handleResetDemoData = async () => {
    if (!confirm("Are you sure you want to reset all demo profiles, skills, and roadmaps to baseline state?")) {
      return;
    }
    setResetting(true);
    setMessage(null);
    try {
      const res = await fetch("/api/settings", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ resetSeed: true }),
      });
      if (!res.ok) throw new Error("Reset failed");
      setMessage({ type: "success", text: "Demo data reset successfully to baseline state." });
      if (onSettingsChanged) onSettingsChanged();
    } catch (err: any) {
      setMessage({ type: "error", text: err.message });
    } finally {
      setResetting(false);
    }
  };

  if (loading) {
    return (
      <div className="p-12 text-center text-slate-400">
        <RefreshCw className="w-6 h-6 mx-auto animate-spin mb-3 text-cyan-400" />
        <p className="text-sm">Loading platform configuration...</p>
      </div>
    );
  }

  return (
    <div className="max-w-3xl mx-auto space-y-6 pb-12">
      {/* Header Banner */}
      <div className="glass-panel rounded-2xl p-6 border border-white/10 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-cyan-500 to-indigo-600 flex items-center justify-center text-white shadow-md shadow-cyan-500/20">
            <Settings className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-base font-bold text-white flex items-center gap-2">
              Platform Configuration & AI Credentials
            </h2>
            <p className="text-xs text-slate-400">
              Manage external Gemini & YouTube API keys, model selections, and demo modes.
            </p>
          </div>
        </div>

        <span
          className={`text-xs font-bold px-3 py-1 rounded-full uppercase tracking-wider border ${
            settings.isDemoModeActive
              ? "bg-amber-500/20 text-amber-300 border-amber-500/30"
              : "bg-emerald-500/20 text-emerald-300 border-emerald-500/30"
          }`}
        >
          {settings.isDemoModeActive ? "Demo Mode Active" : "Live Gemini Active"}
        </span>
      </div>

      {message && (
        <div
          className={`p-4 rounded-xl text-xs flex items-center gap-2.5 ${
            message.type === "error"
              ? "bg-rose-500/10 text-rose-300 border border-rose-500/20"
              : "bg-emerald-500/10 text-emerald-300 border border-emerald-500/20"
          }`}
        >
          {message.type === "error" ? (
            <AlertCircle className="w-4 h-4 shrink-0" />
          ) : (
            <Check className="w-4 h-4 shrink-0" />
          )}
          <span>{message.text}</span>
        </div>
      )}

      <form onSubmit={handleSaveSettings} className="space-y-6">
        {/* Gemini API Key */}
        <div className="glass-panel rounded-2xl p-6 border border-white/10 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
              <Key className="w-4 h-4 text-cyan-400" />
              Google Gemini API Configuration
            </h3>
            <span className="text-[11px] text-slate-400">
              Status:{" "}
              <strong className={settings.hasGeminiKey ? "text-emerald-400" : "text-amber-400"}>
                {settings.hasGeminiKey ? "Configured" : "Not configured (Demo Mode Active)"}
              </strong>
            </span>
          </div>

          <p className="text-xs text-slate-400 leading-relaxed">
            SkillPath AI securely utilizes Google Gemini for skill analysis, career matching,
            curriculum generation, and mentoring. When no API key is provided, deterministic demo
            intelligence provides 100% reliable results for evaluation and live hackathon judging.
          </p>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              Google Gemini API Key
            </label>
            <div className="relative">
              <input
                type={showKey ? "text" : "password"}
                value={geminiKeyInput}
                onChange={(e) => setGeminiKeyInput(e.target.value)}
                placeholder={
                  settings.hasGeminiKey
                    ? `Current Key: ${settings.maskedGeminiKey || "••••••••"} (Enter new key to update)`
                    : "AIzaSy..."
                }
                className="w-full bg-slate-900 border border-white/10 rounded-xl px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500"
              />
              <button
                type="button"
                onClick={() => setShowKey(!showKey)}
                className="absolute right-3 top-2.5 text-slate-400 hover:text-white"
              >
                {showKey ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-1">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Gemini Model Preference
              </label>
              <select
                value={preferredModel}
                onChange={(e) => setPreferredModel(e.target.value)}
                className="w-full bg-slate-900 border border-white/10 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-500"
              >
                <option value="gemini-1.5-flash">Gemini 1.5 Flash (Fast, Low Latency)</option>
                <option value="gemini-1.5-pro">Gemini 1.5 Pro (Deep Reasoning)</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Demo Mode Override
              </label>
              <div className="flex items-center gap-3 pt-2">
                <input
                  type="checkbox"
                  id="demoToggle"
                  checked={demoModeOverride}
                  onChange={(e) => setDemoModeOverride(e.target.checked)}
                  className="w-4 h-4 rounded text-cyan-500 focus:ring-0 bg-slate-900 border-white/20"
                />
                <label htmlFor="demoToggle" className="text-xs text-slate-300 select-none cursor-pointer">
                  Force Deterministic Demo Mode
                </label>
              </div>
            </div>
          </div>
        </div>

        {/* YouTube API Configuration */}
        <div className="glass-panel rounded-2xl p-6 border border-white/10 space-y-4">
          <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
            <Video className="w-4 h-4 text-rose-400" />
            YouTube Data API v3 (Optional)
          </h3>

          <p className="text-xs text-slate-400 leading-relaxed">
            Used to query educational video tutorials on the fly. If omitted, the verified curated
            resource catalog is used automatically.
          </p>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              YouTube Data API Key
            </label>
            <input
              type="password"
              value={youtubeKeyInput}
              onChange={(e) => setYoutubeKeyInput(e.target.value)}
              placeholder={
                settings.hasYoutubeKey
                  ? "Configured (Enter new key to update)"
                  : "Optional YouTube API Key"
              }
              className="w-full bg-slate-900 border border-white/10 rounded-xl px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500"
            />
          </div>
        </div>

        {/* Database & Demo Reset */}
        <div className="glass-panel rounded-2xl p-6 border border-white/10 space-y-4">
          <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
            <Database className="w-4 h-4 text-purple-400" />
            Hackathon Demo State Management
          </h3>

          <p className="text-xs text-slate-400 leading-relaxed">
            Re-populates the database with the initial Alex profile (Python, SQL, HTML → Full Stack
            Developer target), 18 skills, 7 career paths, and fresh roadmap tasks.
          </p>

          <div className="pt-1">
            <button
              type="button"
              onClick={handleResetDemoData}
              disabled={resetting}
              className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-rose-300 border border-rose-500/30 text-xs font-bold transition-all flex items-center gap-2"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${resetting ? "animate-spin" : ""}`} />
              <span>{resetting ? "Resetting Demo State..." : "Reset All Seed Demo Data"}</span>
            </button>
          </div>
        </div>

        {/* Submit Button */}
        <div className="flex justify-end pt-2">
          <button
            type="submit"
            disabled={saving}
            className="px-6 py-2.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs shadow-lg shadow-cyan-500/20 active:scale-95 transition-all flex items-center gap-2 disabled:opacity-50"
          >
            <Check className="w-4 h-4" />
            <span>{saving ? "Saving Configuration..." : "Save Settings"}</span>
          </button>
        </div>
      </form>
    </div>
  );
};
