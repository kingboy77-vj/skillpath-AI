"use client";

import React, { useState, useEffect } from "react";
import {
  Radar as RadarIcon,
  Sparkles,
  Target,
  CheckCircle2,
  AlertTriangle,
  ArrowRight,
  RefreshCw,
  BarChart3,
  ShieldAlert,
  Zap,
} from "lucide-react";
import {
  ResponsiveContainer,
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  Radar,
  Tooltip,
} from "recharts";
import { NavTab } from "../layout/Sidebar";

interface SkillAnalysisViewProps {
  onNavigate: (tab: NavTab, meta?: any) => void;
}

export const SkillAnalysisView: React.FC<SkillAnalysisViewProps> = ({ onNavigate }) => {
  const [loading, setLoading] = useState(true);
  const [analyzing, setAnalyzing] = useState(false);
  const [targetCareer, setTargetCareer] = useState("full-stack-developer");
  const [analysis, setAnalysis] = useState<any>(null);
  const [careersList, setCareersList] = useState<any[]>([]);

  const fetchAnalysis = async (cId: string = targetCareer) => {
    try {
      setAnalyzing(true);
      const res = await fetch("/api/agents/analyze-skills", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ targetCareerId: cId }),
      });
      if (res.ok) {
        const data = await res.json();
        setAnalysis(data.analysis);
      }
    } catch (e) {
      console.error("Error analyzing skills:", e);
    } finally {
      setAnalyzing(false);
      setLoading(false);
    }
  };

  const loadCareers = async () => {
    try {
      const res = await fetch("/api/careers");
      if (res.ok) {
        const data = await res.json();
        setCareersList(data.careers || []);
        if (data.currentTargetCareerId) {
          setTargetCareer(data.currentTargetCareerId);
          fetchAnalysis(data.currentTargetCareerId);
          return;
        }
      }
    } catch (e) {
      console.error("Error loading careers:", e);
    }
    fetchAnalysis();
  };

  useEffect(() => {
    loadCareers();
  }, []);

  const handleCareerChange = (newCareerId: string) => {
    setTargetCareer(newCareerId);
    fetchAnalysis(newCareerId);
  };

  // Prepare radar chart data comparing learner's score vs required target score (100)
  const radarData = [
    { skill: "HTML/CSS", current: 55, required: 90 },
    { skill: "JavaScript", current: 30, required: 95 },
    { skill: "React", current: 20, required: 85 },
    { skill: "Node.js", current: 25, required: 85 },
    { skill: "SQL/DB", current: 70, required: 80 },
    { skill: "Git/VCS", current: 40, required: 80 },
    { skill: "REST APIs", current: 35, required: 85 },
    { skill: "Python", current: 75, required: 60 },
  ];

  const gapPct = analysis?.skillGapPercentage ?? 65;
  const readiness = Math.max(100 - gapPct, 25);

  return (
    <div className="space-y-6 pb-12">
      {/* Top Controller Bar */}
      <div className="glass-panel rounded-2xl p-6 border border-white/10 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-cyan-500/20 flex items-center justify-center text-cyan-400">
              <RadarIcon className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white flex items-center gap-2">
                Agent 1: Skill Analysis & Gap Detector
                <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
                  AI Evaluated
                </span>
              </h2>
              <p className="text-xs text-slate-400">
                Audits competencies, identifies strong vs weak skills, and calculates gap vectors.
              </p>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2">
            <span className="text-xs text-slate-400 font-medium">Evaluate Career:</span>
            <select
              value={targetCareer}
              onChange={(e) => handleCareerChange(e.target.value)}
              className="bg-slate-900 border border-white/10 rounded-xl px-3 py-1.5 text-xs text-white focus:outline-none focus:border-cyan-500 font-medium"
            >
              {careersList.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.title}
                </option>
              ))}
            </select>
          </div>

          <button
            onClick={() => fetchAnalysis(targetCareer)}
            disabled={analyzing}
            className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-cyan-400 border border-white/10 text-xs font-semibold flex items-center gap-1 transition-all disabled:opacity-50"
            title="Recalculate Gaps with AI"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${analyzing ? "animate-spin" : ""}`} />
            <span className="hidden sm:inline">Recalculate</span>
          </button>
        </div>
      </div>

      {/* Main Grid: Radar Chart & Readiness Stats */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Radar Chart Card */}
        <div className="lg:col-span-7 glass-panel rounded-2xl p-6 border border-white/10 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-2">
              <h3 className="font-bold text-sm text-white flex items-center gap-2">
                <Target className="w-4 h-4 text-cyan-400" />
                Technical Competency Radar
              </h3>
              <div className="flex items-center gap-3 text-[11px]">
                <span className="flex items-center gap-1 text-cyan-400">
                  <span className="w-2.5 h-2.5 rounded-full bg-cyan-400" /> Your Skills
                </span>
                <span className="flex items-center gap-1 text-purple-400">
                  <span className="w-2.5 h-2.5 rounded-full bg-purple-500" /> Market Target
                </span>
              </div>
            </div>
            <p className="text-xs text-slate-400 mb-4">
              Visualizes distance between your current demonstrated proficiency and industry expectations.
            </p>
          </div>

          <div className="h-72 w-full flex items-center justify-center">
            <ResponsiveContainer width="100%" height="100%">
              <RadarChart data={radarData}>
                <PolarGrid stroke="rgba(255, 255, 255, 0.1)" />
                <PolarAngleAxis
                  dataKey="skill"
                  tick={{ fill: "#94a3b8", fontSize: 11, fontWeight: 500 }}
                />
                <PolarRadiusAxis
                  angle={30}
                  domain={[0, 100]}
                  stroke="#475569"
                  tick={{ fill: "#64748b", fontSize: 9 }}
                />
                <Radar
                  name="Current Skills"
                  dataKey="current"
                  stroke="#22d3ee"
                  fill="#06b6d4"
                  fillOpacity={0.4}
                />
                <Radar
                  name="Market Target"
                  dataKey="required"
                  stroke="#a855f7"
                  fill="#a855f7"
                  fillOpacity={0.15}
                />
                <Tooltip
                  contentStyle={{
                    backgroundColor: "#0f172a",
                    borderColor: "rgba(255,255,255,0.1)",
                    borderRadius: "8px",
                    fontSize: "11px",
                  }}
                />
              </RadarChart>
            </ResponsiveContainer>
          </div>

          <div className="pt-3 border-t border-white/5 flex items-center justify-between text-xs text-slate-400">
            <span>Legend: Solid cyan is your validated footprint</span>
            <button
              onClick={() => onNavigate("roadmap")}
              className="text-cyan-400 hover:underline font-semibold flex items-center gap-1"
            >
              <span>Bridge Gaps in Roadmap</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Readiness & Gap Metrics Card */}
        <div className="lg:col-span-5 space-y-4">
          <div className="glass-panel rounded-2xl p-6 border border-white/10 space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
                Overall Career Readiness
              </span>
              <span className="text-xs px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 font-bold border border-cyan-500/30">
                {readiness}% Ready
              </span>
            </div>

            <div className="flex items-baseline gap-2">
              <span className="text-4xl font-extrabold text-white">{readiness}%</span>
              <span className="text-xs text-slate-400">
                (Gap: <span className="text-amber-400 font-bold">{gapPct}%</span>)
              </span>
            </div>

            <div className="w-full bg-slate-800 h-2.5 rounded-full overflow-hidden">
              <div
                className="bg-gradient-to-r from-cyan-500 to-indigo-600 h-full rounded-full transition-all duration-1000"
                style={{ width: `${readiness}%` }}
              />
            </div>

            <p className="text-xs text-slate-300 leading-relaxed bg-slate-900/60 p-3 rounded-xl border border-white/5">
              {analysis?.overallProficiencySummary ||
                "Learner possesses foundational competencies in Python and SQL. Highest-leverage opportunity lies in conquering asynchronous JavaScript, React components, and Node API pipelines."}
            </p>
          </div>

          {/* Quick Strengths & Weaknesses Panel */}
          <div className="glass-panel rounded-2xl p-5 border border-white/10 space-y-3">
            <h4 className="text-xs font-bold text-white uppercase tracking-wider">
              AI Diagnostic Breakdown
            </h4>

            <div className="space-y-2 text-xs">
              <div className="p-3 rounded-xl bg-emerald-950/20 border border-emerald-500/20">
                <div className="font-semibold text-emerald-400 flex items-center gap-1.5 mb-1">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>Identified Strengths</span>
                </div>
                <ul className="text-slate-300 text-[11px] space-y-0.5 list-disc list-inside">
                  {(analysis?.strengths || [
                    "Strong procedural logic via Python",
                    "Relational querying fundamentals with SQL",
                  ]).map((s: string, idx: number) => (
                    <li key={idx}>{s}</li>
                  ))}
                </ul>
              </div>

              <div className="p-3 rounded-xl bg-rose-950/20 border border-rose-500/20">
                <div className="font-semibold text-rose-400 flex items-center gap-1.5 mb-1">
                  <AlertTriangle className="w-3.5 h-3.5" />
                  <span>Deficiencies & Gaps</span>
                </div>
                <ul className="text-slate-300 text-[11px] space-y-0.5 list-disc list-inside">
                  {(analysis?.weaknesses || [
                    "Missing asynchronous JavaScript runtime mechanics",
                    "No modern frontend framework experience",
                  ]).map((w: string, idx: number) => (
                    <li key={idx}>{w}</li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Missing Skills vs Acquired Skills Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Missing Skills Grid */}
        <div className="glass-panel rounded-2xl p-6 border border-white/10 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-amber-400" />
              Missing Skills For Target Role
            </h3>
            <span className="text-xs font-bold px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30">
              {analysis?.missingSkills?.length || 6} to acquire
            </span>
          </div>

          <div className="space-y-2.5">
            {(analysis?.missingSkills || ["JavaScript", "CSS", "React", "Node.js", "Express.js", "Git", "REST APIs"]).map(
              (skill: string) => (
                <div
                  key={skill}
                  className="p-3 rounded-xl bg-slate-900/60 border border-white/5 flex items-center justify-between hover:border-amber-500/30 transition-colors"
                >
                  <div className="flex items-center gap-2.5">
                    <span className="w-2 h-2 rounded-full bg-amber-400" />
                    <span className="text-xs font-bold text-white">{skill}</span>
                  </div>
                  <button
                    onClick={() => onNavigate("resources")}
                    className="text-[11px] text-cyan-400 hover:text-cyan-300 font-medium flex items-center gap-1"
                  >
                    <span>View Courses</span>
                    <ArrowRight className="w-3 h-3" />
                  </button>
                </div>
              )
            )}
          </div>
        </div>

        {/* Existing Skills Progress Bars */}
        <div className="glass-panel rounded-2xl p-6 border border-white/10 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
              Current Skills & Proficiency Scores
            </h3>
            <span className="text-xs font-bold px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
              {analysis?.existingSkills?.length || 3} verified
            </span>
          </div>

          <div className="space-y-3">
            {(analysis?.existingSkills || [
              { name: "Python", proficiency: "Intermediate", score: 70 },
              { name: "SQL", proficiency: "Intermediate", score: 65 },
              { name: "HTML", proficiency: "Beginner", score: 40 },
            ]).map((s: any) => (
              <div key={s.name} className="p-3 rounded-xl bg-slate-900/60 border border-white/5 space-y-1.5">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-bold text-white">{s.name}</span>
                  <span className="text-cyan-400 font-semibold">
                    {s.proficiency} ({s.score}%)
                  </span>
                </div>
                <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                  <div
                    className="bg-gradient-to-r from-cyan-400 to-emerald-400 h-full rounded-full"
                    style={{ width: `${s.score}%` }}
                  />
                </div>
              </div>
            ))}
          </div>

          <div className="pt-2">
            <button
              onClick={() => onNavigate("assessments")}
              className="w-full py-2.5 rounded-xl bg-cyan-500/15 hover:bg-cyan-500/25 text-cyan-300 border border-cyan-500/30 text-xs font-bold transition-all text-center"
            >
              Take Skill Assessments to Validate & Increase Scores
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
