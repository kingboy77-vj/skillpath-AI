"use client";

import React, { useState, useEffect } from "react";
import {
  User,
  GraduationCap,
  Briefcase,
  Layers,
  Award,
  FolderGit2,
  Heart,
  Target,
  Sparkles,
  Save,
  Plus,
  Trash2,
  CheckCircle2,
  AlertCircle,
  RefreshCw,
} from "lucide-react";

interface ProfileViewProps {
  onProfileUpdated?: () => void;
}

export const ProfileView: React.FC<ProfileViewProps> = ({ onProfileUpdated }) => {
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [profile, setProfile] = useState<any>(null);
  const [userSkills, setUserSkills] = useState<any[]>([]);
  const [allSkills, setAllSkills] = useState<any[]>([]);
  const [message, setMessage] = useState<{ type: "success" | "error"; text: string } | null>(null);

  // New skill addition state
  const [newSkillName, setNewSkillName] = useState("");
  const [newSkillLevel, setNewSkillLevel] = useState("Intermediate");

  // New project addition state
  const [newProjectTitle, setNewProjectTitle] = useState("");
  const [newProjectDesc, setNewProjectDesc] = useState("");
  const [newProjectTech, setNewProjectTech] = useState("");
  const [showAddProject, setShowAddProject] = useState(false);

  // New certification state
  const [newCert, setNewCert] = useState("");

  const loadProfile = async () => {
    try {
      setLoading(true);
      const res = await fetch("/api/profile");
      if (res.ok) {
        const data = await res.json();
        setProfile(data.profile);
        setUserSkills(data.userSkills || []);
        setAllSkills(data.availableSkills || []);
      }
    } catch (e) {
      console.error("Error loading profile:", e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadProfile();
  }, []);

  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    setMessage(null);
    try {
      const res = await fetch("/api/profile", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          fullName: profile.fullName,
          educationLevel: profile.educationLevel,
          collegeOrOrg: profile.collegeOrOrg,
          certifications: profile.certifications,
          completedProjects: profile.completedProjects,
          workExperience: profile.workExperience,
          learningInterests: profile.learningInterests,
          targetCareerId: profile.targetCareerId,
          targetCareerName: profile.targetCareerName,
          preferredLearningStyle: profile.preferredLearningStyle,
          updatedSkills: userSkills,
        }),
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Save failed");

      setMessage({
        type: "success",
        text: "Profile updated and AI roadmap recalibrated with new competencies!",
      });
      if (onProfileUpdated) onProfileUpdated();
    } catch (err: any) {
      setMessage({ type: "error", text: err.message });
    } finally {
      setSaving(false);
    }
  };

  const handleAddSkill = () => {
    if (!newSkillName.trim()) return;
    const exists = userSkills.some(
      (s) => s.skillName.toLowerCase() === newSkillName.trim().toLowerCase()
    );
    if (exists) {
      setMessage({ type: "error", text: "Skill is already added to your profile." });
      return;
    }

    const defaultScore =
      newSkillLevel === "Expert" ? 90 :
      newSkillLevel === "Advanced" ? 80 :
      newSkillLevel === "Intermediate" ? 65 : 40;

    setUserSkills([
      ...userSkills,
      {
        skillName: newSkillName.trim(),
        proficiencyLevel: newSkillLevel,
        score: defaultScore,
        verified: false,
      },
    ]);
    setNewSkillName("");
  };

  const handleRemoveSkill = (skillName: string) => {
    setUserSkills(userSkills.filter((s) => s.skillName !== skillName));
  };

  const handleAddProject = () => {
    if (!newProjectTitle.trim()) return;
    const currentProjects = profile.completedProjects || [];
    const updated = [
      ...currentProjects,
      {
        title: newProjectTitle.trim(),
        description: newProjectDesc.trim(),
        tech: newProjectTech.split(",").map((t) => t.trim()).filter(Boolean),
      },
    ];
    setProfile({ ...profile, completedProjects: updated });
    setNewProjectTitle("");
    setNewProjectDesc("");
    setNewProjectTech("");
    setShowAddProject(false);
  };

  const handleRemoveProject = (index: number) => {
    const currentProjects = [...(profile.completedProjects || [])];
    currentProjects.splice(index, 1);
    setProfile({ ...profile, completedProjects: currentProjects });
  };

  const handleAddCert = () => {
    if (!newCert.trim()) return;
    const currentCerts = profile.certifications || [];
    setProfile({ ...profile, certifications: [...currentCerts, newCert.trim()] });
    setNewCert("");
  };

  const handleRemoveCert = (index: number) => {
    const current = [...(profile.certifications || [])];
    current.splice(index, 1);
    setProfile({ ...profile, certifications: current });
  };

  if (loading) {
    return (
      <div className="p-12 text-center text-slate-400">
        <RefreshCw className="w-6 h-6 mx-auto animate-spin mb-3 text-cyan-400" />
        <p className="text-sm">Loading learner profile...</p>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto space-y-6 pb-12">
      {/* Header Banner */}
      <div className="glass-panel rounded-2xl p-6 border border-white/10 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-cyan-500 via-indigo-600 to-purple-600 flex items-center justify-center text-white text-2xl font-bold shadow-xl shadow-cyan-500/20">
            {profile?.fullName ? profile.fullName[0].toUpperCase() : "A"}
          </div>
          <div>
            <h2 className="text-xl font-bold text-white flex items-center gap-2">
              {profile?.fullName || "Alex"}
              <span className="text-xs px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 font-semibold border border-cyan-500/30">
                Verified Learner
              </span>
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">{profile?.email || "alex@kingskill.ai"}</p>
            <div className="flex items-center gap-2 mt-1.5 text-xs text-slate-300">
              <span className="text-cyan-400 font-medium">{profile?.targetCareerName}</span>
              <span>•</span>
              <span className="text-slate-400">{profile?.educationLevel}</span>
            </div>
          </div>
        </div>

        <button
          onClick={handleSaveProfile}
          disabled={saving}
          className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white font-semibold text-xs shadow-lg shadow-cyan-500/20 active:scale-95 transition-all flex items-center gap-2 shrink-0 disabled:opacity-50"
        >
          <Save className="w-4 h-4" />
          <span>{saving ? "Saving & Recalibrating..." : "Save Profile Changes"}</span>
        </button>
      </div>

      {message && (
        <div
          className={`p-4 rounded-xl text-xs flex items-center gap-2.5 ${
            message.type === "error"
              ? "bg-rose-500/10 text-rose-300 border border-rose-500/20"
              : "bg-emerald-500/10 text-emerald-300 border border-emerald-500/20"
          }`}
        >
          {message.type === "error" ? (
            <AlertCircle className="w-4 h-4 shrink-0" />
          ) : (
            <CheckCircle2 className="w-4 h-4 shrink-0" />
          )}
          <span>{message.text}</span>
        </div>
      )}

      {/* Profile Form */}
      <form onSubmit={handleSaveProfile} className="space-y-6">
        {/* Academic & Basic Info */}
        <div className="glass-panel rounded-2xl p-6 border border-white/10 space-y-4">
          <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
            <GraduationCap className="w-4 h-4 text-cyan-400" />
            Academic Background & Identity
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">Full Name</label>
              <input
                type="text"
                value={profile?.fullName || ""}
                onChange={(e) => setProfile({ ...profile, fullName: e.target.value })}
                className="w-full bg-slate-900 border border-white/10 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-500"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Email Address (Read Only)
              </label>
              <input
                type="email"
                disabled
                value={profile?.email || ""}
                className="w-full bg-slate-900/50 border border-white/5 rounded-xl px-3 py-2 text-xs text-slate-400 cursor-not-allowed"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Education Level
              </label>
              <input
                type="text"
                value={profile?.educationLevel || ""}
                onChange={(e) => setProfile({ ...profile, educationLevel: e.target.value })}
                placeholder="e.g. Computer Science Student"
                className="w-full bg-slate-900 border border-white/10 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-500"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                College or Organization
              </label>
              <input
                type="text"
                value={profile?.collegeOrOrg || ""}
                onChange={(e) => setProfile({ ...profile, collegeOrOrg: e.target.value })}
                placeholder="e.g. State University of Technology"
                className="w-full bg-slate-900 border border-white/10 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-500"
              />
            </div>

            <div className="sm:col-span-2">
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Work Experience / Background Summary
              </label>
              <textarea
                rows={2}
                value={profile?.workExperience || ""}
                onChange={(e) => setProfile({ ...profile, workExperience: e.target.value })}
                placeholder="Academic team lead, previous internships, or open source contributor..."
                className="w-full bg-slate-900 border border-white/10 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-500"
              />
            </div>
          </div>
        </div>

        {/* Current Technical Skills (Multi-Agent Input) */}
        <div className="glass-panel rounded-2xl p-6 border border-white/10 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
                <Layers className="w-4 h-4 text-indigo-400" />
                Current Technical Skills & Proficiencies
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                Analyzed by the Skill Analysis Agent to compute gaps against your target career.
              </p>
            </div>
          </div>

          {/* Existing Skills Badges */}
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
            {userSkills.map((skill) => (
              <div
                key={skill.skillName}
                className="p-3 rounded-xl bg-slate-900/80 border border-white/10 flex items-center justify-between group hover:border-cyan-500/40 transition-colors"
              >
                <div>
                  <div className="text-xs font-bold text-white flex items-center gap-1.5">
                    {skill.skillName}
                    {skill.verified && (
                      <span title="Verified">
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                      </span>
                    )}
                  </div>
                  <div className="text-[11px] text-cyan-400 mt-0.5">
                    {skill.proficiencyLevel} • {skill.score}%
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => handleRemoveSkill(skill.skillName)}
                  className="p-1 text-slate-400 hover:text-rose-400 transition-colors opacity-0 group-hover:opacity-100"
                  title="Remove skill"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            ))}
          </div>

          {/* Add Skill Row */}
          <div className="pt-3 border-t border-white/5 flex flex-wrap sm:flex-nowrap items-center gap-2">
            <input
              type="text"
              value={newSkillName}
              onChange={(e) => setNewSkillName(e.target.value)}
              placeholder="Add skill (e.g. TypeScript, Docker, React)"
              className="flex-1 bg-slate-900 border border-white/10 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-500"
            />
            <select
              value={newSkillLevel}
              onChange={(e) => setNewSkillLevel(e.target.value)}
              className="bg-slate-900 border border-white/10 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-500"
            >
              <option value="Beginner">Beginner</option>
              <option value="Intermediate">Intermediate</option>
              <option value="Advanced">Advanced</option>
              <option value="Expert">Expert</option>
            </select>
            <button
              type="button"
              onClick={handleAddSkill}
              className="px-3 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold flex items-center gap-1 shrink-0"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add Skill</span>
            </button>
          </div>
        </div>

        {/* Target Career & Learning Preferences */}
        <div className="glass-panel rounded-2xl p-6 border border-white/10 space-y-4">
          <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
            <Target className="w-4 h-4 text-cyan-400" />
            Career Goal & Learning Modality
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Target Career Goal
              </label>
              <select
                value={profile?.targetCareerId || "full-stack-developer"}
                onChange={(e) => {
                  const map: Record<string, string> = {
                    "full-stack-developer": "Full Stack Developer",
                    "ai-engineer": "AI Engineer",
                    "data-scientist": "Data Scientist",
                    "web-developer": "Web Developer",
                    "cloud-engineer": "Cloud Engineer",
                    "cybersecurity-analyst": "Cybersecurity Analyst",
                    "mobile-app-developer": "Mobile App Developer",
                  };
                  setProfile({
                    ...profile,
                    targetCareerId: e.target.value,
                    targetCareerName: map[e.target.value] || e.target.value,
                  });
                }}
                className="w-full bg-slate-900 border border-white/10 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-500"
              >
                <option value="full-stack-developer">Full Stack Developer</option>
                <option value="ai-engineer">AI Engineer</option>
                <option value="data-scientist">Data Scientist</option>
                <option value="web-developer">Web Developer</option>
                <option value="cloud-engineer">Cloud Engineer</option>
                <option value="cybersecurity-analyst">Cybersecurity Analyst</option>
                <option value="mobile-app-developer">Mobile App Developer</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Preferred Learning Style
              </label>
              <select
                value={profile?.preferredLearningStyle || "Hands-on Projects"}
                onChange={(e) => setProfile({ ...profile, preferredLearningStyle: e.target.value })}
                className="w-full bg-slate-900 border border-white/10 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-500"
              >
                <option value="Hands-on Projects">Hands-on Projects & Building</option>
                <option value="Video Tutorials">Video Tutorials & Walkthroughs</option>
                <option value="Interactive Coding Exercises">Interactive Coding Exercises</option>
                <option value="Comprehensive Documentation">Comprehensive Documentation & Books</option>
              </select>
            </div>
          </div>
        </div>

        {/* Certifications & Completed Projects */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
          {/* Certifications */}
          <div className="glass-panel rounded-2xl p-6 border border-white/10 space-y-3">
            <h3 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-2">
              <Award className="w-4 h-4 text-amber-400" />
              Certifications
            </h3>

            <div className="space-y-2">
              {(profile?.certifications || []).map((cert: string, idx: number) => (
                <div
                  key={idx}
                  className="p-2.5 rounded-xl bg-slate-900/60 border border-white/5 flex items-center justify-between text-xs text-slate-200"
                >
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-amber-400" />
                    <span>{cert}</span>
                  </div>
                  <button
                    type="button"
                    onClick={() => handleRemoveCert(idx)}
                    className="text-slate-400 hover:text-rose-400 p-1"
                  >
                    <Trash2 className="w-3 h-3" />
                  </button>
                </div>
              ))}
            </div>

            <div className="flex items-center gap-2 pt-2">
              <input
                type="text"
                value={newCert}
                onChange={(e) => setNewCert(e.target.value)}
                placeholder="Add certification (e.g. AWS Cloud Practitioner)"
                className="flex-1 bg-slate-900 border border-white/10 rounded-xl px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-cyan-500"
              />
              <button
                type="button"
                onClick={handleAddCert}
                className="px-2.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-white rounded-xl text-xs font-medium"
              >
                Add
              </button>
            </div>
          </div>

          {/* Completed Projects */}
          <div className="glass-panel rounded-2xl p-6 border border-white/10 space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-2">
                <FolderGit2 className="w-4 h-4 text-cyan-400" />
                Completed Projects
              </h3>
              <button
                type="button"
                onClick={() => setShowAddProject(!showAddProject)}
                className="text-xs text-cyan-400 hover:underline font-semibold"
              >
                {showAddProject ? "Cancel" : "+ Add Project"}
              </button>
            </div>

            <div className="space-y-2">
              {(profile?.completedProjects || []).map((p: any, idx: number) => (
                <div
                  key={idx}
                  className="p-3 rounded-xl bg-slate-900/60 border border-white/5 space-y-1 relative group"
                >
                  <div className="flex items-center justify-between">
                    <div className="text-xs font-bold text-white">{p.title}</div>
                    <button
                      type="button"
                      onClick={() => handleRemoveProject(idx)}
                      className="text-slate-400 hover:text-rose-400 opacity-0 group-hover:opacity-100 transition-opacity"
                    >
                      <Trash2 className="w-3 h-3" />
                    </button>
                  </div>
                  {p.description && (
                    <div className="text-[11px] text-slate-400">{p.description}</div>
                  )}
                  {p.tech && (
                    <div className="flex flex-wrap gap-1 pt-1">
                      {p.tech.map((t: string) => (
                        <span
                          key={t}
                          className="text-[9px] px-1.5 py-0.2 rounded bg-slate-800 text-slate-300"
                        >
                          {t}
                        </span>
                      ))}
                    </div>
                  )}
                </div>
              ))}
            </div>

            {showAddProject && (
              <div className="p-3 rounded-xl bg-slate-900 border border-cyan-500/30 space-y-2 text-xs">
                <input
                  type="text"
                  value={newProjectTitle}
                  onChange={(e) => setNewProjectTitle(e.target.value)}
                  placeholder="Project Title (e.g. Portfolio App)"
                  className="w-full bg-slate-950 border border-white/10 rounded-lg px-2.5 py-1.5 text-xs text-white"
                />
                <textarea
                  rows={2}
                  value={newProjectDesc}
                  onChange={(e) => setNewProjectDesc(e.target.value)}
                  placeholder="Brief description..."
                  className="w-full bg-slate-950 border border-white/10 rounded-lg px-2.5 py-1.5 text-xs text-white"
                />
                <input
                  type="text"
                  value={newProjectTech}
                  onChange={(e) => setNewProjectTech(e.target.value)}
                  placeholder="Technologies comma-separated (e.g. React, Node.js)"
                  className="w-full bg-slate-950 border border-white/10 rounded-lg px-2.5 py-1.5 text-xs text-white"
                />
                <button
                  type="button"
                  onClick={handleAddProject}
                  className="w-full py-1.5 bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold rounded-lg text-xs"
                >
                  Save Project to Profile
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Save Footer Action */}
        <div className="flex justify-end pt-2">
          <button
            type="submit"
            disabled={saving}
            className="px-6 py-3 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white font-bold text-xs shadow-xl shadow-cyan-500/20 active:scale-95 transition-all flex items-center gap-2"
          >
            <Sparkles className="w-4 h-4" />
            <span>{saving ? "AI Agents Recalibrating..." : "Save Profile & Update Roadmap"}</span>
          </button>
        </div>
      </form>
    </div>
  );
};
