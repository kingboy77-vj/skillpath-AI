"use client";

import React, { useState, useEffect } from "react";
import {
  CheckCircle2,
  XCircle,
  HelpCircle,
  Clock,
  Sparkles,
  ArrowRight,
  ArrowLeft,
  RotateCcw,
  RefreshCw,
  Award,
  AlertTriangle,
  BookOpen,
} from "lucide-react";

interface AssessmentsViewProps {
  initialAssessmentId?: string | null;
  onAssessmentCompleted?: () => void;
}

export const AssessmentsView: React.FC<AssessmentsViewProps> = ({
  initialAssessmentId,
  onAssessmentCompleted,
}) => {
  const [loading, setLoading] = useState(true);
  const [assessments, setAssessments] = useState<any[]>([]);
  const [activeQuiz, setActiveQuiz] = useState<any | null>(null);
  const [quizQuestions, setQuizQuestions] = useState<any[]>([]);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [selectedAnswers, setSelectedAnswers] = useState<Record<number, number>>({});
  const [submitting, setSubmitting] = useState(false);
  const [quizResult, setQuizResult] = useState<any | null>(null);

  const fetchAssessments = async () => {
    try {
      setLoading(true);
      const res = await fetch("/api/assessments");
      if (res.ok) {
        const data = await res.json();
        setAssessments(data.assessments || []);

        if (initialAssessmentId) {
          const target = (data.assessments || []).find((a: any) => a.id === initialAssessmentId);
          if (target) {
            startQuiz(target);
          }
        }
      }
    } catch (e) {
      console.error("Error loading assessments:", e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAssessments();
  }, [initialAssessmentId]);

  const startQuiz = async (asm: any) => {
    try {
      setLoading(true);
      setQuizResult(null);
      const res = await fetch(`/api/assessments/${asm.id}`);
      if (res.ok) {
        const data = await res.json();
        setActiveQuiz(data.assessment);
        setQuizQuestions(data.questions || []);
        setCurrentQuestionIndex(0);
        setSelectedAnswers({});
      }
    } catch (e) {
      console.error("Error starting quiz:", e);
    } finally {
      setLoading(false);
    }
  };

  const handleSelectOption = (questionIndex: number, optionIndex: number) => {
    setSelectedAnswers((prev) => ({
      ...prev,
      [questionIndex]: optionIndex,
    }));
  };

  const handleSubmitQuiz = async () => {
    if (!activeQuiz) return;
    setSubmitting(true);
    try {
      const answersArray = quizQuestions.map((_, idx) =>
        selectedAnswers[idx] !== undefined ? selectedAnswers[idx] : -1
      );

      const res = await fetch("/api/assessments/submit", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          assessmentId: activeQuiz.id,
          answers: answersArray,
        }),
      });

      if (res.ok) {
        const result = await res.json();
        setQuizResult(result);
        if (onAssessmentCompleted) onAssessmentCompleted();
      }
    } catch (e) {
      console.error("Error submitting quiz:", e);
    } finally {
      setSubmitting(false);
    }
  };

  if (loading && !activeQuiz) {
    return (
      <div className="p-12 text-center text-slate-400">
        <RefreshCw className="w-6 h-6 mx-auto animate-spin mb-3 text-cyan-400" />
        <p className="text-sm">Loading skill assessments and question banks...</p>
      </div>
    );
  }

  // Active Quiz View
  if (activeQuiz && !quizResult) {
    const q = quizQuestions[currentQuestionIndex];
    const totalQ = quizQuestions.length;
    const isAnswered = selectedAnswers[currentQuestionIndex] !== undefined;
    const isLastQuestion = currentQuestionIndex === totalQ - 1;
    const allAnswered = quizQuestions.every((_, idx) => selectedAnswers[idx] !== undefined);

    return (
      <div className="max-w-2xl mx-auto space-y-6 pb-12 animate-in fade-in duration-150">
        {/* Top Control Bar */}
        <div className="flex items-center justify-between">
          <button
            onClick={() => {
              setActiveQuiz(null);
              fetchAssessments();
            }}
            className="text-xs text-slate-400 hover:text-white flex items-center gap-1.5 font-medium"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Cancel Assessment</span>
          </button>
          <div className="flex items-center gap-2 text-xs text-cyan-400 font-semibold bg-cyan-500/10 px-3 py-1 rounded-full border border-cyan-500/20">
            <Clock className="w-3.5 h-3.5" />
            <span>{activeQuiz.timeLimitMins} mins allotted</span>
          </div>
        </div>

        {/* Question Card */}
        <div className="glass-panel rounded-2xl p-6 sm:p-8 border border-white/10 space-y-6">
          <div className="flex items-center justify-between border-b border-white/10 pb-4">
            <div>
              <span className="text-[11px] font-bold text-cyan-400 uppercase tracking-wider">
                {activeQuiz.title}
              </span>
              <div className="text-xs text-slate-400 mt-0.5">
                Topic: <span className="text-white font-medium">{q?.topic || "Fundamentals"}</span>
              </div>
            </div>
            <span className="text-xs font-bold text-slate-300 px-2.5 py-1 rounded-lg bg-slate-900 border border-white/5">
              Question {currentQuestionIndex + 1} of {totalQ}
            </span>
          </div>

          {/* Question Text */}
          <h3 className="text-base sm:text-lg font-bold text-white leading-relaxed">
            {q?.questionText}
          </h3>

          {/* Options */}
          <div className="space-y-3">
            {q?.options?.map((option: string, optIdx: number) => {
              const isSelected = selectedAnswers[currentQuestionIndex] === optIdx;
              return (
                <button
                  key={optIdx}
                  onClick={() => handleSelectOption(currentQuestionIndex, optIdx)}
                  className={`w-full p-4 rounded-xl text-left text-xs sm:text-sm font-medium transition-all flex items-center gap-3.5 border ${
                    isSelected
                      ? "bg-cyan-500/20 border-cyan-500 text-cyan-200 shadow-md shadow-cyan-500/10"
                      : "bg-slate-900/70 border-white/10 text-slate-300 hover:border-white/20 hover:text-white"
                  }`}
                >
                  <span
                    className={`w-6 h-6 rounded-lg flex items-center justify-center font-bold text-xs shrink-0 ${
                      isSelected
                        ? "bg-cyan-500 text-slate-950"
                        : "bg-slate-800 text-slate-400"
                    }`}
                  >
                    {String.fromCharCode(65 + optIdx)}
                  </span>
                  <span>{option}</span>
                </button>
              );
            })}
          </div>

          {/* Navigation Buttons inside Quiz */}
          <div className="flex items-center justify-between pt-4 border-t border-white/10">
            <button
              onClick={() => setCurrentQuestionIndex((prev) => Math.max(prev - 1, 0))}
              disabled={currentQuestionIndex === 0}
              className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 text-xs font-semibold disabled:opacity-40 disabled:cursor-not-allowed hover:bg-slate-700"
            >
              Previous
            </button>

            {isLastQuestion ? (
              <button
                onClick={handleSubmitQuiz}
                disabled={submitting || !isAnswered}
                className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-cyan-500 hover:from-emerald-400 hover:to-cyan-400 text-slate-950 font-bold text-xs shadow-lg shadow-emerald-500/20 transition-all flex items-center gap-2 disabled:opacity-50"
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>{submitting ? "Evaluating..." : "Submit & Evaluate with Agent"}</span>
              </button>
            ) : (
              <button
                onClick={() => setCurrentQuestionIndex((prev) => Math.min(prev + 1, totalQ - 1))}
                disabled={!isAnswered}
                className="px-4 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 text-xs font-bold transition-all disabled:opacity-40 disabled:cursor-not-allowed flex items-center gap-1.5"
              >
                <span>Next Question</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        </div>
      </div>
    );
  }

  // Quiz Results / Agent Evaluation View
  if (quizResult) {
    const { score, totalQuestions, percentage, passed, evaluation, breakdown } = quizResult;

    return (
      <div className="max-w-3xl mx-auto space-y-6 pb-12 animate-in fade-in duration-200">
        {/* Score & Agent Evaluation Hero */}
        <div
          className={`glass-panel rounded-2xl p-6 sm:p-8 border shadow-xl ${
            passed
              ? "border-emerald-500/30 bg-gradient-to-b from-slate-900 via-emerald-950/20 to-slate-900"
              : "border-amber-500/30 bg-gradient-to-b from-slate-900 via-amber-950/20 to-slate-900"
          }`}
        >
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-2">
                <span
                  className={`text-xs font-bold px-2.5 py-1 rounded-full uppercase tracking-wider border ${
                    passed
                      ? "bg-emerald-500/20 text-emerald-300 border-emerald-500/30"
                      : "bg-amber-500/20 text-amber-300 border-amber-500/30"
                  }`}
                >
                  {passed ? "Assessment Passed" : "Needs Targeted Revision"}
                </span>
                <span className="text-xs text-slate-400">Agent 5 Evaluation</span>
              </div>
              <h2 className="text-xl sm:text-2xl font-extrabold text-white mt-1">
                Score: {score} / {totalQuestions} ({percentage}%)
              </h2>
              <p className="text-xs text-slate-300 mt-1 max-w-xl leading-relaxed">
                {evaluation?.summary}
              </p>
            </div>

            <button
              onClick={() => {
                setActiveQuiz(null);
                setQuizResult(null);
                fetchAssessments();
              }}
              className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white text-xs font-semibold flex items-center gap-1.5 shrink-0"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>Back to Assessments</span>
            </button>
          </div>

          {/* Diagnostic breakdown by Progress Evaluation Agent */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-6 pt-6 border-t border-white/10 text-xs">
            <div className="p-3.5 rounded-xl bg-slate-950/60 border border-white/5 space-y-1.5">
              <span className="font-semibold text-emerald-400 flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5" />
                Demonstrated Strengths
              </span>
              <ul className="text-slate-300 text-[11px] list-disc list-inside space-y-0.5">
                {(evaluation?.strengths || ["Core concept recall"]).map((s: string, idx: number) => (
                  <li key={idx}>{s}</li>
                ))}
              </ul>
            </div>

            <div className="p-3.5 rounded-xl bg-slate-950/60 border border-white/5 space-y-1.5">
              <span className="font-semibold text-amber-400 flex items-center gap-1.5">
                <AlertTriangle className="w-3.5 h-3.5" />
                Recommended Focus Topics
              </span>
              <ul className="text-slate-300 text-[11px] list-disc list-inside space-y-0.5">
                {(evaluation?.topicsToReview || ["Edge cases and syntax details"]).map((t: string, idx: number) => (
                  <li key={idx}>{t}</li>
                ))}
              </ul>
            </div>
          </div>
        </div>

        {/* Detailed Question Review with Explanations */}
        <div className="space-y-4">
          <h3 className="text-sm font-bold text-white uppercase tracking-wider">
            Detailed Question Explanations & Answers
          </h3>

          {breakdown?.map((item: any, idx: number) => (
            <div
              key={idx}
              className={`glass-panel rounded-2xl p-5 border ${
                item.isCorrect ? "border-emerald-500/20" : "border-rose-500/20"
              }`}
            >
              <div className="flex items-start justify-between gap-3 mb-2">
                <div className="flex items-start gap-2.5">
                  {item.isCorrect ? (
                    <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
                  ) : (
                    <XCircle className="w-5 h-5 text-rose-400 shrink-0 mt-0.5" />
                  )}
                  <h4 className="text-xs sm:text-sm font-semibold text-white">
                    {idx + 1}. {item.questionText}
                  </h4>
                </div>
                <span
                  className={`text-[10px] font-bold px-2 py-0.5 rounded shrink-0 ${
                    item.isCorrect
                      ? "bg-emerald-500/20 text-emerald-300"
                      : "bg-rose-500/20 text-rose-300"
                  }`}
                >
                  {item.isCorrect ? "Correct" : "Incorrect"}
                </span>
              </div>

              <div className="space-y-1.5 text-xs pl-7 mt-2">
                <div className="text-slate-300">
                  <span className="text-slate-500 font-medium">Your answer: </span>
                  <span className={item.isCorrect ? "text-emerald-300 font-medium" : "text-rose-300 font-medium"}>
                    {item.userAnswer}
                  </span>
                </div>
                {!item.isCorrect && (
                  <div className="text-slate-300">
                    <span className="text-slate-500 font-medium">Correct answer: </span>
                    <span className="text-emerald-300 font-medium">{item.correctAnswer}</span>
                  </div>
                )}
                <div className="p-3 rounded-xl bg-slate-950/70 border border-white/5 text-[11px] text-slate-300 leading-relaxed mt-2">
                  <span className="font-semibold text-cyan-400 block mb-0.5">Explanation:</span>
                  {item.explanation}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  // Assessments Catalog View
  return (
    <div className="space-y-6 pb-12">
      {/* Header Banner */}
      <div className="glass-panel rounded-2xl p-6 border border-white/10 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-cyan-500/20 flex items-center justify-center text-cyan-400">
              <CheckCircle2 className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white flex items-center gap-2">
                Agent 5: Progress Evaluation & Skill Quizzes
                <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
                  Adaptive
                </span>
              </h2>
              <p className="text-xs text-slate-400">
                Assessments trigger the Progress Evaluation Agent to update skill proficiencies & roadmap tasks.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Assessments Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {assessments.map((asm) => (
          <div
            key={asm.id}
            className="glass-panel rounded-2xl p-6 border border-white/10 hover:border-cyan-500/30 transition-all flex flex-col justify-between group"
          >
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-cyan-500/10 text-cyan-300 border border-cyan-500/20">
                  {asm.skillName}
                </span>
                <span className="text-[10px] font-semibold text-slate-400 flex items-center gap-1">
                  <Clock className="w-3 h-3" />
                  {asm.timeLimitMins} mins
                </span>
              </div>

              <div>
                <h3 className="text-sm font-bold text-white group-hover:text-cyan-300 transition-colors">
                  {asm.title}
                </h3>
                <p className="text-xs text-slate-400 mt-1 line-clamp-2 leading-relaxed">
                  {asm.description}
                </p>
              </div>

              <div className="flex items-center justify-between text-xs pt-1">
                <span className="text-slate-400">{asm.totalQuestions} Questions</span>
                <span className="text-purple-300 font-medium">{asm.difficulty}</span>
              </div>
            </div>

            <div className="pt-4 border-t border-white/5 mt-4 flex items-center justify-between">
              {asm.completed ? (
                <div className="flex items-center gap-1.5 text-xs text-emerald-400 font-semibold">
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Last Score: {asm.lastScore}%</span>
                </div>
              ) : (
                <span className="text-xs text-slate-500">Not Attempted</span>
              )}

              <button
                onClick={() => startQuiz(asm)}
                className="px-4 py-1.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs transition-all shadow"
              >
                {asm.completed ? "Retake Quiz" : "Start Assessment"}
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
