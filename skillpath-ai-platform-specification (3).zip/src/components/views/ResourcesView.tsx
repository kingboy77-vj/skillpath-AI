"use client";

import React, { useState, useEffect } from "react";
import {
  BookOpen,
  Search,
  ExternalLink,
  Video,
  Code2,
  FolderGit2,
  Sparkles,
  Star,
  Clock,
  RefreshCw,
  Tag,
} from "lucide-react";

export const ResourcesView: React.FC = () => {
  const [loading, setLoading] = useState(true);
  const [resources, setResources] = useState<any[]>([]);
  const [categories, setCategories] = useState<string[]>([]);
  const [types, setTypes] = useState<string[]>([]);
  const [selectedCategory, setSelectedCategory] = useState("All");
  const [selectedType, setSelectedType] = useState("All");
  const [searchQuery, setSearchQuery] = useState("");

  const fetchResources = async () => {
    try {
      setLoading(true);
      const params = new URLSearchParams();
      if (selectedCategory !== "All") params.append("category", selectedCategory);
      if (selectedType !== "All") params.append("type", selectedType);
      if (searchQuery.trim()) params.append("q", searchQuery.trim());

      const res = await fetch(`/api/resources?${params.toString()}`);
      if (res.ok) {
        const data = await res.json();
        setResources(data.resources || []);
        if (data.categories) setCategories(data.categories);
        if (data.types) setTypes(data.types);
      }
    } catch (e) {
      console.error("Error loading resources:", e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchResources();
  }, [selectedCategory, selectedType]);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    fetchResources();
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case "Video Tutorial":
        return <Video className="w-4 h-4 text-rose-400" />;
      case "Coding Exercise":
        return <Code2 className="w-4 h-4 text-emerald-400" />;
      case "Mini-Project":
        return <FolderGit2 className="w-4 h-4 text-purple-400" />;
      default:
        return <BookOpen className="w-4 h-4 text-cyan-400" />;
    }
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header Banner */}
      <div className="glass-panel rounded-2xl p-6 border border-white/10 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-cyan-500/20 flex items-center justify-center text-cyan-400">
              <BookOpen className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white flex items-center gap-2">
                Agent 3: Learning Recommendation Engine
                <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
                  Curated Catalog
                </span>
              </h2>
              <p className="text-xs text-slate-400">
                Personalized courses, official docs, interactive tutorials, and capstone mini-projects.
              </p>
            </div>
          </div>
        </div>

        {/* Search input */}
        <form onSubmit={handleSearchSubmit} className="relative w-full md:w-72">
          <Search className="w-4 h-4 text-slate-500 absolute left-3 top-2.5" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search React, Node, SQL..."
            className="w-full bg-slate-900 border border-white/10 rounded-xl pl-9 pr-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500"
          />
        </form>
      </div>

      {/* Category & Type Filter Pills */}
      <div className="space-y-3">
        {/* Category Pills */}
        <div className="flex flex-wrap items-center gap-2">
          <span className="text-xs text-slate-400 font-semibold mr-1">Category:</span>
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3 py-1.5 rounded-xl text-xs font-medium transition-all ${
                selectedCategory === cat
                  ? "bg-cyan-500 text-slate-950 font-bold shadow-md shadow-cyan-500/20"
                  : "bg-slate-900 text-slate-300 hover:text-white border border-white/10"
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Type Pills */}
        <div className="flex flex-wrap items-center gap-2">
          <span className="text-xs text-slate-400 font-semibold mr-1">Format:</span>
          {types.map((type) => (
            <button
              key={type}
              onClick={() => setSelectedType(type)}
              className={`px-3 py-1 rounded-lg text-[11px] font-medium transition-all ${
                selectedType === type
                  ? "bg-purple-600 text-white font-bold"
                  : "bg-slate-900/60 text-slate-400 hover:text-slate-200 border border-white/5"
              }`}
            >
              {type}
            </button>
          ))}
        </div>
      </div>

      {/* Resources Cards Grid */}
      {loading ? (
        <div className="p-12 text-center text-slate-400">
          <RefreshCw className="w-6 h-6 mx-auto animate-spin mb-3 text-cyan-400" />
          <p className="text-sm">Retrieving personalized learning catalog...</p>
        </div>
      ) : resources.length === 0 ? (
        <div className="p-12 text-center glass-panel rounded-2xl border border-white/10 text-slate-400 text-xs">
          No learning resources found matching your current filters. Try resetting search criteria.
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {resources.map((item) => (
            <div
              key={item.id}
              className="glass-panel rounded-2xl p-5 border border-white/10 hover:border-cyan-500/30 transition-all flex flex-col justify-between group"
            >
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="inline-flex items-center gap-1.5 text-[11px] font-semibold text-slate-300">
                    {getTypeIcon(item.type)}
                    <span>{item.type}</span>
                  </span>
                  <div className="flex items-center gap-1 text-[11px] font-semibold text-amber-400">
                    <Star className="w-3.5 h-3.5 fill-current" />
                    <span>{item.rating || "4.9"}</span>
                  </div>
                </div>

                <div>
                  <h3 className="text-sm font-bold text-white group-hover:text-cyan-300 transition-colors line-clamp-2 leading-snug">
                    {item.title}
                  </h3>
                  <p className="text-xs text-slate-400 mt-1.5 line-clamp-2 leading-relaxed">
                    {item.learningObjective}
                  </p>
                </div>

                <div className="flex flex-wrap items-center gap-1.5 pt-1">
                  <span className="text-[10px] px-2 py-0.5 rounded bg-cyan-500/10 text-cyan-300 font-medium border border-cyan-500/20">
                    {item.skillName}
                  </span>
                  <span className="text-[10px] px-2 py-0.5 rounded bg-slate-800 text-slate-400">
                    {item.difficultyLevel}
                  </span>
                  <span className="text-[10px] text-slate-500 flex items-center gap-1 ml-auto">
                    <Clock className="w-3 h-3" />
                    {item.estimatedDuration}
                  </span>
                </div>
              </div>

              <div className="pt-4 border-t border-white/5 mt-4 flex items-center justify-between">
                <span className="text-[11px] text-slate-400 truncate max-w-[140px]">
                  {item.provider || "SkillPath AI"}
                </span>
                <a
                  href={item.resourceUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="px-3 py-1.5 rounded-xl bg-cyan-500/15 hover:bg-cyan-500 text-cyan-300 hover:text-slate-950 font-bold text-xs transition-all flex items-center gap-1 shadow-sm"
                >
                  <span>Launch Resource</span>
                  <ExternalLink className="w-3 h-3" />
                </a>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
