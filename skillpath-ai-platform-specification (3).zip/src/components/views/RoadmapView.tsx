"use client";

import React, { useState, useEffect } from "react";
import {
  Map,
  CheckCircle2,
  Circle,
  Clock,
  Sparkles,
  ExternalLink,
  ChevronDown,
  ChevronUp,
  RefreshCw,
  BookOpen,
  Check,
  Code2,
  ArrowRight,
} from "lucide-react";
import { NavTab } from "../layout/Sidebar";

interface RoadmapViewProps {
  onNavigate: (tab: NavTab, meta?: any) => void;
  onTaskUpdated?: () => void;
}

export const RoadmapView: React.FC<RoadmapViewProps> = ({ onNavigate, onTaskUpdated }) => {
  const [loading, setLoading] = useState(true);
  const [regenerating, setRegenerating] = useState(false);
  const [roadmap, setRoadmap] = useState<any>(null);
  const [phases, setPhases] = useState<any[]>([]);
  const [completionPct, setCompletionPct] = useState(25);
  const [expandedPhases, setExpandedPhases] = useState<Record<number, boolean>>({
    1: true,
    2: true,
    3: false,
    4: false,
    5: false,
  });

  const fetchRoadmap = async () => {
    try {
      setLoading(true);
      const res = await fetch("/api/roadmap");
      if (res.ok) {
        const data = await res.json();
        setRoadmap(data.roadmap);
        setPhases(data.phases || []);
        setCompletionPct(data.completionPercentage || 0);
      }
    } catch (e) {
      console.error("Error loading roadmap:", e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchRoadmap();
  }, []);

  const togglePhase = (phaseNum: number) => {
    setExpandedPhases((prev) => ({ ...prev, [phaseNum]: !prev[phaseNum] }));
  };

  const handleToggleTask = async (taskId: string, currentCompleted: boolean) => {
    try {
      // Optimistic update
      setPhases((prevPhases) =>
        prevPhases.map((phase) => ({
          ...phase,
          tasks: phase.tasks.map((t: any) =>
            t.id === taskId ? { ...t, completed: !currentCompleted } : t
          ),
        }))
      );

      const res = await fetch(`/api/roadmap/tasks/${taskId}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ completed: !currentCompleted }),
      });

      if (res.ok) {
        const data = await res.json();
        if (data.roadmapCompletionPct !== undefined) {
          setCompletionPct(data.roadmapCompletionPct);
        }
        if (onTaskUpdated) onTaskUpdated();
      }
    } catch (e) {
      console.error("Error toggling task:", e);
      fetchRoadmap(); // rollback on error
    }
  };

  const handleRegenerateRoadmap = async () => {
    try {
      setRegenerating(true);
      const res = await fetch("/api/roadmap/regenerate", { method: "POST" });
      if (res.ok) {
        await fetchRoadmap();
        if (onTaskUpdated) onTaskUpdated();
      }
    } catch (e) {
      console.error("Error regenerating roadmap:", e);
    } finally {
      setRegenerating(false);
    }
  };

  if (loading) {
    return (
      <div className="p-12 text-center text-slate-400">
        <RefreshCw className="w-6 h-6 mx-auto animate-spin mb-3 text-cyan-400" />
        <p className="text-sm">Synthesizing personalized 5-phase learning syllabus...</p>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto space-y-6 pb-12">
      {/* Top Banner Card */}
      <div className="glass-panel rounded-2xl p-6 border border-white/10 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-cyan-500/20 flex items-center justify-center text-cyan-400">
              <Map className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white flex items-center gap-2">
                Agent 4: Personalized Learning Roadmap
                <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
                  5 Structured Phases
                </span>
              </h2>
              <p className="text-xs text-slate-400">
                Target Role:{" "}
                <span className="font-semibold text-white">
                  {roadmap?.careerTitle || "Full Stack Developer"}
                </span>{" "}
                • Interactive syllabus with automated progress tracking
              </p>
            </div>
          </div>
        </div>

        <button
          onClick={handleRegenerateRoadmap}
          disabled={regenerating}
          className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-cyan-300 border border-white/10 text-xs font-semibold flex items-center gap-2 transition-all disabled:opacity-50"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${regenerating ? "animate-spin" : ""}`} />
          <span>{regenerating ? "Re-synthesizing..." : "Regenerate AI Roadmap"}</span>
        </button>
      </div>

      {/* Progress Metric Bar */}
      <div className="glass-panel rounded-2xl p-6 border border-white/10 space-y-3">
        <div className="flex items-center justify-between text-xs">
          <span className="font-semibold text-slate-300 uppercase tracking-wider">
            Overall Roadmap Completion
          </span>
          <span className="font-bold text-cyan-400">{completionPct}% Complete</span>
        </div>
        <div className="w-full bg-slate-800 h-2.5 rounded-full overflow-hidden">
          <div
            className="bg-gradient-to-r from-cyan-500 via-indigo-500 to-purple-500 h-full rounded-full transition-all duration-700"
            style={{ width: `${completionPct}%` }}
          />
        </div>
        <div className="flex items-center justify-between text-[11px] text-slate-400 pt-1">
          <span>Phase 1: Fundamentals</span>
          <span>Phase 2: Core Concepts</span>
          <span>Phase 3: Advanced</span>
          <span>Phase 4: Capstone</span>
          <span>Phase 5: Career Prep</span>
        </div>
      </div>

      {/* 5 Phases Accordion List */}
      <div className="space-y-4">
        {phases.map((phase) => {
          const isExpanded = expandedPhases[phase.phaseNumber] ?? false;
          const completedCount = phase.tasks.filter((t: any) => t.completed).length;
          const totalInPhase = phase.tasks.length;
          const isPhaseDone = totalInPhase > 0 && completedCount === totalInPhase;

          return (
            <div
              key={phase.phaseNumber}
              className={`glass-panel rounded-2xl border transition-all overflow-hidden ${
                isPhaseDone
                  ? "border-emerald-500/30 bg-emerald-950/5"
                  : "border-white/10"
              }`}
            >
              {/* Phase Header */}
              <button
                onClick={() => togglePhase(phase.phaseNumber)}
                className="w-full p-5 flex items-center justify-between text-left hover:bg-white/5 transition-colors"
              >
                <div className="flex items-center gap-3.5">
                  <div
                    className={`w-9 h-9 rounded-xl flex items-center justify-center font-bold text-sm shrink-0 ${
                      isPhaseDone
                        ? "bg-emerald-500/20 text-emerald-300 border border-emerald-500/30"
                        : "bg-cyan-500/20 text-cyan-300 border border-cyan-500/30"
                    }`}
                  >
                    {isPhaseDone ? <Check className="w-4 h-4" /> : phase.phaseNumber}
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-white flex items-center gap-2">
                      {phase.phaseTitle}
                      {isPhaseDone && (
                        <span className="text-[10px] font-semibold px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                          Complete
                        </span>
                      )}
                    </h3>
                    <p className="text-xs text-slate-400 mt-0.5 line-clamp-1">
                      {phase.phaseDescription}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <span className="text-xs text-slate-400 font-medium hidden sm:inline">
                    {completedCount}/{totalInPhase} Tasks
                  </span>
                  {isExpanded ? (
                    <ChevronUp className="w-5 h-5 text-slate-400" />
                  ) : (
                    <ChevronDown className="w-5 h-5 text-slate-400" />
                  )}
                </div>
              </button>

              {/* Tasks List inside Phase */}
              {isExpanded && (
                <div className="p-5 pt-0 space-y-3.5 border-t border-white/5">
                  {phase.tasks.map((task: any) => (
                    <div
                      key={task.id}
                      className={`p-4 rounded-xl border transition-all ${
                        task.completed
                          ? "bg-slate-900/40 border-emerald-500/20"
                          : "bg-slate-900/80 border-white/10 hover:border-cyan-500/30"
                      }`}
                    >
                      <div className="flex items-start justify-between gap-3">
                        <div className="flex items-start gap-3">
                          <button
                            onClick={() => handleToggleTask(task.id, task.completed)}
                            className="mt-0.5 text-slate-400 hover:text-cyan-400 transition-colors shrink-0"
                          >
                            {task.completed ? (
                              <CheckCircle2 className="w-5 h-5 text-emerald-400 fill-emerald-400/20" />
                            ) : (
                              <Circle className="w-5 h-5 text-slate-500 hover:text-cyan-400" />
                            )}
                          </button>
                          <div className="space-y-1.5">
                            <h4
                              className={`text-xs sm:text-sm font-bold ${
                                task.completed ? "text-slate-400 line-through" : "text-white"
                              }`}
                            >
                              {task.title}
                            </h4>

                            {/* Skills to learn */}
                            {task.skillsToLearn && task.skillsToLearn.length > 0 && (
                              <div className="flex flex-wrap gap-1.5 pt-0.5">
                                {task.skillsToLearn.map((s: string) => (
                                  <span
                                    key={s}
                                    className="text-[10px] px-2 py-0.5 rounded bg-cyan-500/10 text-cyan-300 font-medium border border-cyan-500/20"
                                  >
                                    {s}
                                  </span>
                                ))}
                              </div>
                            )}

                            {/* Topics */}
                            {task.topics && task.topics.length > 0 && (
                              <div className="text-[11px] text-slate-400 pt-1">
                                <span className="font-semibold text-slate-300">Topics: </span>
                                {task.topics.join(" • ")}
                              </div>
                            )}

                            {/* Practical Tasks */}
                            {task.practicalTasks && task.practicalTasks.length > 0 && (
                              <div className="text-[11px] text-slate-300 bg-slate-950/60 p-2.5 rounded-lg border border-white/5 space-y-1 mt-1">
                                <span className="font-semibold text-cyan-400 block text-[10px] uppercase">
                                  Practical Coding Deliverable:
                                </span>
                                <ul className="list-disc list-inside space-y-0.5">
                                  {task.practicalTasks.map((pt: string, idx: number) => (
                                    <li key={idx}>{pt}</li>
                                  ))}
                                </ul>
                              </div>
                            )}
                          </div>
                        </div>
                      </div>

                      {/* Resource & Quiz Links */}
                      <div className="flex flex-wrap items-center justify-between gap-2 mt-3 pt-3 border-t border-white/5 text-xs">
                        <div className="flex items-center gap-3">
                          {task.resourceUrl && (
                            <a
                              href={task.resourceUrl}
                              target="_blank"
                              rel="noreferrer"
                              className="text-cyan-400 hover:underline flex items-center gap-1 font-medium"
                            >
                              <BookOpen className="w-3.5 h-3.5" />
                              <span className="truncate max-w-xs">{task.resourceTitle || "View Learning Material"}</span>
                              <ExternalLink className="w-3 h-3" />
                            </a>
                          )}
                        </div>

                        {task.assessmentId ? (
                          <button
                            onClick={() => onNavigate("assessments", { assessmentId: task.assessmentId })}
                            className="px-3 py-1 rounded-lg bg-purple-500/20 hover:bg-purple-500/30 text-purple-300 border border-purple-500/30 font-semibold flex items-center gap-1 transition-colors"
                          >
                            <span>Take Assessment Quiz</span>
                            <ArrowRight className="w-3 h-3" />
                          </button>
                        ) : null}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};
