"use client";

import React, { useState, useEffect } from "react";
import {
  Compass,
  CheckCircle2,
  AlertTriangle,
  ArrowRight,
  TrendingUp,
  DollarSign,
  Layers,
  Sparkles,
  Zap,
  Target,
  RefreshCw,
} from "lucide-react";
import { NavTab } from "../layout/Sidebar";

interface CareerExplorerViewProps {
  onNavigate: (tab: NavTab, meta?: any) => void;
  onCareerSwitched?: () => void;
}

export const CareerExplorerView: React.FC<CareerExplorerViewProps> = ({
  onNavigate,
  onCareerSwitched,
}) => {
  const [loading, setLoading] = useState(true);
  const [selectingId, setSelectingId] = useState<string | null>(null);
  const [careers, setCareers] = useState<any[]>([]);
  const [currentId, setCurrentId] = useState<string>("full-stack-developer");
  const [message, setMessage] = useState<string | null>(null);

  const fetchCareers = async () => {
    try {
      setLoading(true);
      const res = await fetch("/api/careers");
      if (res.ok) {
        const data = await res.json();
        setCareers(data.careers || []);
        setCurrentId(data.currentTargetCareerId || "full-stack-developer");
      }
    } catch (e) {
      console.error("Error loading careers:", e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchCareers();
  }, []);

  const handleSelectCareer = async (careerId: string) => {
    try {
      setSelectingId(careerId);
      setMessage(null);
      const res = await fetch("/api/careers/select", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ careerId }),
      });
      if (res.ok) {
        setCurrentId(careerId);
        setMessage(`Target career switched! AI agents orchestrated new roadmap for this role.`);
        fetchCareers();
        if (onCareerSwitched) onCareerSwitched();
      }
    } catch (e) {
      console.error("Error selecting career:", e);
    } finally {
      setSelectingId(null);
    }
  };

  if (loading) {
    return (
      <div className="p-12 text-center text-slate-400">
        <RefreshCw className="w-6 h-6 mx-auto animate-spin mb-3 text-cyan-400" />
        <p className="text-sm">Loading career profiles & matching algorithms...</p>
      </div>
    );
  }

  return (
    <div className="space-y-6 pb-12">
      {/* Header Banner */}
      <div className="glass-panel rounded-2xl p-6 border border-white/10 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-cyan-500/20 flex items-center justify-center text-cyan-400">
              <Compass className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white flex items-center gap-2">
                Agent 2: Career Matching & Industry Benchmarks
                <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
                  7 Career Paths
                </span>
              </h2>
              <p className="text-xs text-slate-400">
                Compare your current skill profile against real-world engineering roles. Switch target with 1-click.
              </p>
            </div>
          </div>
        </div>

        <div className="text-xs text-slate-300 bg-slate-900/80 px-3 py-2 rounded-xl border border-white/5">
          Active Target:{" "}
          <span className="font-bold text-cyan-400">
            {careers.find((c) => c.id === currentId)?.title || "Full Stack Developer"}
          </span>
        </div>
      </div>

      {message && (
        <div className="p-4 rounded-xl text-xs bg-emerald-500/15 text-emerald-300 border border-emerald-500/30 flex items-center justify-between animate-in fade-in">
          <span>{message}</span>
          <button
            onClick={() => onNavigate("roadmap")}
            className="text-xs font-bold text-white underline"
          >
            Go to Roadmap →
          </button>
        </div>
      )}

      {/* Careers Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {careers.map((career) => {
          const isTarget = career.id === currentId;
          const isSelecting = selectingId === career.id;
          const readiness = career.readinessScore || 30;

          return (
            <div
              key={career.id}
              className={`glass-panel rounded-2xl p-6 border transition-all flex flex-col justify-between relative overflow-hidden group ${
                isTarget
                  ? "border-cyan-500/50 bg-gradient-to-b from-slate-900 via-indigo-950/20 to-slate-900 shadow-xl shadow-cyan-500/10 ring-1 ring-cyan-500/30"
                  : "border-white/10 hover:border-white/20 hover:bg-slate-900/60"
              }`}
            >
              {isTarget && (
                <div className="absolute top-0 right-0 bg-gradient-to-l from-cyan-500 to-blue-600 text-slate-950 text-[10px] font-extrabold px-3 py-1 rounded-bl-xl uppercase tracking-wider flex items-center gap-1 shadow">
                  <Zap className="w-3 h-3 fill-current" />
                  Active Target
                </div>
              )}

              <div className="space-y-4">
                <div>
                  <div className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
                    {career.category}
                  </div>
                  <h3 className="text-base font-bold text-white mt-0.5 group-hover:text-cyan-300 transition-colors">
                    {career.title}
                  </h3>
                  <p className="text-xs text-slate-300 mt-2 line-clamp-3 leading-relaxed">
                    {career.description}
                  </p>
                </div>

                {/* Salary & Growth info */}
                <div className="grid grid-cols-2 gap-2 p-2.5 rounded-xl bg-slate-950/60 border border-white/5 text-[11px]">
                  <div>
                    <span className="text-slate-400 block text-[10px]">Avg Salary</span>
                    <span className="font-semibold text-white">{career.averageSalary}</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[10px]">Growth</span>
                    <span className="font-semibold text-emerald-400">{career.growthRate}</span>
                  </div>
                </div>

                {/* Career Readiness Progress Bar */}
                <div className="space-y-1.5">
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-slate-400 font-medium">Your Readiness Score</span>
                    <span className="font-bold text-cyan-400">{readiness}%</span>
                  </div>
                  <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                    <div
                      className={`h-full rounded-full transition-all duration-1000 ${
                        isTarget
                          ? "bg-gradient-to-r from-cyan-400 to-blue-500"
                          : "bg-slate-500"
                      }`}
                      style={{ width: `${readiness}%` }}
                    />
                  </div>
                </div>

                {/* Required Technologies & Missing Skills */}
                <div className="space-y-2 pt-2 border-t border-white/5">
                  <div className="text-[11px] font-semibold text-slate-300">
                    Required Core Technologies:
                  </div>
                  <div className="flex flex-wrap gap-1">
                    {(career.recommendedTechnologies || []).slice(0, 6).map((tech: string) => {
                      const isAcquired = (career.acquiredSkills || []).includes(tech);
                      return (
                        <span
                          key={tech}
                          className={`text-[10px] px-2 py-0.5 rounded font-medium border ${
                            isAcquired
                              ? "bg-emerald-500/10 text-emerald-300 border-emerald-500/20"
                              : "bg-slate-800 text-slate-300 border-white/5"
                          }`}
                        >
                          {tech} {isAcquired && "✓"}
                        </span>
                      );
                    })}
                  </div>

                  {career.missingSkills?.length > 0 && (
                    <div className="text-[10px] text-amber-400 font-medium pt-1">
                      {career.missingSkills.length} missing skill(s) for this role
                    </div>
                  )}
                </div>
              </div>

              {/* Action Buttons */}
              <div className="pt-5 border-t border-white/5 mt-5 flex items-center justify-between gap-2">
                <button
                  onClick={() => onNavigate("roadmap")}
                  className="text-xs text-slate-400 hover:text-white font-medium transition-colors"
                >
                  Inspect Syllabus
                </button>

                {isTarget ? (
                  <button
                    onClick={() => onNavigate("roadmap")}
                    className="px-3.5 py-1.5 rounded-xl bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 text-xs font-bold flex items-center gap-1.5"
                  >
                    <span>Current Focus</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                ) : (
                  <button
                    onClick={() => handleSelectCareer(career.id)}
                    disabled={isSelecting}
                    className="px-3.5 py-1.5 rounded-xl bg-slate-800 hover:bg-cyan-500 hover:text-slate-950 text-white text-xs font-semibold transition-all active:scale-95 disabled:opacity-50"
                  >
                    {isSelecting ? "Recalibrating..." : "Set as Target Career"}
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
