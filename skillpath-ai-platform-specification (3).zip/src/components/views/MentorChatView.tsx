"use client";

import React, { useState, useEffect, useRef } from "react";
import {
  Bot,
  Send,
  User,
  Sparkles,
  RefreshCw,
  ArrowRight,
  Zap,
  HelpCircle,
  CheckCircle2,
} from "lucide-react";
import { NavTab } from "../layout/Sidebar";

interface MentorChatViewProps {
  onNavigate: (tab: NavTab, meta?: any) => void;
  userContext?: any;
}

export const MentorChatView: React.FC<MentorChatViewProps> = ({ onNavigate, userContext }) => {
  const [messages, setMessages] = useState<any[]>([]);
  const [inputMessage, setInputMessage] = useState("");
  const [loading, setLoading] = useState(false);
  const [fetchingHistory, setFetchingHistory] = useState(true);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const fetchChatHistory = async () => {
    try {
      setFetchingHistory(true);
      const res = await fetch("/api/mentor/chat");
      if (res.ok) {
        const data = await res.json();
        setMessages(data.messages || []);
      }
    } catch (e) {
      console.error("Error loading chat history:", e);
    } finally {
      setFetchingHistory(false);
    }
  };

  useEffect(() => {
    fetchChatHistory();
  }, []);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, loading]);

  const handleSendMessage = async (textToSend?: string) => {
    const text = (textToSend || inputMessage).trim();
    if (!text || loading) return;

    setInputMessage("");
    setLoading(true);

    // Optimistic user message
    const tempUserMsg = {
      id: `temp_${Date.now()}`,
      sender: "user",
      message: text,
      createdAt: new Date().toISOString(),
    };
    setMessages((prev) => [...prev, tempUserMsg]);

    try {
      const res = await fetch("/api/mentor/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: text }),
      });

      if (res.ok) {
        const data = await res.json();
        setMessages((prev) => [...prev.filter((m) => m.id !== tempUserMsg.id), tempUserMsg, data.message]);
      }
    } catch (e) {
      console.error("Error sending mentor message:", e);
    } finally {
      setLoading(false);
    }
  };

  const handleActionClick = (action: string, payload?: any) => {
    if (action === "NAVIGATE_ROADMAP") {
      onNavigate("roadmap");
    } else if (action === "START_ASSESSMENT") {
      onNavigate("assessments", { assessmentId: payload?.assessmentId || "asm_javascript_101" });
    } else if (action === "VIEW_SKILLS") {
      onNavigate("skills");
    } else if (action === "EXPLORE_CAREERS") {
      onNavigate("careers");
    } else if (action === "OPEN_RESOURCE") {
      onNavigate("resources");
    }
  };

  const promptSuggestions = [
    "I want to become a Full Stack Developer.",
    "What should I learn first?",
    "Explain React hooks and state immutability.",
    "How does the JavaScript Event Loop work?",
  ];

  return (
    <div className="max-w-4xl mx-auto h-[calc(100vh-140px)] flex flex-col glass-panel rounded-2xl border border-white/10 shadow-2xl overflow-hidden">
      {/* Top Mentor Header */}
      <div className="p-4 sm:p-5 border-b border-white/10 bg-slate-950/70 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="relative">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-cyan-500 via-indigo-600 to-purple-600 flex items-center justify-center text-white shadow-lg shadow-cyan-500/20">
              <Bot className="w-5 h-5" />
            </div>
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 absolute -bottom-0.5 -right-0.5 ring-2 ring-slate-950" />
          </div>
          <div>
            <h3 className="font-bold text-white text-sm sm:text-base flex items-center gap-2">
              Agent 6: AI Mentor & Technical Coach
              <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                Online
              </span>
            </h3>
            <p className="text-xs text-slate-400">
              Context-aware advisor tuned to your skills, readiness score, and active roadmap tasks.
            </p>
          </div>
        </div>

        <button
          onClick={fetchChatHistory}
          disabled={fetchingHistory}
          className="p-2 text-slate-400 hover:text-white rounded-lg hover:bg-white/5 transition-colors"
          title="Reload chat"
        >
          <RefreshCw className={`w-4 h-4 ${fetchingHistory ? "animate-spin" : ""}`} />
        </button>
      </div>

      {/* Chat Messages Stream */}
      <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4">
        {fetchingHistory && messages.length === 0 ? (
          <div className="p-12 text-center text-slate-400 text-xs">
            <RefreshCw className="w-5 h-5 mx-auto animate-spin mb-2 text-cyan-400" />
            Synchronizing conversation memory with AI Mentor...
          </div>
        ) : (
          messages.map((msg) => {
            const isUser = msg.sender === "user";
            return (
              <div
                key={msg.id}
                className={`flex gap-3 max-w-[85%] ${
                  isUser ? "ml-auto flex-row-reverse" : "mr-auto"
                }`}
              >
                {/* Avatar */}
                <div
                  className={`w-8 h-8 rounded-xl flex items-center justify-center shrink-0 text-xs font-bold ${
                    isUser
                      ? "bg-gradient-to-tr from-cyan-500 to-blue-600 text-slate-950 ring-1 ring-cyan-400"
                      : "bg-gradient-to-tr from-indigo-600 to-purple-600 text-white ring-1 ring-purple-400"
                  }`}
                >
                  {isUser ? <User className="w-4 h-4" /> : <Bot className="w-4 h-4" />}
                </div>

                {/* Message Bubble */}
                <div className="space-y-2">
                  <div
                    className={`p-4 rounded-2xl text-xs sm:text-sm leading-relaxed ${
                      isUser
                        ? "bg-cyan-500 text-slate-950 font-medium rounded-tr-none shadow-md shadow-cyan-500/10"
                        : "bg-slate-900/90 text-slate-100 border border-white/10 rounded-tl-none shadow-md"
                    }`}
                  >
                    {msg.message}
                  </div>

                  {/* Recommended Skills & Action Buttons inside AI response */}
                  {!isUser && msg.metadata && (
                    <div className="space-y-2 pt-1 pl-1">
                      {msg.metadata.recommendedSkills && msg.metadata.recommendedSkills.length > 0 && (
                        <div className="flex flex-wrap items-center gap-1.5">
                          <span className="text-[10px] text-slate-400 font-semibold uppercase">
                            Focus Skills:
                          </span>
                          {msg.metadata.recommendedSkills.map((sk: string) => (
                            <span
                              key={sk}
                              className="text-[10px] px-2 py-0.5 rounded bg-cyan-500/15 text-cyan-300 font-semibold border border-cyan-500/30"
                            >
                              {sk}
                            </span>
                          ))}
                        </div>
                      )}

                      {msg.metadata.suggestedActions && msg.metadata.suggestedActions.length > 0 && (
                        <div className="flex flex-wrap gap-2 pt-1">
                          {msg.metadata.suggestedActions.map((act: any, idx: number) => (
                            <button
                              key={idx}
                              onClick={() => handleActionClick(act.action, act.payload)}
                              className="px-3 py-1.5 rounded-xl bg-purple-500/20 hover:bg-purple-500/30 text-purple-300 border border-purple-500/40 text-xs font-semibold flex items-center gap-1.5 transition-colors shadow-sm"
                            >
                              <span>{act.label}</span>
                              <ArrowRight className="w-3 h-3" />
                            </button>
                          ))}
                        </div>
                      )}
                    </div>
                  )}
                </div>
              </div>
            );
          })
        )}

        {loading && (
          <div className="flex gap-3 max-w-[85%] mr-auto">
            <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-indigo-600 to-purple-600 text-white flex items-center justify-center shrink-0">
              <Bot className="w-4 h-4 animate-bounce" />
            </div>
            <div className="p-4 rounded-2xl bg-slate-900 border border-white/10 rounded-tl-none flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse" />
              <span className="w-2 h-2 rounded-full bg-indigo-400 animate-pulse delay-100" />
              <span className="w-2 h-2 rounded-full bg-purple-400 animate-pulse delay-200" />
              <span className="text-xs text-slate-400 ml-1">AI Mentor formulating guidance...</span>
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Suggested Quick Prompts */}
      <div className="px-4 py-2 border-t border-white/5 bg-slate-950/40 flex items-center gap-2 overflow-x-auto">
        <span className="text-[10px] text-slate-400 uppercase font-bold shrink-0">Prompts:</span>
        {promptSuggestions.map((prompt, idx) => (
          <button
            key={idx}
            onClick={() => handleSendMessage(prompt)}
            className="px-2.5 py-1 rounded-lg bg-slate-900 hover:bg-slate-800 text-[11px] text-slate-300 hover:text-cyan-300 border border-white/5 whitespace-nowrap transition-colors"
          >
            {prompt}
          </button>
        ))}
      </div>

      {/* Input Field & Send Button */}
      <form
        onSubmit={(e) => {
          e.preventDefault();
          handleSendMessage();
        }}
        className="p-3 sm:p-4 border-t border-white/10 bg-slate-950/70 flex items-center gap-2"
      >
        <input
          type="text"
          value={inputMessage}
          onChange={(e) => setInputMessage(e.target.value)}
          placeholder="Ask AI Mentor anything about your roadmap, coding concepts, or career strategy..."
          className="flex-1 bg-slate-900 border border-white/10 rounded-xl px-4 py-2.5 text-xs sm:text-sm text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500"
        />
        <button
          type="submit"
          disabled={loading || !inputMessage.trim()}
          className="p-2.5 sm:px-4 sm:py-2.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs shadow-lg shadow-cyan-500/20 transition-all flex items-center gap-1.5 disabled:opacity-40 disabled:cursor-not-allowed shrink-0"
        >
          <Send className="w-4 h-4" />
          <span className="hidden sm:inline">Send</span>
        </button>
      </form>
    </div>
  );
};
