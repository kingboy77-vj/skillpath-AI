"use client";

import React from "react";
import {
  Sparkles,
  Target,
  Award,
  Layers,
  AlertTriangle,
  ArrowRight,
  CheckCircle2,
  Clock,
  BookOpen,
  TrendingUp,
  BrainCircuit,
  Bot,
  Zap,
} from "lucide-react";
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  PieChart,
  Pie,
  Cell,
} from "recharts";
import { NavTab } from "../layout/Sidebar";

interface DashboardViewProps {
  data: {
    user: any;
    progress: any;
    roadmap: any;
    skills: any[];
    recentAssessments: any[];
  };
  onNavigate: (tab: NavTab, meta?: any) => void;
  onRunOrchestrator: () => void;
  isOrchestrating: boolean;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  data,
  onNavigate,
  onRunOrchestrator,
  isOrchestrating,
}) => {
  const { user, progress, roadmap, skills, recentAssessments } = data;

  const readinessScore = progress?.careerReadiness ?? 38;
  const acquiredCount = progress?.totalSkillsAcquired ?? skills?.length ?? 3;
  const missingCount = progress?.missingSkillsCount ?? 6;
  const roadmapPct = progress?.roadmapCompletionPct ?? 25;

  // Next recommended task
  const nextTask = roadmap?.phases?.[1]?.tasks?.[0] ||
    roadmap?.phases?.[0]?.tasks?.find((t: any) => !t.completed) || {
      title: "JavaScript Deep Dive: Async/Await, Closures & Event Loop",
      skillsToLearn: ["JavaScript"],
      practicalTasks: ["Build an interactive weather dashboard consuming open weather API"],
      resourceTitle: "Modern JavaScript Deep Dive: From Fundamentals to ESNext",
    };

  const donutData = [
    { name: "Ready", value: readinessScore, color: "#06b6d4" },
    { name: "Gap", value: Math.max(100 - readinessScore, 0), color: "#1e293b" },
  ];

  const weeklyActivityData = progress?.weeklyHours || [
    { day: "Mon", hours: 2.5 },
    { day: "Tue", hours: 3.0 },
    { day: "Wed", hours: 1.5 },
    { day: "Thu", hours: 4.0 },
    { day: "Fri", hours: 2.0 },
    { day: "Sat", hours: 5.0 },
    { day: "Sun", hours: 3.5 },
  ];

  return (
    <div className="space-y-6 pb-12">
      {/* Welcome Banner Card */}
      <div className="relative overflow-hidden rounded-2xl p-6 sm:p-8 bg-gradient-to-r from-slate-900 via-indigo-950/70 to-slate-900 border border-white/10 shadow-xl">
        <div className="absolute right-0 top-0 bottom-0 w-1/3 bg-radial from-cyan-500/10 to-transparent pointer-events-none" />
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2 max-w-2xl">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-cyan-500/10 text-cyan-300 text-xs font-semibold border border-cyan-500/20">
              <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
              Agentic AI Learning Engine Online
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
              Welcome back, <span className="text-cyan-400">{user?.fullName || "Alex"}</span>!
            </h1>
            <p className="text-slate-300 text-sm leading-relaxed">
              Target Career:{" "}
              <span className="font-semibold text-white">
                {user?.targetCareerName || "Full Stack Developer"}
              </span>
              . The Multi-Agent Orchestrator has mapped your existing competencies in{" "}
              <span className="text-cyan-300 font-medium">
                {skills?.map((s: any) => s.skillName || s.name).join(", ") || "Python, SQL, HTML"}
              </span>{" "}
              and prioritized your next steps to bridge remaining skill gaps.
            </p>
          </div>

          <div className="flex flex-wrap sm:flex-nowrap items-center gap-3 shrink-0">
            <button
              onClick={() => onNavigate("roadmap")}
              className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white font-semibold text-xs shadow-lg shadow-cyan-500/20 active:scale-95 transition-all flex items-center gap-2"
            >
              <span>View Learning Roadmap</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={() => onNavigate("mentor")}
              className="px-4 py-2.5 rounded-xl bg-slate-800/80 hover:bg-slate-700/80 text-slate-200 border border-white/10 text-xs font-semibold transition-all flex items-center gap-2"
            >
              <Bot className="w-4 h-4 text-cyan-400" />
              <span>Ask AI Mentor</span>
            </button>
          </div>
        </div>
      </div>

      {/* 4 Top KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Career Readiness */}
        <div className="glass-panel rounded-2xl p-5 relative overflow-hidden group border border-white/10 hover:border-cyan-500/30 transition-all">
          <div className="flex items-center justify-between text-slate-400 text-xs mb-2">
            <span>Career Readiness Score</span>
            <div className="w-7 h-7 rounded-lg bg-cyan-500/20 flex items-center justify-center text-cyan-400">
              <Target className="w-4 h-4" />
            </div>
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-3xl font-extrabold text-white">{readinessScore}%</span>
            <span className="text-[11px] font-medium text-emerald-400">+8% from last week</span>
          </div>
          <div className="w-full bg-slate-800 h-2 rounded-full mt-3 overflow-hidden">
            <div
              className="bg-gradient-to-r from-cyan-500 to-blue-500 h-full rounded-full transition-all duration-1000"
              style={{ width: `${readinessScore}%` }}
            />
          </div>
          <div className="mt-2 text-[11px] text-slate-400">
            Role: {user?.targetCareerName || "Full Stack Developer"}
          </div>
        </div>

        {/* Skills Acquired */}
        <div className="glass-panel rounded-2xl p-5 relative overflow-hidden group border border-white/10 hover:border-indigo-500/30 transition-all">
          <div className="flex items-center justify-between text-slate-400 text-xs mb-2">
            <span>Acquired Skills</span>
            <div className="w-7 h-7 rounded-lg bg-indigo-500/20 flex items-center justify-center text-indigo-400">
              <Award className="w-4 h-4" />
            </div>
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-3xl font-extrabold text-white">{acquiredCount}</span>
            <span className="text-[11px] font-medium text-slate-400">verified competencies</span>
          </div>
          <div className="flex flex-wrap gap-1.5 mt-3">
            {(skills || []).slice(0, 3).map((s: any) => (
              <span
                key={s.id || s.name}
                className="text-[10px] px-2 py-0.5 rounded-md bg-indigo-500/20 text-indigo-300 font-medium border border-indigo-500/30"
              >
                {s.skillName || s.name}
              </span>
            ))}
          </div>
        </div>

        {/* Missing Skills */}
        <div className="glass-panel rounded-2xl p-5 relative overflow-hidden group border border-white/10 hover:border-amber-500/30 transition-all">
          <div className="flex items-center justify-between text-slate-400 text-xs mb-2">
            <span>Missing Industry Skills</span>
            <div className="w-7 h-7 rounded-lg bg-amber-500/20 flex items-center justify-center text-amber-400">
              <AlertTriangle className="w-4 h-4" />
            </div>
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-3xl font-extrabold text-white">{missingCount}</span>
            <span className="text-[11px] font-medium text-amber-400">gaps to close</span>
          </div>
          <button
            onClick={() => onNavigate("skills")}
            className="mt-3 text-[11px] text-cyan-400 hover:text-cyan-300 flex items-center gap-1 font-semibold group-hover:translate-x-0.5 transition-all"
          >
            <span>Analyze Skill Gaps in Radar</span>
            <ArrowRight className="w-3 h-3" />
          </button>
        </div>

        {/* Roadmap Completion */}
        <div className="glass-panel rounded-2xl p-5 relative overflow-hidden group border border-white/10 hover:border-purple-500/30 transition-all">
          <div className="flex items-center justify-between text-slate-400 text-xs mb-2">
            <span>Roadmap Completion</span>
            <div className="w-7 h-7 rounded-lg bg-purple-500/20 flex items-center justify-center text-purple-400">
              <Layers className="w-4 h-4" />
            </div>
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-3xl font-extrabold text-white">{roadmapPct}%</span>
            <span className="text-[11px] font-medium text-slate-400">5 Phases active</span>
          </div>
          <div className="w-full bg-slate-800 h-2 rounded-full mt-3 overflow-hidden">
            <div
              className="bg-gradient-to-r from-purple-500 to-pink-500 h-full rounded-full transition-all duration-1000"
              style={{ width: `${roadmapPct}%` }}
            />
          </div>
          <div className="mt-2 text-[11px] text-slate-400">
            Phase 1 completed • Phase 2 in progress
          </div>
        </div>
      </div>

      {/* Middle Row: Recommended Next Activity & Weekly Activity Chart */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Recommended Next Activity Card */}
        <div className="lg:col-span-2 glass-panel rounded-2xl p-6 border border-white/10 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <div className="w-7 h-7 rounded-lg bg-cyan-500/20 flex items-center justify-center text-cyan-400">
                  <Zap className="w-4 h-4" />
                </div>
                <h3 className="font-bold text-base text-white">Recommended Next Activity</h3>
              </div>
              <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 uppercase">
                High Priority Focus
              </span>
            </div>

            <div className="p-4 rounded-xl bg-slate-900/80 border border-white/5 space-y-3">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <div className="text-xs font-semibold text-cyan-400 uppercase tracking-wide">
                    Phase 2: Intermediate Concepts
                  </div>
                  <h4 className="text-base font-bold text-white mt-0.5">
                    {nextTask.title}
                  </h4>
                </div>
                <span className="text-xs font-medium px-2 py-1 rounded bg-slate-800 text-slate-300 shrink-0">
                  Estimated ~14h
                </span>
              </div>

              <div className="flex flex-wrap gap-2 text-xs">
                {nextTask.skillsToLearn?.map((skill: string) => (
                  <span
                    key={skill}
                    className="px-2 py-0.5 rounded bg-cyan-500/10 text-cyan-300 border border-cyan-500/20 font-medium"
                  >
                    Skill: {skill}
                  </span>
                ))}
              </div>

              {nextTask.practicalTasks && (
                <div className="text-xs text-slate-300 space-y-1 pt-1 border-t border-white/5">
                  <span className="font-semibold text-slate-400">Practical Task:</span>
                  <div className="flex items-center gap-2 text-slate-200">
                    <CheckCircle2 className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                    <span>{nextTask.practicalTasks[0]}</span>
                  </div>
                </div>
              )}
            </div>
          </div>

          <div className="flex items-center justify-between gap-3 pt-4 border-t border-white/5 mt-4">
            <button
              onClick={() => onNavigate("roadmap")}
              className="text-xs font-medium text-slate-400 hover:text-white transition-colors"
            >
              Browse Full 5-Phase Roadmap →
            </button>
            <div className="flex items-center gap-2">
              <button
                onClick={() => onNavigate("assessments", { assessmentId: "asm_javascript_101" })}
                className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-cyan-300 border border-cyan-500/30 text-xs font-semibold transition-all"
              >
                Take JS Assessment
              </button>
              <button
                onClick={() => onNavigate("resources")}
                className="px-3.5 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 text-xs font-bold transition-all shadow-md"
              >
                Start Learning Task
              </button>
            </div>
          </div>
        </div>

        {/* Weekly Study Hours Activity */}
        <div className="glass-panel rounded-2xl p-6 border border-white/10 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-2">
              <h3 className="font-bold text-sm text-white flex items-center gap-2">
                <Clock className="w-4 h-4 text-purple-400" />
                Weekly Study Activity
              </h3>
              <span className="text-xs text-slate-400">19.5 hrs total</span>
            </div>
            <p className="text-[11px] text-slate-400 mb-4">
              Consistent daily practice tracked by Progress Evaluation Agent.
            </p>
          </div>

          <div className="h-40 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={weeklyActivityData}>
                <XAxis dataKey="day" stroke="#64748b" fontSize={10} tickLine={false} />
                <YAxis stroke="#64748b" fontSize={10} tickLine={false} axisLine={false} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: "#0f172a",
                    borderColor: "rgba(255,255,255,0.1)",
                    borderRadius: "8px",
                    fontSize: "11px",
                  }}
                />
                <Bar dataKey="hours" fill="#818cf8" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>

          <div className="pt-3 border-t border-white/5 flex items-center justify-between text-xs text-slate-400">
            <span>Peak day: Saturday (5h)</span>
            <button
              onClick={() => onNavigate("progress")}
              className="text-cyan-400 hover:underline font-medium text-[11px]"
            >
              Detailed Analytics →
            </button>
          </div>
        </div>
      </div>

      {/* Bottom Row: Upcoming Learning Tasks & Recent Assessment Results */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Upcoming Tasks Checklist */}
        <div className="glass-panel rounded-2xl p-6 border border-white/10">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-bold text-base text-white flex items-center gap-2">
              <BookOpen className="w-4 h-4 text-cyan-400" />
              Upcoming Learning Tasks
            </h3>
            <button
              onClick={() => onNavigate("roadmap")}
              className="text-xs text-cyan-400 hover:underline font-semibold"
            >
              View All
            </button>
          </div>

          <div className="space-y-3">
            {[
              {
                title: "JavaScript Deep Dive: Async/Await & Closures",
                phase: "Phase 2",
                skill: "JavaScript",
                duration: "14h",
                done: false,
              },
              {
                title: "Node.js & Express Architecture Fundamentals",
                phase: "Phase 2",
                skill: "Node.js",
                duration: "16h",
                done: false,
              },
              {
                title: "React Component Lifecycle & Custom Hooks",
                phase: "Phase 3",
                skill: "React",
                duration: "18h",
                done: false,
              },
            ].map((task, idx) => (
              <div
                key={idx}
                className="p-3.5 rounded-xl bg-slate-900/60 border border-white/5 hover:border-white/10 transition-colors flex items-center justify-between"
              >
                <div className="flex items-center gap-3">
                  <div className="w-5 h-5 rounded-full border border-cyan-500/40 flex items-center justify-center shrink-0">
                    <span className="text-[10px] font-bold text-cyan-400">{idx + 1}</span>
                  </div>
                  <div>
                    <h5 className="text-xs font-semibold text-white">{task.title}</h5>
                    <div className="flex items-center gap-2 text-[10px] text-slate-400 mt-0.5">
                      <span className="text-purple-300 font-medium">{task.phase}</span>
                      <span>•</span>
                      <span>{task.skill}</span>
                    </div>
                  </div>
                </div>
                <span className="text-[11px] text-slate-400 px-2 py-0.5 rounded bg-slate-800">
                  {task.duration}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Recent Assessment Results */}
        <div className="glass-panel rounded-2xl p-6 border border-white/10">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-bold text-base text-white flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
              Skill Assessments & Quizzes
            </h3>
            <button
              onClick={() => onNavigate("assessments")}
              className="text-xs text-cyan-400 hover:underline font-semibold"
            >
              Take Quiz
            </button>
          </div>

          <div className="space-y-3">
            {[
              {
                title: "JavaScript Core & Asynchronous Mechanics",
                status: "Pending Evaluation",
                score: "Ready",
                badgeColor: "bg-cyan-500/20 text-cyan-300 border-cyan-500/30",
                id: "asm_javascript_101",
              },
              {
                title: "React Component Architecture & Hooks",
                status: "Pending Evaluation",
                score: "Ready",
                badgeColor: "bg-purple-500/20 text-purple-300 border-purple-500/30",
                id: "asm_react_101",
              },
              {
                title: "Python Fundamentals Certification",
                status: "Verified Passed",
                score: "92%",
                badgeColor: "bg-emerald-500/20 text-emerald-300 border-emerald-500/30",
                id: null,
              },
            ].map((asm, idx) => (
              <div
                key={idx}
                className="p-3.5 rounded-xl bg-slate-900/60 border border-white/5 hover:border-white/10 transition-colors flex items-center justify-between"
              >
                <div>
                  <h5 className="text-xs font-semibold text-white">{asm.title}</h5>
                  <span className="text-[10px] text-slate-400 mt-0.5 block">{asm.status}</span>
                </div>
                {asm.id ? (
                  <button
                    onClick={() => onNavigate("assessments", { assessmentId: asm.id })}
                    className="px-3 py-1 rounded-lg bg-cyan-500/10 hover:bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 text-xs font-semibold transition-colors"
                  >
                    Start Quiz
                  </button>
                ) : (
                  <span
                    className={`text-[11px] font-bold px-2 py-0.5 rounded border ${asm.badgeColor}`}
                  >
                    {asm.score}
                  </span>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
