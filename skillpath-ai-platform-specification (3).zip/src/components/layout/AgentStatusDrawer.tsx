"use client";

import React, { useState, useEffect } from "react";
import {
  X,
  Bot,
  Cpu,
  CheckCircle2,
  Clock,
  Sparkles,
  ArrowRight,
  ShieldCheck,
  RefreshCw,
  ChevronDown,
  ChevronUp,
} from "lucide-react";

interface AgentLog {
  id: string;
  agentName: string;
  agentRole: string;
  durationMs?: number;
  status: string;
  createdAt: string;
  inputPayload?: any;
  outputPayload?: any;
}

interface AgentStatusDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  isDemoMode: boolean;
}

export const AgentStatusDrawer: React.FC<AgentStatusDrawerProps> = ({
  isOpen,
  onClose,
  isDemoMode,
}) => {
  const [logs, setLogs] = useState<AgentLog[]>([]);
  const [loading, setLoading] = useState(false);
  const [expandedLogId, setExpandedLogId] = useState<string | null>(null);

  const agents = [
    {
      name: "Skill Analysis Agent",
      role: "Analyze user competencies, evaluate strengths/weaknesses, compute gaps %",
      status: "Active",
      color: "from-cyan-500 to-blue-500",
      tag: "Agent 1",
    },
    {
      name: "Career Matching Agent",
      role: "Match user skill vector against industry market benchmarks & requirements",
      status: "Active",
      color: "from-blue-500 to-indigo-500",
      tag: "Agent 2",
    },
    {
      name: "Learning Recommendation Agent",
      role: "Prioritize tailored courses, tutorials, exercises & mini-projects",
      status: "Active",
      color: "from-indigo-500 to-purple-500",
      tag: "Agent 3",
    },
    {
      name: "Learning Roadmap Agent",
      role: "Synthesize 5-phase progressive personalized syllabus with practical tasks",
      status: "Active",
      color: "from-purple-500 to-pink-500",
      tag: "Agent 4",
    },
    {
      name: "Progress Evaluation Agent",
      role: "Diagnose quiz performance, update skill proficiencies & prescribe revisions",
      status: "Active",
      color: "from-emerald-500 to-teal-500",
      tag: "Agent 5",
    },
    {
      name: "AI Mentor Agent",
      role: "Conversational coach providing 24/7 technical advice, code guidance & roadmap tweaks",
      status: "Active",
      color: "from-amber-500 to-orange-500",
      tag: "Agent 6",
    },
  ];

  const fetchLogs = async () => {
    try {
      setLoading(true);
      const res = await fetch("/api/agents/logs");
      if (res.ok) {
        const data = await res.json();
        setLogs(data.logs || []);
      }
    } catch (e) {
      console.error("Error fetching agent logs:", e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (isOpen) {
      fetchLogs();
    }
  }, [isOpen]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-black/60 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="w-full max-w-2xl bg-[#090d1a] border-l border-white/10 h-full flex flex-col shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="p-5 border-b border-white/10 flex items-center justify-between bg-slate-950/60">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-cyan-500 to-purple-600 flex items-center justify-center text-white shadow-md shadow-cyan-500/20">
              <Cpu className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-white text-base flex items-center gap-2">
                Multi-Agent AI Architecture
                <span className="text-[11px] font-semibold px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
                  6 Agents
                </span>
              </h3>
              <p className="text-xs text-slate-400">
                Central AI Orchestrator with structured JSON exchange
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={fetchLogs}
              disabled={loading}
              className="p-2 text-slate-400 hover:text-white rounded-lg hover:bg-white/5 transition-colors"
              title="Refresh logs"
            >
              <RefreshCw className={`w-4 h-4 ${loading ? "animate-spin" : ""}`} />
            </button>
            <button
              onClick={onClose}
              className="p-2 text-slate-400 hover:text-white rounded-lg hover:bg-white/5 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Content Tabs / Body */}
        <div className="flex-1 overflow-y-auto p-5 space-y-6">
          {/* Engine Status Banner */}
          <div className="p-4 rounded-xl bg-gradient-to-r from-slate-900 via-indigo-950/40 to-slate-900 border border-cyan-500/20 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-lg bg-cyan-500/20 flex items-center justify-center text-cyan-400">
                <Sparkles className="w-4 h-4" />
              </div>
              <div>
                <div className="text-xs font-semibold text-white">
                  Orchestrator Operational Mode
                </div>
                <div className="text-[11px] text-slate-300">
                  {isDemoMode
                    ? "Operating in Deterministic Demo Mode (Reliable hackathon testing)"
                    : "Live Google Gemini 1.5 Generative API active"}
                </div>
              </div>
            </div>
            <span
              className={`text-[10px] font-bold px-2.5 py-1 rounded-full uppercase tracking-wider ${
                isDemoMode
                  ? "bg-amber-500/20 text-amber-300 border border-amber-500/30"
                  : "bg-emerald-500/20 text-emerald-300 border border-emerald-500/30"
              }`}
            >
              {isDemoMode ? "Demo Mode" : "Gemini AI"}
            </span>
          </div>

          {/* 6 Specialized Agents Overview */}
          <div>
            <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-400 mb-3">
              Specialized Agent Cluster
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {agents.map((agent) => (
                <div
                  key={agent.name}
                  className="p-3.5 rounded-xl bg-slate-900/60 border border-white/5 hover:border-white/10 transition-colors"
                >
                  <div className="flex items-center justify-between mb-1.5">
                    <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-white/5 text-slate-300">
                      {agent.tag}
                    </span>
                    <span className="flex items-center gap-1 text-[10px] font-medium text-emerald-400">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                      {agent.status}
                    </span>
                  </div>
                  <div className="text-xs font-bold text-white mb-1">{agent.name}</div>
                  <p className="text-[11px] text-slate-400 line-clamp-2 leading-relaxed">
                    {agent.role}
                  </p>
                </div>
              ))}
            </div>
          </div>

          {/* Agent Execution Logs */}
          <div>
            <div className="flex items-center justify-between mb-3">
              <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-400">
                Agent Orchestration Log Stream
              </h4>
              <span className="text-[11px] text-slate-400">{logs.length} logged actions</span>
            </div>

            {loading && logs.length === 0 ? (
              <div className="p-8 text-center text-xs text-slate-400">
                <RefreshCw className="w-5 h-5 mx-auto animate-spin mb-2 text-cyan-400" />
                Loading agent telemetry...
              </div>
            ) : logs.length === 0 ? (
              <div className="p-6 rounded-xl bg-slate-900/40 border border-white/5 text-center text-xs text-slate-400">
                No recent agent logs found. Click "Run AI Orchestrator" in the top bar to trigger a fresh multi-agent cycle.
              </div>
            ) : (
              <div className="space-y-2.5">
                {logs.map((log) => {
                  const isExpanded = expandedLogId === log.id;
                  return (
                    <div
                      key={log.id}
                      className="rounded-xl bg-slate-900/70 border border-white/10 overflow-hidden"
                    >
                      <button
                        onClick={() => setExpandedLogId(isExpanded ? null : log.id)}
                        className="w-full p-3 flex items-center justify-between text-left hover:bg-white/5 transition-colors"
                      >
                        <div className="flex items-center gap-2.5">
                          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                          <div>
                            <div className="text-xs font-semibold text-white flex items-center gap-2">
                              {log.agentName}
                              {log.durationMs ? (
                                <span className="text-[10px] text-slate-400 font-normal">
                                  ({log.durationMs}ms)
                                </span>
                              ) : null}
                            </div>
                            <div className="text-[11px] text-slate-400 truncate max-w-sm">
                              {log.agentRole}
                            </div>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <span className="text-[10px] text-slate-400">
                            {new Date(log.createdAt).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" })}
                          </span>
                          {isExpanded ? (
                            <ChevronUp className="w-4 h-4 text-slate-400" />
                          ) : (
                            <ChevronDown className="w-4 h-4 text-slate-400" />
                          )}
                        </div>
                      </button>

                      {isExpanded && (
                        <div className="p-3 bg-slate-950/80 border-t border-white/5 text-[11px] space-y-2 font-mono">
                          {log.inputPayload && (
                            <div>
                              <div className="text-slate-400 font-semibold mb-1 text-[10px] uppercase">
                                Input Payload
                              </div>
                              <pre className="p-2 rounded bg-black/50 text-cyan-300 overflow-x-auto max-h-36">
                                {JSON.stringify(log.inputPayload, null, 2)}
                              </pre>
                            </div>
                          )}
                          {log.outputPayload && (
                            <div>
                              <div className="text-slate-400 font-semibold mb-1 text-[10px] uppercase">
                                Output Payload
                              </div>
                              <pre className="p-2 rounded bg-black/50 text-emerald-300 overflow-x-auto max-h-36">
                                {JSON.stringify(log.outputPayload, null, 2)}
                              </pre>
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
