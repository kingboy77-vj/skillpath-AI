"use client";

import React from "react";
import {
  Sparkles,
  Bot,
  RefreshCw,
  Cpu,
  Layers,
  Menu,
  ShieldCheck,
  Zap,
} from "lucide-react";
import { NavTab } from "./Sidebar";

interface NavbarProps {
  currentTab: NavTab;
  isOrchestrating: boolean;
  onRunOrchestrator: () => void;
  onOpenAgentLogs: () => void;
  isDemoMode: boolean;
  onToggleMobileMenu?: () => void;
  careerTitle?: string;
}

const tabTitles: Record<NavTab, { title: string; subtitle: string }> = {
  dashboard: {
    title: "Master Learner Dashboard",
    subtitle: "AI-driven overview of skill acquisition, target readiness, and pending milestones.",
  },
  profile: {
    title: "My Learner Profile",
    subtitle: "Manage technical competencies, academic background, projects, and target career goals.",
  },
  skills: {
    title: "Skill Gap Analysis",
    subtitle: "Visual radar & proficiency comparison of your skills versus market expectations.",
  },
  careers: {
    title: "Career Explorer",
    subtitle: "Compare in-demand tech roles, required proficiencies, and switch your active target career.",
  },
  roadmap: {
    title: "Personalized Learning Roadmap",
    subtitle: "5-phase structured progressive curriculum dynamically maintained by AI agents.",
  },
  resources: {
    title: "Personalized Learning Resources",
    subtitle: "Curated courses, video tutorials, exercises, and mini-projects prioritized by skill gaps.",
  },
  assessments: {
    title: "Skill Assessments & Quizzes",
    subtitle: "Topic-wise technical tests evaluated instantly by the Progress Evaluation Agent.",
  },
  progress: {
    title: "Progress & Analytics",
    subtitle: "Quantitative tracking of study hours, quiz trends, and career readiness trajectory.",
  },
  mentor: {
    title: "AI Mentor Chatbot",
    subtitle: "Interactive context-aware coach to explain concepts, guide code, and update your roadmap.",
  },
  settings: {
    title: "Platform Settings & AI Configuration",
    subtitle: "Configure Gemini API credentials, models, and demo mode preferences.",
  },
};

export const Navbar: React.FC<NavbarProps> = ({
  currentTab,
  isOrchestrating,
  onRunOrchestrator,
  onOpenAgentLogs,
  isDemoMode,
  onToggleMobileMenu,
  careerTitle,
}) => {
  const current = tabTitles[currentTab] || {
    title: "SkillPath AI",
    subtitle: "Agentic AI Personalized Learning Platform",
  };

  return (
    <header className="sticky top-0 z-20 bg-black/70 backdrop-blur-xl border-b border-white/10 px-4 sm:px-6 py-3.5 flex items-center justify-between gap-4">
      <div className="flex items-center gap-3">
        {onToggleMobileMenu && (
          <button
            onClick={onToggleMobileMenu}
            className="md:hidden p-2 rounded-lg bg-white/5 text-slate-300 hover:text-white"
          >
            <Menu className="w-5 h-5" />
          </button>
        )}
        <div>
          <h2 className="text-base sm:text-lg font-bold text-white tracking-tight flex items-center gap-2">
            {current.title}
            {careerTitle && currentTab === "dashboard" && (
              <span className="hidden sm:inline-flex items-center gap-1 text-[11px] font-medium px-2 py-0.5 rounded-full bg-cyan-500/15 text-cyan-300 border border-cyan-500/30">
                <Zap className="w-3 h-3 text-cyan-400" />
                {careerTitle}
              </span>
            )}
          </h2>
          <p className="text-xs text-slate-400 hidden sm:block truncate max-w-xl">
            {current.subtitle}
          </p>
        </div>
      </div>

      <div className="flex items-center gap-2.5 sm:gap-3">
        {/* Multi-Agent Status Pill */}
        <button
          onClick={onOpenAgentLogs}
          className="hidden md:flex items-center gap-2 px-3 py-1.5 rounded-xl bg-slate-900/90 border border-white/10 hover:border-cyan-500/40 text-xs transition-colors"
          title="Click to view AI Agent Execution Logs"
        >
          <span className="relative flex h-2 w-2">
            <span
              className={`animate-ping absolute inline-flex h-full w-full rounded-full ${
                isDemoMode ? "bg-amber-400 opacity-75" : "bg-emerald-400 opacity-75"
              }`}
            />
            <span
              className={`relative inline-flex rounded-full h-2 w-2 ${
                isDemoMode ? "bg-amber-500" : "bg-emerald-500"
              }`}
            />
          </span>
          <span className="text-slate-300 font-medium">
            {isDemoMode ? "Demo Mode (Deterministic)" : "Gemini API Multi-Agent"}
          </span>
          <Cpu className="w-3.5 h-3.5 text-cyan-400 ml-0.5" />
        </button>

        {/* View Agents Drawer Button */}
        <button
          onClick={onOpenAgentLogs}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-purple-950/40 hover:bg-purple-900/50 border border-purple-500/30 text-purple-300 text-xs font-medium transition-all shadow-sm"
        >
          <Bot className="w-3.5 h-3.5 text-purple-400" />
          <span className="hidden sm:inline">6 AI Agents</span>
          <span className="sm:hidden">Agents</span>
        </button>

        {/* Central Orchestrator Trigger Button */}
        <button
          onClick={onRunOrchestrator}
          disabled={isOrchestrating}
          className="flex items-center gap-2 px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-cyan-500 via-blue-600 to-indigo-600 hover:from-cyan-400 hover:to-indigo-500 text-white text-xs font-semibold shadow-lg shadow-cyan-500/20 active:scale-95 transition-all disabled:opacity-60 disabled:cursor-not-allowed"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${isOrchestrating ? "animate-spin" : ""}`} />
          <span>{isOrchestrating ? "Orchestrating..." : "Run AI Orchestrator"}</span>
        </button>
      </div>
    </header>
  );
};
