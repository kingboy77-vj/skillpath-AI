"use client";

import React from "react";
import {
  LayoutDashboard,
  User,
  Radar,
  Compass,
  Map,
  BookOpen,
  CheckCircle2,
  TrendingUp,
  Bot,
  Settings,
  Sparkles,
  LogOut,
  ChevronRight,
  Home,
} from "lucide-react";

export type NavTab =
  | "dashboard"
  | "profile"
  | "skills"
  | "careers"
  | "roadmap"
  | "resources"
  | "assessments"
  | "progress"
  | "mentor"
  | "settings";

interface SidebarProps {
  currentTab: NavTab;
  onSelectTab: (tab: NavTab) => void;
  user: { fullName?: string; email?: string; targetCareerName?: string } | null;
  onLogout: () => void;
  onOpenAuth: () => void;
  onGoHome?: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentTab,
  onSelectTab,
  user,
  onLogout,
  onOpenAuth,
  onGoHome,
}) => {
  const navItems = [
    { id: "dashboard", label: "Dashboard", icon: LayoutDashboard, badge: null },
    { id: "profile", label: "My Profile", icon: User, badge: null },
    { id: "skills", label: "Skill Analysis", icon: Radar, badge: "AI" },
    { id: "careers", label: "Career Explorer", icon: Compass, badge: "7" },
    { id: "roadmap", label: "Learning Roadmap", icon: Map, badge: "5 Ph" },
    { id: "resources", label: "Learning Resources", icon: BookOpen, badge: null },
    { id: "assessments", label: "Assessments", icon: CheckCircle2, badge: "Quiz" },
    { id: "progress", label: "Progress Tracking", icon: TrendingUp, badge: null },
    { id: "mentor", label: "AI Mentor", icon: Bot, badge: "Live" },
    { id: "settings", label: "Settings", icon: Settings, badge: null },
  ] as const;

  return (
    <aside className="w-64 bg-black/85 backdrop-blur-xl border-r border-white/10 flex flex-col h-screen sticky top-0 z-30 select-none">
      {/* Brand Header */}
      <div className="p-5 border-b border-white/10 flex items-center justify-between">
        <button onClick={onGoHome} className="flex items-center gap-3 text-left group">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-cyan-400 via-blue-600 to-purple-600 flex items-center justify-center shadow-[0_0_20px_rgba(56,189,248,0.4)] relative group-hover:shadow-[0_0_28px_rgba(56,189,248,0.65)] transition-shadow">
            <Sparkles className="w-5 h-5 text-white" />
            <span className="absolute -top-1 -right-1 w-2 h-2 rounded-full bg-white animate-twinkle" />
          </div>
          <div>
            <h1 className="font-bold text-lg text-white tracking-tight flex items-center gap-1.5">
              SkillPath <span className="text-cyan-400">AI</span>
            </h1>
            <p className="text-[10px] text-slate-400 font-medium tracking-wide uppercase">
              Agentic Learning Engine
            </p>
          </div>
        </button>
      </div>

      {onGoHome && (
        <div className="px-3 pt-3">
          <button
            onClick={onGoHome}
            className="w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs font-medium text-slate-300 hover:text-white hover:bg-white/5 border border-transparent hover:border-white/10 transition-all"
          >
            <Home className="w-4 h-4 text-cyan-400" />
            <span>Back to Home</span>
          </button>
        </div>
      )}

      {/* Navigation List */}
      <div className="flex-1 overflow-y-auto px-3 py-4 space-y-1">
        <div className="px-3 pb-2 text-[11px] font-semibold tracking-wider text-slate-400 uppercase">
          Navigation
        </div>
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = currentTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => onSelectTab(item.id as NavTab)}
              className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-sm font-medium transition-all group ${
                isActive
                  ? "bg-gradient-to-r from-cyan-500/20 to-purple-500/20 text-cyan-300 border border-cyan-500/30 shadow-sm"
                  : "text-slate-300 hover:text-white hover:bg-white/5"
              }`}
            >
              <div className="flex items-center gap-3">
                <Icon
                  className={`w-4 h-4 transition-colors ${
                    isActive ? "text-cyan-400" : "text-slate-400 group-hover:text-slate-200"
                  }`}
                />
                <span>{item.label}</span>
              </div>
              <div className="flex items-center gap-1.5">
                {item.badge && (
                  <span
                    className={`text-[10px] px-1.5 py-0.5 rounded-md font-semibold ${
                      item.badge === "Live"
                        ? "bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 animate-pulse"
                        : "bg-purple-500/20 text-purple-300 border border-purple-500/30"
                    }`}
                  >
                    {item.badge}
                  </span>
                )}
                {isActive && <ChevronRight className="w-3.5 h-3.5 text-cyan-400" />}
              </div>
            </button>
          );
        })}
      </div>

      {/* Target Career Pill in Sidebar */}
      <div className="px-3 pb-3">
        <div className="p-3 rounded-xl bg-slate-900/80 border border-white/5 text-xs">
          <div className="text-[10px] text-slate-400 font-semibold uppercase tracking-wider">
            Target Career
          </div>
          <div className="font-semibold text-white mt-1 truncate flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-cyan-400 animate-ping" />
            {user?.targetCareerName || "Full Stack Developer"}
          </div>
        </div>
      </div>

      {/* User Footer Profile */}
      <div className="p-3 border-t border-white/10 bg-slate-950/60">
        {user ? (
          <div className="flex items-center justify-between">
            <div
              onClick={() => onSelectTab("profile")}
              className="flex items-center gap-2.5 overflow-hidden cursor-pointer group"
            >
              <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-cyan-400 to-indigo-600 flex items-center justify-center text-white font-bold text-xs ring-1 ring-white/20">
                {user.fullName ? user.fullName[0].toUpperCase() : "A"}
              </div>
              <div className="truncate">
                <div className="text-xs font-semibold text-white group-hover:text-cyan-300 transition-colors truncate">
                  {user.fullName || "Alex"}
                </div>
                <div className="text-[10px] text-slate-400 truncate">{user.email || "demo user"}</div>
              </div>
            </div>
            <button
              onClick={onLogout}
              title="Log out"
              className="p-1.5 text-slate-400 hover:text-rose-400 rounded-lg hover:bg-white/5 transition-colors"
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        ) : (
          <button
            onClick={onOpenAuth}
            className="w-full py-2 px-3 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 text-xs font-semibold text-white shadow hover:opacity-95 transition-opacity"
          >
            Sign In / Switch Demo
          </button>
        )}
      </div>
    </aside>
  );
};
