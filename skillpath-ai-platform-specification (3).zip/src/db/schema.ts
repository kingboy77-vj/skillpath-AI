import { pgTable, text, integer, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";

export const profiles = pgTable("profiles", {
  id: text("id").primaryKey(),
  email: text("email").notNull().unique(),
  passwordHash: text("password_hash").notNull(),
  fullName: text("full_name").notNull(),
  educationLevel: text("education_level").default("Computer Science Student"),
  collegeOrOrg: text("college_or_org").default("State University of Technology"),
  certifications: jsonb("certifications").$type<string[]>().default([]),
  completedProjects: jsonb("completed_projects").$type<{ title: string; description: string; tech: string[] }[]>().default([]),
  workExperience: text("work_experience").default("Aspiring Software Engineer / Academic Projects"),
  learningInterests: jsonb("learning_interests").$type<string[]>().default([]),
  targetCareerId: text("target_career_id").default("full-stack-developer"),
  targetCareerName: text("target_career_name").default("Full Stack Developer"),
  preferredLearningStyle: text("preferred_learning_style").default("Hands-on Projects"),
  avatarUrl: text("avatar_url"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
});

export const skills = pgTable("skills", {
  id: text("id").primaryKey(),
  name: text("name").notNull().unique(),
  category: text("category").notNull(),
  description: text("description"),
  icon: text("icon"),
  popularLevel: text("popular_level").default("Intermediate"),
});

export const userSkills = pgTable("user_skills", {
  id: text("id").primaryKey(),
  userId: text("user_id").notNull().references(() => profiles.id, { onDelete: "cascade" }),
  skillId: text("skill_id").notNull().references(() => skills.id, { onDelete: "cascade" }),
  skillName: text("skill_name").notNull(),
  proficiencyLevel: text("proficiency_level").notNull(), // 'Beginner' | 'Intermediate' | 'Advanced' | 'Expert'
  score: integer("score").default(50).notNull(), // 0 to 100
  verified: boolean("verified").default(false).notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export const careers = pgTable("careers", {
  id: text("id").primaryKey(),
  title: text("title").notNull(),
  slug: text("slug").notNull().unique(),
  description: text("description").notNull(),
  category: text("category").notNull(),
  averageSalary: text("average_salary").notNull(),
  growthRate: text("growth_rate").notNull(),
  icon: text("icon"),
  recommendedTechnologies: jsonb("recommended_technologies").$type<string[]>().default([]).notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export const careerRequirements = pgTable("career_requirements", {
  id: text("id").primaryKey(),
  careerId: text("career_id").notNull().references(() => careers.id, { onDelete: "cascade" }),
  skillId: text("skill_id").notNull().references(() => skills.id, { onDelete: "cascade" }),
  skillName: text("skill_name").notNull(),
  requiredProficiency: text("required_proficiency").notNull(), // 'Beginner' | 'Intermediate' | 'Advanced'
  importance: text("importance").notNull(), // 'Critical' | 'Important' | 'Recommended'
  weight: integer("weight").default(1).notNull(),
});

export const assessments = pgTable("assessments", {
  id: text("id").primaryKey(),
  title: text("title").notNull(),
  slug: text("slug").notNull().unique(),
  skillId: text("skill_id").references(() => skills.id),
  skillName: text("skill_name").notNull(),
  difficulty: text("difficulty").notNull(),
  timeLimitMins: integer("time_limit_mins").default(15).notNull(),
  description: text("description"),
  totalQuestions: integer("total_questions").default(5).notNull(),
});

export const assessmentQuestions = pgTable("assessment_questions", {
  id: text("id").primaryKey(),
  assessmentId: text("assessment_id").notNull().references(() => assessments.id, { onDelete: "cascade" }),
  questionText: text("question_text").notNull(),
  options: jsonb("options").$type<string[]>().notNull(),
  correctOptionIndex: integer("correct_option_index").notNull(),
  explanation: text("explanation").notNull(),
  topic: text("topic"),
  difficulty: text("difficulty"),
});

export const assessmentResults = pgTable("assessment_results", {
  id: text("id").primaryKey(),
  userId: text("user_id").notNull().references(() => profiles.id, { onDelete: "cascade" }),
  assessmentId: text("assessment_id").notNull().references(() => assessments.id, { onDelete: "cascade" }),
  assessmentTitle: text("assessment_title").notNull(),
  score: integer("score").notNull(),
  totalQuestions: integer("total_questions").notNull(),
  percentage: integer("percentage").notNull(),
  passed: boolean("passed").notNull(),
  answers: jsonb("answers").$type<number[]>().notNull(),
  agentFeedback: jsonb("agent_feedback").$type<{
    summary: string;
    strengths: string[];
    topicsToReview: string[];
    recommendedAction: string;
    newProficiencyLevel?: string;
  }>(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export const learningResources = pgTable("learning_resources", {
  id: text("id").primaryKey(),
  title: text("title").notNull(),
  category: text("category").notNull(),
  skillId: text("skill_id").references(() => skills.id),
  skillName: text("skill_name").notNull(),
  difficultyLevel: text("difficulty_level").notNull(),
  type: text("type").notNull(), // 'Course' | 'Video Tutorial' | 'Documentation' | 'Coding Exercise' | 'Mini-Project'
  provider: text("provider").notNull(),
  estimatedDuration: text("estimated_duration").notNull(),
  resourceUrl: text("resource_url").notNull(),
  learningObjective: text("learning_objective").notNull(),
  rating: text("rating").default("4.8"),
  isFree: boolean("is_free").default(true).notNull(),
});

export const learningRoadmaps = pgTable("learning_roadmaps", {
  id: text("id").primaryKey(),
  userId: text("user_id").notNull().references(() => profiles.id, { onDelete: "cascade" }),
  careerId: text("career_id").notNull().references(() => careers.id),
  careerTitle: text("career_title").notNull(),
  readinessScore: integer("readiness_score").default(0).notNull(),
  status: text("status").default("active").notNull(),
  totalPhases: integer("total_phases").default(5).notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
});

export const roadmapTasks = pgTable("roadmap_tasks", {
  id: text("id").primaryKey(),
  roadmapId: text("roadmap_id").notNull().references(() => learningRoadmaps.id, { onDelete: "cascade" }),
  phaseNumber: integer("phase_number").notNull(), // 1 to 5
  phaseTitle: text("phase_title").notNull(),
  phaseDescription: text("phase_description"),
  title: text("title").notNull(),
  skillsToLearn: jsonb("skills_to_learn").$type<string[]>().default([]).notNull(),
  topics: jsonb("topics").$type<string[]>().default([]).notNull(),
  practicalTasks: jsonb("practical_tasks").$type<string[]>().default([]).notNull(),
  resourceId: text("resource_id"),
  resourceTitle: text("resource_title"),
  resourceUrl: text("resource_url"),
  assessmentId: text("assessment_id"),
  completed: boolean("completed").default(false).notNull(),
  orderIndex: integer("order_index").default(0).notNull(),
  completedAt: timestamp("completed_at", { withTimezone: true }),
});

export const userProgress = pgTable("user_progress", {
  id: text("id").primaryKey(),
  userId: text("user_id").notNull().unique().references(() => profiles.id, { onDelete: "cascade" }),
  careerReadiness: integer("career_readiness").default(35).notNull(),
  totalSkillsAcquired: integer("total_skills_acquired").default(3).notNull(),
  missingSkillsCount: integer("missing_skills_count").default(6).notNull(),
  roadmapCompletionPct: integer("roadmap_completion_pct").default(12).notNull(),
  weeklyHours: jsonb("weekly_hours").$type<{ day: string; hours: number }[]>().default([]).notNull(),
  monthlyActivity: jsonb("monthly_activity").$type<{ week: string; tasksCompleted: number; scoreAvg: number }[]>().default([]).notNull(),
  lastActiveAt: timestamp("last_active_at", { withTimezone: true }).defaultNow().notNull(),
});

export const aiAgentLogs = pgTable("ai_agent_logs", {
  id: text("id").primaryKey(),
  userId: text("user_id").references(() => profiles.id, { onDelete: "cascade" }),
  agentName: text("agent_name").notNull(),
  agentRole: text("agent_role").notNull(),
  inputPayload: jsonb("input_payload"),
  outputPayload: jsonb("output_payload"),
  status: text("status").default("success").notNull(),
  durationMs: integer("duration_ms").default(0),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export const chatMessages = pgTable("chat_messages", {
  id: text("id").primaryKey(),
  userId: text("user_id").notNull().references(() => profiles.id, { onDelete: "cascade" }),
  sender: text("sender").notNull(), // 'user' | 'ai_mentor'
  message: text("message").notNull(),
  metadata: jsonb("metadata").$type<{
    agentSource?: string;
    suggestedActions?: { label: string; action: string; payload?: unknown }[];
    recommendedSkills?: string[];
  }>(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export const systemSettings = pgTable("system_settings", {
  id: text("id").primaryKey(),
  geminiApiKey: text("gemini_api_key"),
  youtubeApiKey: text("youtube_api_key"),
  preferredModel: text("preferred_model").default("gemini-1.5-flash").notNull(),
  demoModeOverride: boolean("demo_mode_override").default(false).notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
});
