import { db } from "./index";
import {
  profiles,
  skills,
  userSkills,
  careers,
  careerRequirements,
  assessments,
  assessmentQuestions,
  assessmentResults,
  learningResources,
  learningRoadmaps,
  roadmapTasks,
  userProgress,
  aiAgentLogs,
  chatMessages,
  systemSettings,
} from "./schema";
import { eq } from "drizzle-orm";

export async function seedDatabase() {
  // Check if already seeded
  const existingProfile = await db.select().from(profiles).where(eq(profiles.id, "usr_alex_001"));
  if (existingProfile.length > 0) {
    return;
  }

  console.log("Seeding database with King Skill AI data...");

  // 1. System Settings
  await db.insert(systemSettings).values({
    id: "system_default",
    geminiApiKey: process.env.GEMINI_API_KEY || null,
    youtubeApiKey: process.env.YOUTUBE_API_KEY || null,
    preferredModel: "gemini-1.5-flash",
    demoModeOverride: false,
  }).onConflictDoNothing();

  // 2. Skills
  const skillList = [
    { id: "sk_python", name: "Python", category: "Programming", description: "General purpose high-level programming language", icon: "Code2" },
    { id: "sk_sql", name: "SQL", category: "Database", description: "Structured Query Language for relational databases", icon: "Database" },
    { id: "sk_html", name: "HTML", category: "Frontend", description: "Standard markup language for web browser documents", icon: "Layout" },
    { id: "sk_css", name: "CSS", category: "Frontend", description: "Cascading Style Sheets for layout & UI styling", icon: "Palette" },
    { id: "sk_javascript", name: "JavaScript", category: "Programming", description: "Core scripting language for web development", icon: "Braces" },
    { id: "sk_typescript", name: "TypeScript", category: "Programming", description: "Typed superset of JavaScript", icon: "FileCode2" },
    { id: "sk_react", name: "React", category: "Frontend", description: "Declarative UI component library", icon: "Layers" },
    { id: "sk_nodejs", name: "Node.js", category: "Backend", description: "JavaScript runtime built on Chrome V8 engine", icon: "Server" },
    { id: "sk_express", name: "Express.js", category: "Backend", description: "Fast, unopinionated web framework for Node.js", icon: "Cpu" },
    { id: "sk_git", name: "Git", category: "Tools", description: "Distributed version control system", icon: "GitBranch" },
    { id: "sk_rest_api", name: "REST APIs", category: "Backend", description: "Representational State Transfer web services", icon: "Network" },
    { id: "sk_docker", name: "Docker", category: "Cloud", description: "Containerization platform for application packaging", icon: "Container" },
    { id: "sk_aws", name: "AWS", category: "Cloud", description: "Amazon Web Services cloud platform", icon: "Cloud" },
    { id: "sk_ml", name: "Machine Learning", category: "AI/ML", description: "Algorithms that learn patterns from training data", icon: "BrainCircuit" },
    { id: "sk_pytorch", name: "PyTorch", category: "AI/ML", description: "Deep learning framework for tensor computation", icon: "Workflow" },
    { id: "sk_cybersecurity", name: "Cybersecurity", category: "Security", description: "Information protection and security protocols", icon: "ShieldAlert" },
    { id: "sk_react_native", name: "React Native", category: "Mobile", description: "Cross-platform native mobile application framework", icon: "Smartphone" },
    { id: "sk_mongodb", name: "MongoDB", category: "Database", description: "NoSQL document database", icon: "Boxes" },
  ];

  for (const s of skillList) {
    await db.insert(skills).values(s).onConflictDoNothing();
  }

  // 3. Careers
  const careerList = [
    {
      id: "full-stack-developer",
      title: "Full Stack Developer",
      slug: "full-stack-developer",
      description: "Builds responsive client-side user interfaces, robust backend servers, APIs, and manages relational & non-relational database schemas.",
      category: "Software Engineering",
      averageSalary: "$115,000 / yr",
      growthRate: "+22% (Faster than avg)",
      icon: "Layers",
      recommendedTechnologies: ["HTML", "CSS", "JavaScript", "React", "Node.js", "Express.js", "SQL", "Git", "REST APIs"],
    },
    {
      id: "ai-engineer",
      title: "AI Engineer",
      slug: "ai-engineer",
      description: "Designs, trains, deploys, and fine-tunes artificial intelligence and large language model architectures into production systems.",
      category: "Artificial Intelligence",
      averageSalary: "$145,000 / yr",
      growthRate: "+38% (High Demand)",
      icon: "BrainCircuit",
      recommendedTechnologies: ["Python", "Machine Learning", "PyTorch", "Docker", "REST APIs", "SQL", "Git"],
    },
    {
      id: "data-scientist",
      title: "Data Scientist",
      slug: "data-scientist",
      description: "Extracts actionable predictive insights, statistical trends, and analytical models from massive structured and unstructured datasets.",
      category: "Data & Analytics",
      averageSalary: "$128,000 / yr",
      growthRate: "+28% (High Demand)",
      icon: "BarChart3",
      recommendedTechnologies: ["Python", "SQL", "Machine Learning", "Git", "REST APIs"],
    },
    {
      id: "web-developer",
      title: "Web Developer",
      slug: "web-developer",
      description: "Specializes in crafting modern, high-speed, accessible, and intuitive front-of-the-glass web applications and websites.",
      category: "Frontend Development",
      averageSalary: "$98,000 / yr",
      growthRate: "+18%",
      icon: "Globe",
      recommendedTechnologies: ["HTML", "CSS", "JavaScript", "React", "Git", "REST APIs"],
    },
    {
      id: "cloud-engineer",
      title: "Cloud Engineer",
      slug: "cloud-engineer",
      description: "Architects scalable, fault-tolerant cloud infrastructure, CI/CD deployment pipelines, and manages container orchestration.",
      category: "DevOps & Cloud",
      averageSalary: "$132,000 / yr",
      growthRate: "+25%",
      icon: "Cloud",
      recommendedTechnologies: ["AWS", "Docker", "Linux", "Python", "Git", "REST APIs"],
    },
    {
      id: "cybersecurity-analyst",
      title: "Cybersecurity Analyst",
      slug: "cybersecurity-analyst",
      description: "Monitors, analyzes, and safeguards enterprise networks, cloud assets, and software endpoints against unauthorized intrusion.",
      category: "Information Security",
      averageSalary: "$118,000 / yr",
      growthRate: "+32%",
      icon: "ShieldAlert",
      recommendedTechnologies: ["Cybersecurity", "Python", "Linux", "Git", "SQL"],
    },
    {
      id: "mobile-app-developer",
      title: "Mobile App Developer",
      slug: "mobile-app-developer",
      description: "Engineers fluid, performant native and cross-platform smartphone applications for iOS and Android ecosystems.",
      category: "Mobile Development",
      averageSalary: "$112,000 / yr",
      growthRate: "+20%",
      icon: "Smartphone",
      recommendedTechnologies: ["React Native", "JavaScript", "TypeScript", "REST APIs", "Git"],
    },
  ];

  for (const c of careerList) {
    await db.insert(careers).values(c).onConflictDoNothing();
  }

  // 4. Career Requirements (specifically for Full Stack Developer and others)
  const fullstackReqs = [
    { id: "cr_fs_html", careerId: "full-stack-developer", skillId: "sk_html", skillName: "HTML", requiredProficiency: "Intermediate", importance: "Critical", weight: 8 },
    { id: "cr_fs_css", careerId: "full-stack-developer", skillId: "sk_css", skillName: "CSS", requiredProficiency: "Intermediate", importance: "Critical", weight: 9 },
    { id: "cr_fs_js", careerId: "full-stack-developer", skillId: "sk_javascript", skillName: "JavaScript", requiredProficiency: "Advanced", importance: "Critical", weight: 15 },
    { id: "cr_fs_react", careerId: "full-stack-developer", skillId: "sk_react", skillName: "React", requiredProficiency: "Intermediate", importance: "Critical", weight: 14 },
    { id: "cr_fs_node", careerId: "full-stack-developer", skillId: "sk_nodejs", skillName: "Node.js", requiredProficiency: "Intermediate", importance: "Critical", weight: 14 },
    { id: "cr_fs_express", careerId: "full-stack-developer", skillId: "sk_express", skillName: "Express.js", requiredProficiency: "Intermediate", importance: "Critical", weight: 10 },
    { id: "cr_fs_sql", careerId: "full-stack-developer", skillId: "sk_sql", skillName: "SQL", requiredProficiency: "Intermediate", importance: "Critical", weight: 10 },
    { id: "cr_fs_git", careerId: "full-stack-developer", skillId: "sk_git", skillName: "Git", requiredProficiency: "Intermediate", importance: "Important", weight: 10 },
    { id: "cr_fs_api", careerId: "full-stack-developer", skillId: "sk_rest_api", skillName: "REST APIs", requiredProficiency: "Advanced", importance: "Critical", weight: 10 },
  ];

  for (const cr of fullstackReqs) {
    await db.insert(careerRequirements).values(cr).onConflictDoNothing();
  }

  // Other careers requirements
  const aiReqs = [
    { id: "cr_ai_py", careerId: "ai-engineer", skillId: "sk_python", skillName: "Python", requiredProficiency: "Advanced", importance: "Critical", weight: 20 },
    { id: "cr_ai_ml", careerId: "ai-engineer", skillId: "sk_ml", skillName: "Machine Learning", requiredProficiency: "Advanced", importance: "Critical", weight: 25 },
    { id: "cr_ai_pt", careerId: "ai-engineer", skillId: "sk_pytorch", skillName: "PyTorch", requiredProficiency: "Intermediate", importance: "Critical", weight: 20 },
    { id: "cr_ai_sql", careerId: "ai-engineer", skillId: "sk_sql", skillName: "SQL", requiredProficiency: "Intermediate", importance: "Important", weight: 15 },
    { id: "cr_ai_api", careerId: "ai-engineer", skillId: "sk_rest_api", skillName: "REST APIs", requiredProficiency: "Intermediate", importance: "Important", weight: 10 },
    { id: "cr_ai_git", careerId: "ai-engineer", skillId: "sk_git", skillName: "Git", requiredProficiency: "Intermediate", importance: "Recommended", weight: 10 },
  ];
  for (const cr of aiReqs) {
    await db.insert(careerRequirements).values(cr).onConflictDoNothing();
  }

  // 5. Assessments & Assessment Questions
  const jsAssessment = {
    id: "asm_javascript_101",
    title: "JavaScript Core & Asynchronous Mechanics",
    slug: "javascript-core-assessment",
    skillId: "sk_javascript",
    skillName: "JavaScript",
    difficulty: "Intermediate",
    timeLimitMins: 12,
    description: "Evaluates understanding of closures, event loop, Promises, ES6+ syntax, and array methods.",
    totalQuestions: 5,
  };
  await db.insert(assessments).values(jsAssessment).onConflictDoNothing();

  const jsQuestions = [
    {
      id: "q_js_1",
      assessmentId: "asm_javascript_101",
      questionText: "What is the primary difference between 'let' and 'var' declarations in modern JavaScript?",
      options: [
        "'let' is function-scoped while 'var' is block-scoped.",
        "'let' is block-scoped and does not hoist initialize, while 'var' is function-scoped and hoisted with undefined.",
        "'var' cannot be reassigned once declared, whereas 'let' can.",
        "There is no difference; 'let' is merely syntactical sugar for 'var'."
      ],
      correctOptionIndex: 1,
      explanation: "'let' enforces block scope within curly brackets {} and resides in the Temporal Dead Zone until initialized. 'var' is hoisted to its enclosing function scope and initialized to undefined.",
      topic: "ES6 Variables & Scoping",
      difficulty: "Beginner",
    },
    {
      id: "q_js_2",
      assessmentId: "asm_javascript_101",
      questionText: "In the JavaScript Event Loop, which queue is processed first after the current call stack clears?",
      options: [
        "Macro-task Queue (setTimeout, setInterval)",
        "Micro-task Queue (Promises, queueMicrotask, MutationObserver)",
        "Rendering Queue (requestAnimationFrame)",
        "I/O polling callbacks"
      ],
      correctOptionIndex: 1,
      explanation: "Microtasks (such as resolved Promise .then() callbacks) have higher priority and will drain completely before the next macrotask is dequeued.",
      topic: "Event Loop & Asynchrony",
      difficulty: "Intermediate",
    },
    {
      id: "q_js_3",
      assessmentId: "asm_javascript_101",
      questionText: "What does Array.prototype.reduce() return if no initial value is provided?",
      options: [
        "undefined immediately",
        "It uses the first element of the array as accumulator and begins iteration at index 1",
        "An empty array []",
        "It throws a TypeError in every scenario"
      ],
      correctOptionIndex: 1,
      explanation: "When accumulator initialValue is omitted, reduce() assigns index 0 as initial accumulator and starts the reducer function at index 1. Note: if the array is empty, it throws a TypeError.",
      topic: "Functional Array Methods",
      difficulty: "Intermediate",
    },
    {
      id: "q_js_4",
      assessmentId: "asm_javascript_101",
      questionText: "How does a Closure work in JavaScript?",
      options: [
        "It is a method that encrypts local variables to prevent garbage collection.",
        "A function bundled with references to its lexical environment, allowing access to an outer scope even after the outer function has closed.",
        "A syntax error caused by unmatched closing braces.",
        "An asynchronous promise wrapper that auto-terminates after timeout."
      ],
      correctOptionIndex: 1,
      explanation: "A closure gives you access to an outer function's scope from an inner function. In JavaScript, closures are created every time a function is created, at function creation time.",
      topic: "Closures & Scope Chain",
      difficulty: "Intermediate",
    },
    {
      id: "q_js_5",
      assessmentId: "asm_javascript_101",
      questionText: "Which statement correctly handles potential rejections with async/await?",
      options: [
        "await catchError(asyncFn())",
        "try { await asyncFn(); } catch (err) { console.error(err); }",
        "asyncFn().wait().catch() inside sync block",
        "window.addEventListener('error', asyncFn)"
      ],
      correctOptionIndex: 1,
      explanation: "Standard try/catch blocks wrap awaited asynchronous promises to capture rejection exceptions cleanly and prevent unhandled promise rejection errors.",
      topic: "Async/Await Error Handling",
      difficulty: "Beginner",
    },
  ];

  for (const q of jsQuestions) {
    await db.insert(assessmentQuestions).values(q).onConflictDoNothing();
  }

  // React Assessment
  const reactAssessment = {
    id: "asm_react_101",
    title: "React Component Architecture & Hooks",
    slug: "react-core-assessment",
    skillId: "sk_react",
    skillName: "React",
    difficulty: "Intermediate",
    timeLimitMins: 15,
    description: "Tests mastery over state lifecycle, useEffect dependencies, custom hooks, and memoization.",
    totalQuestions: 5,
  };
  await db.insert(assessments).values(reactAssessment).onConflictDoNothing();

  const reactQuestions = [
    {
      id: "q_react_1",
      assessmentId: "asm_react_101",
      questionText: "Why shouldn't you mutate state directly, such as `state.items.push(newItem)`?",
      options: [
        "Because JavaScript arrays are immutable in strict mode.",
        "Direct mutations bypass React's shallow comparison, preventing component re-renders and causing subtle state sync bugs.",
        "It triggers an unhandled memory leak in the browser.",
        "React compiler will throw an uncatchable compile-time syntax error."
      ],
      correctOptionIndex: 1,
      explanation: "React relies on referential equality to detect state updates. Direct mutations retain the same memory reference, so React cannot detect changes or trigger necessary re-renders.",
      topic: "State Immutability",
      difficulty: "Beginner",
    },
    {
      id: "q_react_2",
      assessmentId: "asm_react_101",
      questionText: "What occurs if you pass an empty dependency array `[]` to `useEffect`?",
      options: [
        "The effect executes on every single render cycle.",
        "The effect runs once after the initial component mount and cleans up on unmount.",
        "The effect is cancelled and never executes.",
        "React throws an invalid dependency warning and breaks."
      ],
      correctOptionIndex: 1,
      explanation: "An empty dependency array indicates the effect depends on no state or props, so it only runs once after mount, similar to componentDidMount.",
      topic: "useEffect Lifecycle",
      difficulty: "Beginner",
    },
    {
      id: "q_react_3",
      assessmentId: "asm_react_101",
      questionText: "When should you use the `useCallback` hook in React?",
      options: [
        "For every inline function to make the entire application execute faster.",
        "To memoize a callback instance to prevent re-creating functions passed to memoized children or dependency arrays.",
        "To fetch data from backend servers automatically.",
        "To replace standard JavaScript try/catch statements."
      ],
      correctOptionIndex: 1,
      explanation: "useCallback caches function definitions between renders when passed to optimized child components relying on reference equality (React.memo).",
      topic: "Performance & Memoization",
      difficulty: "Intermediate",
    },
    {
      id: "q_react_4",
      assessmentId: "asm_react_101",
      questionText: "What is the primary role of the `key` prop when rendering dynamic lists in React?",
      options: [
        "It sets the HTML element id attribute.",
        "It uniquely identifies items to help React reconcile list additions, removals, and reordering efficiently.",
        "It automatically indexes elements in the Redux store.",
        "It provides CSS styling hooks."
      ],
      correctOptionIndex: 1,
      explanation: "Keys give React identity to list elements during Virtual DOM diffing, avoiding unnecessary DOM reconstructions.",
      topic: "Reconciliation & Keys",
      difficulty: "Beginner",
    },
    {
      id: "q_react_5",
      assessmentId: "asm_react_101",
      questionText: "What is React Context primarily intended for?",
      options: [
        "Replacing relational SQL databases.",
        "Sharing global data (like themes, auth user, localization) across component trees without prop drilling.",
        "Caching heavy arithmetic computations.",
        "Creating multi-threaded background worker processes."
      ],
      correctOptionIndex: 1,
      explanation: "Context provides a way to pass data through the component tree without having to pass props down manually at every level.",
      topic: "State Management & Context",
      difficulty: "Intermediate",
    },
  ];

  for (const q of reactQuestions) {
    await db.insert(assessmentQuestions).values(q).onConflictDoNothing();
  }

  // Node & REST APIs Assessment
  const nodeAssessment = {
    id: "asm_node_101",
    title: "Node.js & RESTful API Engineering",
    slug: "nodejs-rest-apis-assessment",
    skillId: "sk_nodejs",
    skillName: "Node.js",
    difficulty: "Intermediate",
    timeLimitMins: 15,
    description: "Assesses Express middleware pipelines, HTTP status codes, REST conventions, and asynchronous I/O.",
    totalQuestions: 5,
  };
  await db.insert(assessments).values(nodeAssessment).onConflictDoNothing();

  const nodeQuestions = [
    {
      id: "q_node_1",
      assessmentId: "asm_node_101",
      questionText: "Which HTTP status code is most appropriate when creating a new resource via a POST request?",
      options: ["200 OK", "201 Created", "204 No Content", "302 Found"],
      correctOptionIndex: 1,
      explanation: "201 Created signifies that the request succeeded and led to the creation of one or more new resources.",
      topic: "HTTP Standards",
      difficulty: "Beginner",
    },
    {
      id: "q_node_2",
      assessmentId: "asm_node_101",
      questionText: "In Express.js, what does calling `next()` inside middleware do?",
      options: [
        "Restarts the Node.js server process.",
        "Passes control to the next middleware function in the request-response cycle stack.",
        "Sends a 200 JSON response immediately to the client.",
        "Terminates the incoming HTTP socket."
      ],
      correctOptionIndex: 1,
      explanation: "next() hands execution to the next matching route handler or middleware function in the Express pipeline.",
      topic: "Express Middleware",
      difficulty: "Beginner",
    },
    {
      id: "q_node_3",
      assessmentId: "asm_node_101",
      questionText: "What makes Node.js non-blocking and single-threaded?",
      options: [
        "It uses a single thread for JavaScript execution alongside libuv's event loop and thread pool for asynchronous I/O operations.",
        "It runs multiple threads natively on every single function call.",
        "It disables all CPU concurrency.",
        "It relies exclusively on browser Web Workers."
      ],
      correctOptionIndex: 0,
      explanation: "Node.js runs JS execution on a single main thread while offloading asynchronous operations like file I/O, DNS, and crypto to libuv's thread pool.",
      topic: "Node Architecture",
      difficulty: "Intermediate",
    },
    {
      id: "q_node_4",
      assessmentId: "asm_node_101",
      questionText: "Which HTTP method should be used for idempotent full replacements of an existing resource?",
      options: ["PATCH", "POST", "PUT", "DELETE"],
      correctOptionIndex: 2,
      explanation: "PUT replaces an entire existing entity or creates it if non-existent, and is designed to be idempotent.",
      topic: "REST Conventions",
      difficulty: "Intermediate",
    },
    {
      id: "q_node_5",
      assessmentId: "asm_node_101",
      questionText: "How should CORS (Cross-Origin Resource Sharing) be handled in production Express backends?",
      options: [
        "Allow `Access-Control-Allow-Origin: *` unconditionally with credentials enabled.",
        "Configure CORS middleware with explicit allowed origins, methods, and credential headers.",
        "Disable HTTP completely.",
        "Force users to run reverse proxies locally."
      ],
      correctOptionIndex: 1,
      explanation: "Restricting CORS origins explicitly ensures web browsers only allow permitted client domains to execute authenticated API calls.",
      topic: "API Security",
      difficulty: "Intermediate",
    },
  ];

  for (const q of nodeQuestions) {
    await db.insert(assessmentQuestions).values(q).onConflictDoNothing();
  }

  // 6. Learning Resources
  const resourcesList = [
    {
      id: "res_js_mastery",
      title: "Modern JavaScript Deep Dive: From Fundamentals to ESNext",
      category: "Programming",
      skillId: "sk_javascript",
      skillName: "JavaScript",
      difficultyLevel: "Beginner",
      type: "Course",
      provider: "King Skill Academy",
      estimatedDuration: "14 hours",
      resourceUrl: "https://javascript.info",
      learningObjective: "Master closures, lexical scoping, event loop, promises, and modern ES6+ functional paradigms.",
      rating: "4.9",
      isFree: true,
    },
    {
      id: "res_css_flexgrid",
      title: "Responsive Web Layouts: Flexbox, CSS Grid & Tailwind Mastery",
      category: "Web Development",
      skillId: "sk_css",
      skillName: "CSS",
      difficultyLevel: "Beginner",
      type: "Video Tutorial",
      provider: "Frontend Masters",
      estimatedDuration: "8 hours",
      resourceUrl: "https://web.dev/learn/css",
      learningObjective: "Build modern, accessible, pixel-perfect responsive layouts and dynamic styling systems.",
      rating: "4.8",
      isFree: true,
    },
    {
      id: "res_react_official",
      title: "Interactive React 19: Full Architecture & Hooks",
      category: "Web Development",
      skillId: "sk_react",
      skillName: "React",
      difficultyLevel: "Intermediate",
      type: "Course",
      provider: "React Official Core Curriculum",
      estimatedDuration: "18 hours",
      resourceUrl: "https://react.dev/learn",
      learningObjective: "Understand component trees, hooks lifecycle, server state caching, and client performance.",
      rating: "5.0",
      isFree: true,
    },
    {
      id: "res_node_express",
      title: "Building Production-Ready REST APIs with Node.js & Express",
      category: "Web Development",
      skillId: "sk_nodejs",
      skillName: "Node.js",
      difficultyLevel: "Intermediate",
      type: "Course",
      provider: "Backend Pro",
      estimatedDuration: "16 hours",
      resourceUrl: "https://nodejs.org/en/learn",
      learningObjective: "Architect scalable Express routers, error handlers, authentication middleware, and input validators.",
      rating: "4.8",
      isFree: true,
    },
    {
      id: "res_git_github",
      title: "Git & Collaborative GitHub Workflows for Engineers",
      category: "Programming",
      skillId: "sk_git",
      skillName: "Git",
      difficultyLevel: "Beginner",
      type: "Video Tutorial",
      provider: "GitLab Learning",
      estimatedDuration: "5 hours",
      resourceUrl: "https://git-scm.com/book/en/v2",
      learningObjective: "Master branching, merging, rebasing, pull requests, resolving merge conflicts, and Git conventions.",
      rating: "4.9",
      isFree: true,
    },
    {
      id: "res_mini_ecommerce",
      title: "Full Stack Mini-Project: E-Commerce Store with Cart & Auth",
      category: "Web Development",
      skillId: "sk_react",
      skillName: "React",
      difficultyLevel: "Intermediate",
      type: "Mini-Project",
      provider: "King Skill Project Lab",
      estimatedDuration: "20 hours",
      resourceUrl: "https://github.com/topics/fullstack-ecommerce",
      learningObjective: "Integrate React frontend with Express REST backend and PostgreSQL database storage.",
      rating: "4.9",
      isFree: true,
    },
    {
      id: "res_sql_optim",
      title: "Advanced PostgreSQL: Indexing, Transactions & Query Tuning",
      category: "Database Management",
      skillId: "sk_sql",
      skillName: "SQL",
      difficultyLevel: "Advanced",
      type: "Course",
      provider: "Database Specialists",
      estimatedDuration: "10 hours",
      resourceUrl: "https://www.postgresql.org/docs/current/tutorial.html",
      learningObjective: "Write performant joins, CTEs, window functions, and optimize query execution plans.",
      rating: "4.9",
      isFree: true,
    },
    {
      id: "res_ai_ml_bootcamp",
      title: "Machine Learning with Python & Scikit-Learn Foundations",
      category: "Artificial Intelligence",
      skillId: "sk_ml",
      skillName: "Machine Learning",
      difficultyLevel: "Intermediate",
      type: "Course",
      provider: "AI Research Hub",
      estimatedDuration: "22 hours",
      resourceUrl: "https://scikit-learn.org/stable/tutorial/index.html",
      learningObjective: "Train supervised classification and regression models and evaluate statistical accuracy.",
      rating: "4.7",
      isFree: true,
    },
    {
      id: "res_docker_cloud",
      title: "Docker Containerization for Modern Web Apps",
      category: "Cloud Computing",
      skillId: "sk_docker",
      skillName: "Docker",
      difficultyLevel: "Beginner",
      type: "Coding Exercise",
      provider: "Cloud Native Labs",
      estimatedDuration: "7 hours",
      resourceUrl: "https://docs.docker.com/get-started/",
      learningObjective: "Containerize multi-container full stack web stacks with Dockerfiles and Docker Compose.",
      rating: "4.8",
      isFree: true,
    },
  ];

  for (const r of resourcesList) {
    await db.insert(learningResources).values(r).onConflictDoNothing();
  }

  // 7. Alex Demo Profile
  await db.insert(profiles).values({
    id: "usr_alex_001",
    email: "alex@kingskill.ai",
    passwordHash: "demo_password_hash",
    fullName: "Alex",
    educationLevel: "Computer Science Student",
    collegeOrOrg: "State University of Technology",
    certifications: ["Python Fundamentals"],
    completedProjects: [
      {
        title: "Student Management System",
        description: "A desktop application with Python and SQLite for managing student records, enrollment, and grade calculations.",
        tech: ["Python", "SQL", "Tkinter"],
      },
    ],
    workExperience: "Aspiring Full Stack Engineer / Academic Team Lead",
    learningInterests: ["Web Development", "Frontend Frameworks", "REST APIs", "Modern Cloud Architecture"],
    targetCareerId: "full-stack-developer",
    targetCareerName: "Full Stack Developer",
    preferredLearningStyle: "Hands-on Projects & Interactive Exercises",
    avatarUrl: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=256&q=80",
  }).onConflictDoNothing();

  // 8. User Skills for Alex:
  // Python: Intermediate, SQL: Intermediate, HTML: Beginner
  const alexSkills = [
    { id: "usk_alex_py", userId: "usr_alex_001", skillId: "sk_python", skillName: "Python", proficiencyLevel: "Intermediate", score: 70, verified: true },
    { id: "usk_alex_sql", userId: "usr_alex_001", skillId: "sk_sql", skillName: "SQL", proficiencyLevel: "Intermediate", score: 65, verified: true },
    { id: "usk_alex_html", userId: "usr_alex_001", skillId: "sk_html", skillName: "HTML", proficiencyLevel: "Beginner", score: 40, verified: false },
  ];

  for (const us of alexSkills) {
    await db.insert(userSkills).values(us).onConflictDoNothing();
  }

  // 9. Alex's Learning Roadmap (5 Phases)
  const roadmapId = "rdm_alex_fullstack_001";
  await db.insert(learningRoadmaps).values({
    id: roadmapId,
    userId: "usr_alex_001",
    careerId: "full-stack-developer",
    careerTitle: "Full Stack Developer",
    readinessScore: 35,
    status: "active",
    totalPhases: 5,
  }).onConflictDoNothing();

  const alexTasks = [
    // Phase 1: Beginner fundamentals
    {
      id: "tsk_p1_html_css",
      roadmapId,
      phaseNumber: 1,
      phaseTitle: "Phase 1: Beginner Fundamentals",
      phaseDescription: "Solidify HTML semantic foundations, modern CSS layout mechanics (Flexbox & Grid), and responsive design principles.",
      title: "Master Semantic HTML5 & Responsive CSS Layouts",
      skillsToLearn: ["HTML", "CSS"],
      topics: ["HTML5 semantic tags", "CSS Box Model", "Flexbox alignment", "CSS Grid template areas", "Mobile-first media queries"],
      practicalTasks: ["Build a multi-page responsive personal portfolio", "Implement fluid navigation drawer without JS libraries"],
      resourceId: "res_css_flexgrid",
      resourceTitle: "Responsive Web Layouts: Flexbox, CSS Grid & Tailwind Mastery",
      resourceUrl: "https://web.dev/learn/css",
      completed: true,
      orderIndex: 1,
    },
    {
      id: "tsk_p1_git_vcs",
      roadmapId,
      phaseNumber: 1,
      phaseTitle: "Phase 1: Beginner Fundamentals",
      phaseDescription: "Establish professional version control workflows and repository hygiene.",
      title: "Git Essentials & Collaborative Version Control",
      skillsToLearn: ["Git"],
      topics: ["Git init, stage, commit", "Feature branches", "Merge vs Rebase", "Pull request reviews", ".gitignore setup"],
      practicalTasks: ["Initialize GitHub repo with README and branch protection", "Resolve a simulated 3-way merge conflict"],
      resourceId: "res_git_github",
      resourceTitle: "Git & Collaborative GitHub Workflows for Engineers",
      resourceUrl: "https://git-scm.com/book/en/v2",
      completed: true,
      orderIndex: 2,
    },
    // Phase 2: Intermediate concepts
    {
      id: "tsk_p2_js_deep",
      roadmapId,
      phaseNumber: 2,
      phaseTitle: "Phase 2: Intermediate Concepts",
      phaseDescription: "Deep dive into JavaScript engines, asynchronous workflows, and DOM manipulation.",
      title: "JavaScript Deep Dive: Async/Await, Closures & Event Loop",
      skillsToLearn: ["JavaScript"],
      topics: ["Scope chain and closures", "Prototypes and this keyword", "Promises and async/await", "Fetch API & JSON handling", "Array map, filter, reduce"],
      practicalTasks: ["Build an interactive weather dashboard consuming open weather API", "Write custom polyfill for Array.prototype.reduce"],
      resourceId: "res_js_mastery",
      resourceTitle: "Modern JavaScript Deep Dive: From Fundamentals to ESNext",
      resourceUrl: "https://javascript.info",
      assessmentId: "asm_javascript_101",
      completed: false,
      orderIndex: 3,
    },
    {
      id: "tsk_p2_node_intro",
      roadmapId,
      phaseNumber: 2,
      phaseTitle: "Phase 2: Intermediate Concepts",
      phaseDescription: "Learn server-side runtime operations and backend API architectures.",
      title: "Node.js & Express Architecture Fundamentals",
      skillsToLearn: ["Node.js", "Express.js", "REST APIs"],
      topics: ["Node.js event-driven architecture", "Express routing and middleware", "Request body parsing", "CORS and environment configs"],
      practicalTasks: ["Create a REST API with GET, POST, PUT, DELETE for task management", "Implement JSON schema input validator"],
      resourceId: "res_node_express",
      resourceTitle: "Building Production-Ready REST APIs with Node.js & Express",
      resourceUrl: "https://nodejs.org/en/learn",
      assessmentId: "asm_node_101",
      completed: false,
      orderIndex: 4,
    },
    // Phase 3: Advanced skills
    {
      id: "tsk_p3_react_core",
      roadmapId,
      phaseNumber: 3,
      phaseTitle: "Phase 3: Advanced Skills",
      phaseDescription: "Master modern component-based UI engineering with React 19.",
      title: "React Component Lifecycle, Custom Hooks & Global State",
      skillsToLearn: ["React", "JavaScript"],
      topics: ["Component composition", "useState and useReducer state machines", "useEffect and custom hooks", "Context API & Zustand", "Client performance memoization"],
      practicalTasks: ["Build an interactive Kanban board with drag-and-drop state", "Create a reusable custom hook for debounced API queries"],
      resourceId: "res_react_official",
      resourceTitle: "Interactive React 19: Full Architecture & Hooks",
      resourceUrl: "https://react.dev/learn",
      assessmentId: "asm_react_101",
      completed: false,
      orderIndex: 5,
    },
    {
      id: "tsk_p3_db_integration",
      roadmapId,
      phaseNumber: 3,
      phaseTitle: "Phase 3: Advanced Skills",
      phaseDescription: "Connect backend services to relational databases with ORMs and SQL migrations.",
      title: "PostgreSQL Database Design & Drizzle/Prisma ORM Integration",
      skillsToLearn: ["SQL", "Node.js", "REST APIs"],
      topics: ["Relational normalization & foreign keys", "Transactions & ACID guarantees", "Indexes and query execution plans", "ORM schema migrations"],
      practicalTasks: ["Design relational schema for e-commerce catalog with orders and line items", "Write complex multi-table JOIN with grouping aggregations"],
      resourceId: "res_sql_optim",
      resourceTitle: "Advanced PostgreSQL: Indexing, Transactions & Query Tuning",
      resourceUrl: "https://www.postgresql.org/docs/current/tutorial.html",
      completed: false,
      orderIndex: 6,
    },
    // Phase 4: Practical projects
    {
      id: "tsk_p4_fullstack_project",
      roadmapId,
      phaseNumber: 4,
      phaseTitle: "Phase 4: Practical Projects",
      phaseDescription: "Synthesize all skills into a production-grade full stack capstone application.",
      title: "End-to-End SaaS Web App: E-Commerce / LMS Platform",
      skillsToLearn: ["React", "Node.js", "Express.js", "SQL", "REST APIs", "Git"],
      topics: ["JWT authentication and refresh tokens", "Payment gateway integration (Stripe)", "Role-based access control (RBAC)", "File uploads and cloud storage"],
      practicalTasks: ["Build complete e-commerce store with authentication, search, checkout, and admin dashboard", "Implement comprehensive integration tests"],
      resourceId: "res_mini_ecommerce",
      resourceTitle: "Full Stack Mini-Project: E-Commerce Store with Cart & Auth",
      resourceUrl: "https://github.com/topics/fullstack-ecommerce",
      completed: false,
      orderIndex: 7,
    },
    // Phase 5: Career preparation
    {
      id: "tsk_p5_career_prep",
      roadmapId,
      phaseNumber: 5,
      phaseTitle: "Phase 5: Career Preparation",
      phaseDescription: "Polish technical resume, deploy applications live, and master technical coding interviews.",
      title: "Portfolio Deployment, System Design & Technical Interviews",
      skillsToLearn: ["Git", "REST APIs"],
      topics: ["CI/CD pipelines with GitHub Actions", "Deploying frontend on Vercel and backend on Render/AWS", "Full-stack system design questions", "Live coding whiteboard challenges"],
      practicalTasks: ["Deploy 2 production applications with live custom domains", "Conduct 3 mock technical coding interviews on LeetCode Mediums"],
      completed: false,
      orderIndex: 8,
    },
  ];

  for (const t of alexTasks) {
    await db.insert(roadmapTasks).values(t).onConflictDoNothing();
  }

  // 10. User Progress for Alex
  await db.insert(userProgress).values({
    id: "prog_alex_001",
    userId: "usr_alex_001",
    careerReadiness: 38,
    totalSkillsAcquired: 3,
    missingSkillsCount: 6,
    roadmapCompletionPct: 25,
    weeklyHours: [
      { day: "Mon", hours: 2.5 },
      { day: "Tue", hours: 3.0 },
      { day: "Wed", hours: 1.5 },
      { day: "Thu", hours: 4.0 },
      { day: "Fri", hours: 2.0 },
      { day: "Sat", hours: 5.0 },
      { day: "Sun", hours: 3.5 },
    ],
    monthlyActivity: [
      { week: "Week 1", tasksCompleted: 2, scoreAvg: 80 },
      { week: "Week 2", tasksCompleted: 3, scoreAvg: 85 },
      { week: "Week 3", tasksCompleted: 1, scoreAvg: 75 },
      { week: "Week 4", tasksCompleted: 4, scoreAvg: 90 },
    ],
  }).onConflictDoNothing();

  // 11. Initial AI Agent Logs showing Multi-Agent Orchestration
  const agentLogs = [
    {
      id: "log_agent_1",
      userId: "usr_alex_001",
      agentName: "Skill Analysis Agent",
      agentRole: "Analyze user skills, detect strengths & gaps",
      inputPayload: {
        existingSkills: ["Python (Intermediate)", "SQL (Intermediate)", "HTML (Beginner)"],
        targetCareer: "Full Stack Developer",
      },
      outputPayload: {
        status: "complete",
        strengths: ["Strong procedural logic via Python", "Relational querying fundamentals with SQL"],
        weaknesses: ["Missing asynchronous JavaScript foundation", "No modern frontend framework experience"],
        missingSkills: ["JavaScript", "CSS", "React", "Node.js", "Express.js", "Git", "REST APIs"],
        skillGapPercentage: 65,
      },
      durationMs: 380,
    },
    {
      id: "log_agent_2",
      userId: "usr_alex_001",
      agentName: "Career Matching Agent",
      agentRole: "Compare user profile against industry benchmark for Full Stack Developer",
      inputPayload: {
        userSkills: ["Python", "SQL", "HTML"],
        career: "Full Stack Developer",
        requiredSkills: ["HTML", "CSS", "JavaScript", "React", "Node.js", "Express.js", "SQL", "Git", "REST APIs"],
      },
      outputPayload: {
        careerReadinessScore: 35,
        matchedSkillsCount: 3,
        missingSkillsCount: 6,
        recommendation: "Focus on JavaScript as high-priority prerequisite before advancing to React and Node.js.",
      },
      durationMs: 410,
    },
    {
      id: "log_agent_3",
      userId: "usr_alex_001",
      agentName: "Learning Recommendation Agent",
      agentRole: "Curate tailored courses, exercises, and projects",
      inputPayload: { missingSkills: ["JavaScript", "CSS", "React", "Node.js", "Express.js", "Git", "REST APIs"] },
      outputPayload: {
        topRecommendations: [
          "Modern JavaScript Deep Dive: From Fundamentals to ESNext",
          "Responsive Web Layouts: Flexbox, CSS Grid & Tailwind Mastery",
          "Interactive React 19: Full Architecture & Hooks",
        ],
        learningModality: "Hands-on Projects & Interactive Exercises",
      },
      durationMs: 350,
    },
    {
      id: "log_agent_4",
      userId: "usr_alex_001",
      agentName: "Learning Roadmap Agent",
      agentRole: "Synthesize 5-phase progressive personalized syllabus",
      inputPayload: { targetCareer: "Full Stack Developer", gaps: 6, phases: 5 },
      outputPayload: {
        roadmapId,
        phasesCreated: 5,
        totalTasks: 8,
        estimatedTimeWeeks: 12,
      },
      durationMs: 490,
    },
  ];

  for (const l of agentLogs) {
    await db.insert(aiAgentLogs).values(l).onConflictDoNothing();
  }

  // 12. Seed Chat Messages with the prompt's sample conversation
  const chatSeed = [
    {
      id: "msg_seed_1",
      userId: "usr_alex_001",
      sender: "user",
      message: "I want to become a Full Stack Developer.",
      metadata: null,
    },
    {
      id: "msg_seed_2",
      userId: "usr_alex_001",
      sender: "ai_mentor",
      message: "You already have Python, SQL, and basic HTML skills. Your next learning priorities are JavaScript, CSS, React, and Node.js.",
      metadata: {
        agentSource: "AI Mentor Agent",
        recommendedSkills: ["JavaScript", "CSS", "React", "Node.js"],
        suggestedActions: [
          { label: "View Recommended Roadmap", action: "NAVIGATE_ROADMAP" },
          { label: "Take JavaScript Assessment", action: "START_ASSESSMENT", payload: { assessmentId: "asm_javascript_101" } },
        ],
      },
    },
    {
      id: "msg_seed_3",
      userId: "usr_alex_001",
      sender: "user",
      message: "What should I learn first?",
      metadata: null,
    },
    {
      id: "msg_seed_4",
      userId: "usr_alex_001",
      sender: "ai_mentor",
      message: "Start with JavaScript fundamentals. After completing the lessons, take a short assessment. Your roadmap will update based on your performance.",
      metadata: {
        agentSource: "AI Mentor Agent",
        suggestedActions: [
          { label: "Start JavaScript 101 Assessment", action: "START_ASSESSMENT", payload: { assessmentId: "asm_javascript_101" } },
          { label: "Open Modern JS Resource", action: "OPEN_RESOURCE", payload: { resourceId: "res_js_mastery" } },
        ],
      },
    },
  ];

  for (const m of chatSeed) {
    await db.insert(chatMessages).values(m).onConflictDoNothing();
  }

  console.log("Database seeded successfully!");
}
