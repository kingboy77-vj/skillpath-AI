import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "SkillPath AI – Your Future. Your Skills. Your Path.",
  description: "Discover your potential, develop future-ready skills, and build your career with intelligent AI guidance.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en" className="dark">
      <body className="bg-black text-slate-100 antialiased min-h-screen selection:bg-cyan-400 selection:text-black">
        {children}
      </body>
    </html>
  );
}
