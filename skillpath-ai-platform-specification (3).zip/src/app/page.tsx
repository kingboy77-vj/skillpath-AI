"use client";

import React, { useState, useEffect } from "react";
import { Sidebar, NavTab } from "@/components/layout/Sidebar";
import { Navbar } from "@/components/layout/Navbar";
import { AgentStatusDrawer } from "@/components/layout/AgentStatusDrawer";
import { AuthModal } from "@/components/auth/AuthModal";
import { DashboardView } from "@/components/views/DashboardView";
import { ProfileView } from "@/components/views/ProfileView";
import { SkillAnalysisView } from "@/components/views/SkillAnalysisView";
import { CareerExplorerView } from "@/components/views/CareerExplorerView";
import { RoadmapView } from "@/components/views/RoadmapView";
import { ResourcesView } from "@/components/views/ResourcesView";
import { AssessmentsView } from "@/components/views/AssessmentsView";
import { ProgressView } from "@/components/views/ProgressView";
import { MentorChatView } from "@/components/views/MentorChatView";
import { SettingsView } from "@/components/views/SettingsView";
import { LandingPage } from "@/components/landing/LandingPage";
import { RefreshCw, CheckCircle2 } from "lucide-react";

export default function SkillPathApp() {
  const [viewMode, setViewMode] = useState<"landing" | "app">("landing");
  const [currentTab, setCurrentTab] = useState<NavTab>("dashboard");
  const [user, setUser] = useState<any>(null);
  const [loadingUser, setLoadingUser] = useState(true);
  const [isOrchestrating, setIsOrchestrating] = useState(false);
  const [isAgentDrawerOpen, setIsAgentDrawerOpen] = useState(false);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [isDemoMode, setIsDemoMode] = useState(true);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const [dashboardData, setDashboardData] = useState<any>({
    user: null,
    progress: null,
    roadmap: null,
    skills: [],
    recentAssessments: [],
  });

  const [targetAssessmentId, setTargetAssessmentId] = useState<string | null>(null);

  const fetchSessionAndData = async () => {
    try {
      setLoadingUser(true);
      const sessionRes = await fetch("/api/auth/session");
      if (sessionRes.ok) {
        const sessionData = await sessionRes.json();
        if (sessionData.authenticated) {
          setUser(sessionData.user);
          setDashboardData((prev: any) => ({
            ...prev,
            user: sessionData.user,
            progress: sessionData.user.progress,
            skills: sessionData.user.skills || [],
          }));
        }
      }

      const settingsRes = await fetch("/api/settings");
      if (settingsRes.ok) {
        const sData = await settingsRes.json();
        setIsDemoMode(sData.isDemoModeActive ?? true);
      }

      const roadmapRes = await fetch("/api/roadmap");
      if (roadmapRes.ok) {
        const rData = await roadmapRes.json();
        setDashboardData((prev: any) => ({
          ...prev,
          roadmap: rData,
        }));
      }

      const asmRes = await fetch("/api/assessments");
      if (asmRes.ok) {
        const aData = await asmRes.json();
        setDashboardData((prev: any) => ({
          ...prev,
          recentAssessments: aData.recentResults || [],
        }));
      }
    } catch (e) {
      console.error("Error initializing SkillPath AI session:", e);
    } finally {
      setLoadingUser(false);
    }
  };

  useEffect(() => {
    fetchSessionAndData();
  }, []);

  const handleLogout = async () => {
    try {
      await fetch("/api/auth/logout", { method: "POST" });
      setUser(null);
      setViewMode("landing");
      setIsAuthModalOpen(true);
    } catch (e) {
      console.error("Logout error:", e);
    }
  };

  const handleRunOrchestrator = async () => {
    try {
      setIsOrchestrating(true);
      const res = await fetch("/api/agents/orchestrate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({}),
      });

      if (res.ok) {
        showToast("AI Orchestrator successfully recalibrated all 6 agents!");
        await fetchSessionAndData();
      }
    } catch (e) {
      console.error("Orchestrator trigger error:", e);
    } finally {
      setIsOrchestrating(false);
    }
  };

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 4000);
  };

  const handleNavigate = (tab: NavTab, meta?: any) => {
    if (meta?.assessmentId) {
      setTargetAssessmentId(meta.assessmentId);
    } else {
      setTargetAssessmentId(null);
    }
    setCurrentTab(tab);
    setViewMode("app");
    setMobileMenuOpen(false);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const handleLandingNavigate = (
    target: "home" | "skills" | "roadmap" | "mentor" | "dashboard" | "careers" | "progress"
  ) => {
    if (target === "home") {
      setViewMode("landing");
      window.scrollTo({ top: 0, behavior: "smooth" });
      return;
    }
    const map: Record<string, NavTab> = {
      skills: "skills",
      roadmap: "roadmap",
      mentor: "mentor",
      dashboard: "dashboard",
      careers: "careers",
      progress: "progress",
    };
    handleNavigate(map[target]);
  };

  const handleGetStarted = () => {
    if (user) {
      setViewMode("app");
      setCurrentTab("dashboard");
      window.scrollTo({ top: 0, behavior: "smooth" });
    } else {
      setIsAuthModalOpen(true);
    }
  };

  const handleAuthSuccess = () => {
    fetchSessionAndData();
    setViewMode("app");
    setCurrentTab("dashboard");
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const handleGoHome = () => {
    setViewMode("landing");
    setMobileMenuOpen(false);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  // Landing mode — cinematic entry, all buttons route into the real app
  if (viewMode === "landing") {
    return (
      <>
        <LandingPage
          onNavigate={handleLandingNavigate}
          onGetStarted={handleGetStarted}
          isLoggedIn={Boolean(user)}
          userName={user?.fullName}
        />

        {toastMessage && (
          <div className="fixed top-20 right-6 z-[60] p-4 rounded-xl bg-black/90 backdrop-blur-xl border border-cyan-500/40 text-cyan-300 text-xs font-semibold shadow-2xl flex items-center gap-2 animate-fade-up">
            <CheckCircle2 className="w-4 h-4 text-cyan-400 shrink-0" />
            <span>{toastMessage}</span>
          </div>
        )}

        <AgentStatusDrawer
          isOpen={isAgentDrawerOpen}
          onClose={() => setIsAgentDrawerOpen(false)}
          isDemoMode={isDemoMode}
        />

        <AuthModal
          isOpen={isAuthModalOpen}
          onClose={() => setIsAuthModalOpen(false)}
          onSuccess={handleAuthSuccess}
        />
      </>
    );
  }

  // App mode — preserved dashboard shell, APIs, and navigation logic
  return (
    <div className="flex min-h-screen bg-black text-slate-100">
      <div className="hidden md:block">
        <Sidebar
          currentTab={currentTab}
          onSelectTab={handleNavigate}
          user={user}
          onLogout={handleLogout}
          onOpenAuth={() => setIsAuthModalOpen(true)}
          onGoHome={handleGoHome}
        />
      </div>

      {mobileMenuOpen && (
        <div className="fixed inset-0 z-50 md:hidden bg-black/80 backdrop-blur-sm flex">
          <div className="w-64 bg-black h-full">
            <Sidebar
              currentTab={currentTab}
              onSelectTab={handleNavigate}
              user={user}
              onLogout={handleLogout}
              onOpenAuth={() => setIsAuthModalOpen(true)}
              onGoHome={handleGoHome}
            />
          </div>
          <div className="flex-1" onClick={() => setMobileMenuOpen(false)} />
        </div>
      )}

      <div className="flex-1 flex flex-col min-w-0">
        <Navbar
          currentTab={currentTab}
          isOrchestrating={isOrchestrating}
          onRunOrchestrator={handleRunOrchestrator}
          onOpenAgentLogs={() => setIsAgentDrawerOpen(true)}
          isDemoMode={isDemoMode}
          onToggleMobileMenu={() => setMobileMenuOpen(!mobileMenuOpen)}
          careerTitle={user?.targetCareerName}
        />

        {toastMessage && (
          <div className="fixed top-16 right-6 z-50 p-4 rounded-xl bg-black/90 backdrop-blur-xl border border-cyan-500/40 text-cyan-300 text-xs font-semibold shadow-2xl flex items-center gap-2 animate-fade-up">
            <CheckCircle2 className="w-4 h-4 text-cyan-400 shrink-0" />
            <span>{toastMessage}</span>
          </div>
        )}

        <main className="flex-1 p-4 sm:p-6 lg:p-8 overflow-y-auto">
          {loadingUser && !user ? (
            <div className="p-16 text-center text-slate-400">
              <RefreshCw className="w-8 h-8 mx-auto animate-spin mb-3 text-cyan-400" />
              <p className="text-sm font-medium">Bootstrapping SkillPath AI Multi-Agent Environment...</p>
            </div>
          ) : (
            <>
              {currentTab === "dashboard" && (
                <DashboardView
                  data={{
                    user: user || dashboardData.user,
                    progress: user?.progress || dashboardData.progress,
                    roadmap: dashboardData.roadmap,
                    skills: user?.skills || dashboardData.skills,
                    recentAssessments: dashboardData.recentAssessments,
                  }}
                  onNavigate={handleNavigate}
                  onRunOrchestrator={handleRunOrchestrator}
                  isOrchestrating={isOrchestrating}
                />
              )}

              {currentTab === "profile" && (
                <ProfileView onProfileUpdated={fetchSessionAndData} />
              )}

              {currentTab === "skills" && (
                <SkillAnalysisView onNavigate={handleNavigate} />
              )}

              {currentTab === "careers" && (
                <CareerExplorerView
                  onNavigate={handleNavigate}
                  onCareerSwitched={fetchSessionAndData}
                />
              )}

              {currentTab === "roadmap" && (
                <RoadmapView
                  onNavigate={handleNavigate}
                  onTaskUpdated={fetchSessionAndData}
                />
              )}

              {currentTab === "resources" && <ResourcesView />}

              {currentTab === "assessments" && (
                <AssessmentsView
                  initialAssessmentId={targetAssessmentId}
                  onAssessmentCompleted={fetchSessionAndData}
                />
              )}

              {currentTab === "progress" && <ProgressView />}

              {currentTab === "mentor" && (
                <MentorChatView onNavigate={handleNavigate} userContext={user} />
              )}

              {currentTab === "settings" && (
                <SettingsView onSettingsChanged={fetchSessionAndData} />
              )}
            </>
          )}
        </main>
      </div>

      <AgentStatusDrawer
        isOpen={isAgentDrawerOpen}
        onClose={() => setIsAgentDrawerOpen(false)}
        isDemoMode={isDemoMode}
      />

      <AuthModal
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
        onSuccess={handleAuthSuccess}
      />
    </div>
  );
}
