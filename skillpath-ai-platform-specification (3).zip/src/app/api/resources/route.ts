import { NextResponse } from "next/server";
import { db } from "@/db";
import { learningResources, systemSettings } from "@/db/schema";
import { eq } from "drizzle-orm";

export async function GET(req: Request) {
  try {
    const { searchParams } = new URL(req.url);
    const category = searchParams.get("category");
    const type = searchParams.get("type");
    const query = searchParams.get("q")?.toLowerCase();

    let resources = await db.select().from(learningResources);

    if (category && category !== "All") {
      resources = resources.filter((r) => r.category.toLowerCase() === category.toLowerCase());
    }

    if (type && type !== "All") {
      resources = resources.filter((r) => r.type.toLowerCase() === type.toLowerCase());
    }

    if (query) {
      resources = resources.filter(
        (r) =>
          r.title.toLowerCase().includes(query) ||
          r.skillName.toLowerCase().includes(query) ||
          r.learningObjective.toLowerCase().includes(query)
      );
    }

    // Check if YouTube API is configured
    const settings = await db.select().from(systemSettings).where(eq(systemSettings.id, "system_default"));
    const youtubeKey = settings[0]?.youtubeApiKey || process.env.YOUTUBE_API_KEY;

    let youtubeVideos: any[] = [];
    if (youtubeKey && query) {
      try {
        const ytRes = await fetch(
          `https://www.googleapis.com/youtube/v3/search?part=snippet&q=${encodeURIComponent(
            query + " tutorial coding"
          )}&type=video&maxResults=3&key=${youtubeKey}`
        );
        if (ytRes.ok) {
          const ytData = await ytRes.json();
          youtubeVideos = (ytData.items || []).map((item: any) => ({
            id: `yt_${item.id.videoId}`,
            title: item.snippet.title,
            category: category || "Programming",
            skillName: query,
            difficultyLevel: "Intermediate",
            type: "Video Tutorial",
            provider: item.snippet.channelTitle,
            estimatedDuration: "Video",
            resourceUrl: `https://www.youtube.com/watch?v=${item.id.videoId}`,
            learningObjective: item.snippet.description || "Video walkthrough and coding tutorial",
            rating: "4.8",
            isFree: true,
          }));
        }
      } catch (ytErr) {
        console.warn("YouTube search API error (fallback to curated):", ytErr);
      }
    }

    return NextResponse.json({
      resources: [...youtubeVideos, ...resources],
      categories: [
        "All",
        "Programming",
        "Web Development",
        "Artificial Intelligence",
        "Database Management",
        "Cloud Computing",
      ],
      types: ["All", "Course", "Video Tutorial", "Documentation", "Coding Exercise", "Mini-Project"],
    });
  } catch (error: any) {
    console.error("GET /api/resources error:", error);
    return NextResponse.json({ error: error.message || "Failed to fetch resources" }, { status: 500 });
  }
}
