import { NextResponse } from "next/server";
import { getCurrentUserId } from "@/lib/auth";
import { db } from "@/db";
import { aiAgentLogs } from "@/db/schema";
import { runProgressEvaluationAgent } from "@/lib/agents/progress-evaluation-agent";

export async function POST(req: Request) {
  try {
    const userId = await getCurrentUserId();
    const body = await req.json();

    const { assessmentTitle, skillName, score, totalQuestions, percentage, questionDetails } = body;

    const startTime = Date.now();
    const result = await runProgressEvaluationAgent({
      assessmentTitle: assessmentTitle || "Technical Assessment",
      skillName: skillName || "General Engineering",
      score: score || 0,
      totalQuestions: totalQuestions || 5,
      percentage: percentage || 0,
      questionDetails: questionDetails || [],
    });

    await db.insert(aiAgentLogs).values({
      id: `log_pe_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      userId,
      agentName: "Progress Evaluation Agent",
      agentRole: "Evaluate quiz performance, identify improvement areas, adjust proficiency",
      inputPayload: { assessmentTitle, score, percentage },
      outputPayload: result as any,
      durationMs: Date.now() - startTime,
    });

    return NextResponse.json({ success: true, evaluation: result });
  } catch (error: any) {
    console.error("Agent 5 Error:", error);
    return NextResponse.json({ error: error.message || "Progress evaluation failed" }, { status: 500 });
  }
}
