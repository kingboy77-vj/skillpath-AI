import { NextResponse } from "next/server";
import { getCurrentUserId } from "@/lib/auth";
import { db } from "@/db";
import { profiles, userSkills, careerRequirements, aiAgentLogs } from "@/db/schema";
import { eq } from "drizzle-orm";
import { runRoadmapAgent } from "@/lib/agents/roadmap-agent";

export async function POST(req: Request) {
  try {
    const userId = await getCurrentUserId();
    const body = await req.json().catch(() => ({}));

    const userList = await db.select().from(profiles).where(eq(profiles.id, userId));
    const user = userList[0];
    const targetCareer = body.targetCareer || user?.targetCareerName || "Full Stack Developer";
    const targetCareerId = body.targetCareerId || user?.targetCareerId || "full-stack-developer";

    const uSkills = await db.select().from(userSkills).where(eq(userSkills.userId, userId));
    const reqs = await db.select().from(careerRequirements).where(eq(careerRequirements.careerId, targetCareerId));

    const existingNames = uSkills.map((s) => s.skillName.toLowerCase());
    const missing = reqs
      .filter((r) => !existingNames.includes(r.skillName.toLowerCase()))
      .map((r) => r.skillName);

    const startTime = Date.now();
    const result = await runRoadmapAgent({
      targetCareer,
      missingSkills: missing.length ? missing : ["JavaScript", "React", "Node.js"],
      currentSkills: uSkills.map((s) => s.skillName),
      learningStyle: user?.preferredLearningStyle || undefined,
    });

    await db.insert(aiAgentLogs).values({
      id: `log_rm_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      userId,
      agentName: "Learning Roadmap Agent",
      agentRole: "Synthesize personalized 5-phase progressive learning roadmap",
      inputPayload: { targetCareer, missingSkills: missing },
      outputPayload: result as any,
      durationMs: Date.now() - startTime,
    });

    return NextResponse.json({ success: true, roadmap: result });
  } catch (error: any) {
    console.error("Agent 4 Error:", error);
    return NextResponse.json({ error: error.message || "Roadmap generation failed" }, { status: 500 });
  }
}
