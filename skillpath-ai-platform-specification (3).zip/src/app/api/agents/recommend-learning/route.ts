import { NextResponse } from "next/server";
import { getCurrentUserId } from "@/lib/auth";
import { db } from "@/db";
import { profiles, userSkills, careerRequirements, learningResources, aiAgentLogs } from "@/db/schema";
import { eq } from "drizzle-orm";
import { runLearningRecommendationAgent } from "@/lib/agents/learning-recommendation-agent";

export async function POST(req: Request) {
  try {
    const userId = await getCurrentUserId();
    const body = await req.json().catch(() => ({}));

    const userList = await db.select().from(profiles).where(eq(profiles.id, userId));
    const user = userList[0];
    const targetCareer = body.targetCareer || user?.targetCareerName || "Full Stack Developer";
    const targetCareerId = body.targetCareerId || user?.targetCareerId || "full-stack-developer";

    const uSkills = await db.select().from(userSkills).where(eq(userSkills.userId, userId));
    const reqs = await db.select().from(careerRequirements).where(eq(careerRequirements.careerId, targetCareerId));
    const dbResources = await db.select().from(learningResources);

    const existingNames = uSkills.map((s) => s.skillName.toLowerCase());
    const missing = reqs
      .filter((r) => !existingNames.includes(r.skillName.toLowerCase()))
      .map((r) => r.skillName);

    const startTime = Date.now();
    const result = await runLearningRecommendationAgent({
      targetCareer,
      missingSkills: missing.length ? missing : ["JavaScript", "React", "Node.js"],
      learningStyle: user?.preferredLearningStyle || undefined,
      existingResources: dbResources.map((r) => ({
        id: r.id,
        title: r.title,
        skillCovered: r.skillName,
        difficultyLevel: r.difficultyLevel as any,
        estimatedDuration: r.estimatedDuration,
        resourceUrl: r.resourceUrl,
        learningObjective: r.learningObjective,
        type: r.type as any,
        provider: r.provider,
      })),
    });

    await db.insert(aiAgentLogs).values({
      id: `log_lr_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      userId,
      agentName: "Learning Recommendation Agent",
      agentRole: "Prioritize courses, tutorials, exercises and mini-projects based on gaps",
      inputPayload: { targetCareer, missingSkills: missing },
      outputPayload: result as any,
      durationMs: Date.now() - startTime,
    });

    return NextResponse.json({ success: true, recommendations: result });
  } catch (error: any) {
    console.error("Agent 3 Error:", error);
    return NextResponse.json({ error: error.message || "Learning recommendation failed" }, { status: 500 });
  }
}
