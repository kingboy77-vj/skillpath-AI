import { NextResponse } from "next/server";
import { getCurrentUserId } from "@/lib/auth";
import { orchestrateFullLearningPipeline } from "@/lib/agents/orchestrator";

export async function POST(req: Request) {
  try {
    const userId = await getCurrentUserId();
    const body = await req.json().catch(() => ({}));
    const targetCareerId = body.targetCareerId;

    const result = await orchestrateFullLearningPipeline(userId, targetCareerId);

    return NextResponse.json({
      success: true,
      orchestration: result,
    });
  } catch (error: any) {
    console.error("Central Orchestrator Error:", error);
    return NextResponse.json({ error: error.message || "Orchestration failed" }, { status: 500 });
  }
}
