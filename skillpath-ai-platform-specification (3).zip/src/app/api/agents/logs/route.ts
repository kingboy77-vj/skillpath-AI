import { NextResponse } from "next/server";
import { getCurrentUserId } from "@/lib/auth";
import { db } from "@/db";
import { aiAgentLogs } from "@/db/schema";
import { eq, desc } from "drizzle-orm";

export async function GET() {
  try {
    const userId = await getCurrentUserId();
    const logs = await db
      .select()
      .from(aiAgentLogs)
      .where(eq(aiAgentLogs.userId, userId))
      .orderBy(desc(aiAgentLogs.createdAt))
      .limit(20);

    return NextResponse.json({ logs });
  } catch (error: any) {
    return NextResponse.json({ error: error.message || "Failed to fetch logs" }, { status: 500 });
  }
}
