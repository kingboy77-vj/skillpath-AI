import { NextResponse } from "next/server";
import { getCurrentUserId } from "@/lib/auth";
import { db } from "@/db";
import { profiles, userSkills, careers, careerRequirements, aiAgentLogs } from "@/db/schema";
import { eq } from "drizzle-orm";
import { runCareerMatchingAgent } from "@/lib/agents/career-matching-agent";

export async function POST(req: Request) {
  try {
    const userId = await getCurrentUserId();
    const body = await req.json().catch(() => ({}));

    const userList = await db.select().from(profiles).where(eq(profiles.id, userId));
    const user = userList[0];
    const careerId = body.careerId || user?.targetCareerId || "full-stack-developer";

    const careerList = await db.select().from(careers).where(eq(careers.id, careerId));
    const career = careerList[0];

    const uSkills = await db.select().from(userSkills).where(eq(userSkills.userId, userId));
    const reqs = await db.select().from(careerRequirements).where(eq(careerRequirements.careerId, careerId));

    const startTime = Date.now();
    const result = await runCareerMatchingAgent({
      targetCareer: career ? career.title : "Full Stack Developer",
      careerDescription: career?.description,
      userSkills: uSkills.map((s) => ({ name: s.skillName, proficiency: s.proficiencyLevel, score: s.score })),
      careerRequirements: reqs.map((r) => ({
        skillName: r.skillName,
        requiredProficiency: r.requiredProficiency,
        importance: r.importance,
        weight: r.weight,
      })),
    });

    await db.insert(aiAgentLogs).values({
      id: `log_cm_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      userId,
      agentName: "Career Matching Agent",
      agentRole: "Compute career readiness score, match user skills vs market requirements",
      inputPayload: { careerId, careerTitle: career?.title },
      outputPayload: result as any,
      durationMs: Date.now() - startTime,
    });

    return NextResponse.json({ success: true, match: result });
  } catch (error: any) {
    console.error("Agent 2 Error:", error);
    return NextResponse.json({ error: error.message || "Career matching failed" }, { status: 500 });
  }
}
