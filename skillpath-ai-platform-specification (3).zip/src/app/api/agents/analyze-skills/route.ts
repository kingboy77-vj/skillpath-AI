import { NextResponse } from "next/server";
import { getCurrentUserId } from "@/lib/auth";
import { db } from "@/db";
import { profiles, userSkills, careerRequirements, aiAgentLogs } from "@/db/schema";
import { eq } from "drizzle-orm";
import { runSkillAnalysisAgent } from "@/lib/agents/skill-analysis-agent";

export async function POST(req: Request) {
  try {
    const userId = await getCurrentUserId();
    const body = await req.json().catch(() => ({}));

    const userList = await db.select().from(profiles).where(eq(profiles.id, userId));
    const user = userList[0];
    const targetCareer = body.targetCareer || user?.targetCareerName || "Full Stack Developer";
    const targetCareerId = body.targetCareerId || user?.targetCareerId || "full-stack-developer";

    const uSkills = await db.select().from(userSkills).where(eq(userSkills.userId, userId));
    const reqs = await db.select().from(careerRequirements).where(eq(careerRequirements.careerId, targetCareerId));

    const startTime = Date.now();
    const result = await runSkillAnalysisAgent({
      userSkills: uSkills.map((s) => ({ name: s.skillName, proficiency: s.proficiencyLevel, score: s.score })),
      targetCareer,
      requiredSkills: reqs.map((r) => ({ name: r.skillName, requiredProficiency: r.requiredProficiency, importance: r.importance })),
      education: user?.educationLevel || undefined,
      projects: user?.completedProjects as any,
    });

    await db.insert(aiAgentLogs).values({
      id: `log_sa_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      userId,
      agentName: "Skill Analysis Agent",
      agentRole: "Analyze user competencies, identify strong & weak skills, compute gaps",
      inputPayload: { targetCareer, skillCount: uSkills.length },
      outputPayload: result as any,
      durationMs: Date.now() - startTime,
    });

    return NextResponse.json({ success: true, analysis: result });
  } catch (error: any) {
    console.error("Agent 1 Error:", error);
    return NextResponse.json({ error: error.message || "Skill analysis failed" }, { status: 500 });
  }
}
