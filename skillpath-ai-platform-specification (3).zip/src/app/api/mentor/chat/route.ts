import { NextResponse } from "next/server";
import { getCurrentUserId } from "@/lib/auth";
import { db } from "@/db";
import { profiles, userSkills, userProgress, chatMessages, roadmapTasks, learningRoadmaps } from "@/db/schema";
import { eq, desc, and } from "drizzle-orm";
import { runMentorAgent } from "@/lib/agents/mentor-agent";

export async function GET() {
  try {
    const userId = await getCurrentUserId();
    const messages = await db
      .select()
      .from(chatMessages)
      .where(eq(chatMessages.userId, userId))
      .orderBy(chatMessages.createdAt);

    return NextResponse.json({ messages });
  } catch (error: any) {
    return NextResponse.json({ error: error.message || "Failed to load chat" }, { status: 500 });
  }
}

export async function POST(req: Request) {
  try {
    const userId = await getCurrentUserId();
    const { message } = await req.json();

    if (!message || typeof message !== "string" || !message.trim()) {
      return NextResponse.json({ error: "Message is required" }, { status: 400 });
    }

    // 1. Fetch user context
    const profileList = await db.select().from(profiles).where(eq(profiles.id, userId));
    const user = profileList[0];
    const uSkills = await db.select().from(userSkills).where(eq(userSkills.userId, userId));
    const progressList = await db.select().from(userProgress).where(eq(userProgress.userId, userId));
    const progress = progressList[0] || {
      careerReadiness: 35,
      totalSkillsAcquired: uSkills.length,
      missingSkillsCount: 6,
      roadmapCompletionPct: 20,
    };

    // Find active roadmap task
    const activeRoadmap = await db.select().from(learningRoadmaps).where(eq(learningRoadmaps.userId, userId));
    let activeTaskTitle = "";
    if (activeRoadmap.length > 0) {
      const pendingTasks = await db
        .select()
        .from(roadmapTasks)
        .where(and(eq(roadmapTasks.roadmapId, activeRoadmap[0].id), eq(roadmapTasks.completed, false)))
        .orderBy(roadmapTasks.orderIndex)
        .limit(1);
      if (pendingTasks.length > 0) {
        activeTaskTitle = pendingTasks[0].title;
      }
    }

    // Fetch previous 6 messages for conversation memory
    const history = await db
      .select()
      .from(chatMessages)
      .where(eq(chatMessages.userId, userId))
      .orderBy(desc(chatMessages.createdAt))
      .limit(6);

    const formattedHistory = history
      .reverse()
      .map((h) => ({ sender: h.sender as "user" | "ai_mentor", message: h.message }));

    // Save user message
    const userMsgId = `msg_u_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;
    await db.insert(chatMessages).values({
      id: userMsgId,
      userId,
      sender: "user",
      message: message.trim(),
    });

    // Run AI Mentor Agent
    const mentorResult = await runMentorAgent({
      userMessage: message.trim(),
      chatHistory: formattedHistory,
      profile: {
        fullName: user?.fullName || "Learner",
        education: user?.educationLevel || "Student",
        targetCareer: user?.targetCareerName || "Full Stack Developer",
        learningStyle: user?.preferredLearningStyle || "Hands-on Projects",
        skills: uSkills.map((s) => ({ name: s.skillName, proficiency: s.proficiencyLevel })),
      },
      progress: {
        careerReadiness: progress.careerReadiness,
        totalSkillsAcquired: progress.totalSkillsAcquired,
        missingSkillsCount: progress.missingSkillsCount,
        roadmapCompletionPct: progress.roadmapCompletionPct,
      },
      activeRoadmapTask: activeTaskTitle,
    });

    // Save AI Mentor reply
    const mentorMsgId = `msg_ai_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;
    const newAiMessage = {
      id: mentorMsgId,
      userId,
      sender: "ai_mentor",
      message: mentorResult.reply,
      metadata: {
        agentSource: "AI Mentor Agent",
        suggestedActions: mentorResult.suggestedActions,
        recommendedSkills: mentorResult.recommendedSkills,
      },
    };
    await db.insert(chatMessages).values(newAiMessage);

    return NextResponse.json({
      success: true,
      message: newAiMessage,
      source: mentorResult.source,
    });
  } catch (error: any) {
    console.error("Mentor chat error:", error);
    return NextResponse.json({ error: error.message || "Failed to process message" }, { status: 500 });
  }
}
