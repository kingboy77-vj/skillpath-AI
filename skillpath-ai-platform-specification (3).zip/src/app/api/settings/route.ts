import { NextResponse } from "next/server";
import { db } from "@/db";
import { systemSettings } from "@/db/schema";
import { eq } from "drizzle-orm";
import { seedDatabase } from "@/db/seed";

export async function GET() {
  try {
    const list = await db.select().from(systemSettings).where(eq(systemSettings.id, "system_default"));
    const current = list[0] || {
      id: "system_default",
      geminiApiKey: process.env.GEMINI_API_KEY || null,
      youtubeApiKey: process.env.YOUTUBE_API_KEY || null,
      preferredModel: "gemini-1.5-flash",
      demoModeOverride: false,
    };

    const hasEnvGemini = Boolean(process.env.GEMINI_API_KEY);
    const hasDbGemini = Boolean(current.geminiApiKey);
    const effectiveGemini = current.geminiApiKey || process.env.GEMINI_API_KEY || "";

    const maskedGemini = effectiveGemini
      ? effectiveGemini.length > 8
        ? `${effectiveGemini.slice(0, 4)}...${effectiveGemini.slice(-4)}`
        : "••••••••"
      : "";

    return NextResponse.json({
      hasGeminiKey: hasEnvGemini || hasDbGemini,
      maskedGeminiKey: maskedGemini,
      hasYoutubeKey: Boolean(current.youtubeApiKey || process.env.YOUTUBE_API_KEY),
      preferredModel: current.preferredModel || "gemini-1.5-flash",
      demoModeOverride: Boolean(current.demoModeOverride),
      isDemoModeActive: Boolean(current.demoModeOverride) || (!hasEnvGemini && !hasDbGemini),
    });
  } catch (error: any) {
    return NextResponse.json({ error: error.message || "Failed to load settings" }, { status: 500 });
  }
}

export async function PUT(req: Request) {
  try {
    const body = await req.json();
    const { geminiApiKey, youtubeApiKey, preferredModel, demoModeOverride, resetSeed } = body;

    if (resetSeed) {
      await seedDatabase();
      return NextResponse.json({ success: true, message: "Demo data reset successfully." });
    }

    const updateValues: Partial<typeof systemSettings.$inferInsert> = {
      updatedAt: new Date(),
    };

    if (geminiApiKey !== undefined) {
      updateValues.geminiApiKey = geminiApiKey ? geminiApiKey.trim() : null;
    }
    if (youtubeApiKey !== undefined) {
      updateValues.youtubeApiKey = youtubeApiKey ? youtubeApiKey.trim() : null;
    }
    if (preferredModel !== undefined) {
      updateValues.preferredModel = preferredModel;
    }
    if (demoModeOverride !== undefined) {
      updateValues.demoModeOverride = Boolean(demoModeOverride);
    }

    const existing = await db.select().from(systemSettings).where(eq(systemSettings.id, "system_default"));
    if (existing.length === 0) {
      await db.insert(systemSettings).values({
        id: "system_default",
        ...updateValues,
      });
    } else {
      await db.update(systemSettings).set(updateValues).where(eq(systemSettings.id, "system_default"));
    }

    return NextResponse.json({ success: true, message: "Settings saved successfully" });
  } catch (error: any) {
    return NextResponse.json({ error: error.message || "Failed to save settings" }, { status: 500 });
  }
}
