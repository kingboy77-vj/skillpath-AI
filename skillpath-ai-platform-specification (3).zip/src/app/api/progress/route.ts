import { NextResponse } from "next/server";
import { getCurrentUserId } from "@/lib/auth";
import { db } from "@/db";
import { userProgress, userSkills, roadmapTasks, learningRoadmaps, assessmentResults, profiles } from "@/db/schema";
import { eq, desc } from "drizzle-orm";

export async function GET() {
  try {
    const userId = await getCurrentUserId();
    const progressList = await db.select().from(userProgress).where(eq(userProgress.userId, userId));
    const uSkills = await db.select().from(userSkills).where(eq(userSkills.userId, userId));
    const user = await db.select().from(profiles).where(eq(profiles.id, userId));
    const results = await db
      .select()
      .from(assessmentResults)
      .where(eq(assessmentResults.userId, userId))
      .orderBy(desc(assessmentResults.createdAt))
      .limit(6);

    const roadmaps = await db.select().from(learningRoadmaps).where(eq(learningRoadmaps.userId, userId));
    let tasks: any[] = [];
    if (roadmaps.length > 0) {
      tasks = await db.select().from(roadmapTasks).where(eq(roadmapTasks.roadmapId, roadmaps[0].id));
    }

    const defaultWeekly = [
      { day: "Mon", hours: 2.5 },
      { day: "Tue", hours: 3.0 },
      { day: "Wed", hours: 1.5 },
      { day: "Thu", hours: 4.0 },
      { day: "Fri", hours: 2.0 },
      { day: "Sat", hours: 5.0 },
      { day: "Sun", hours: 3.5 },
    ];

    const defaultMonthly = [
      { week: "Week 1", tasksCompleted: 2, scoreAvg: 80 },
      { week: "Week 2", tasksCompleted: 3, scoreAvg: 85 },
      { week: "Week 3", tasksCompleted: 1, scoreAvg: 75 },
      { week: "Week 4", tasksCompleted: 4, scoreAvg: 90 },
    ];

    const currentProg = progressList[0] || {
      careerReadiness: 38,
      totalSkillsAcquired: uSkills.length,
      missingSkillsCount: 6,
      roadmapCompletionPct: 25,
      weeklyHours: defaultWeekly,
      monthlyActivity: defaultMonthly,
    };

    const completedTasksCount = tasks.filter((t) => t.completed).length;

    return NextResponse.json({
      progress: {
        ...currentProg,
        weeklyHours: currentProg.weeklyHours?.length ? currentProg.weeklyHours : defaultWeekly,
        monthlyActivity: currentProg.monthlyActivity?.length ? currentProg.monthlyActivity : defaultMonthly,
      },
      skills: uSkills,
      targetCareer: user[0]?.targetCareerName || "Full Stack Developer",
      totalTasksCount: tasks.length,
      completedTasksCount,
      recentAssessments: results,
    });
  } catch (error: any) {
    console.error("GET /api/progress error:", error);
    return NextResponse.json({ error: error.message || "Failed to fetch progress" }, { status: 500 });
  }
}
