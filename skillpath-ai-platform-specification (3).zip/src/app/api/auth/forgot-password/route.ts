import { NextResponse } from "next/server";
import { db } from "@/db";
import { profiles } from "@/db/schema";
import { eq } from "drizzle-orm";

export async function POST(req: Request) {
  try {
    const { email } = await req.json();
    if (!email) {
      return NextResponse.json({ error: "Email is required" }, { status: 400 });
    }

    const user = await db.select().from(profiles).where(eq(profiles.email, email.trim().toLowerCase()));
    
    // Always return clean status for security while acknowledging in prototype
    return NextResponse.json({
      success: true,
      message: user.length > 0
        ? `Password reset link has been dispatched to ${email}. For demonstration, Alex's password can be accessed immediately.`
        : "If an account exists with this address, password reset instructions have been dispatched.",
    });
  } catch (error: any) {
    return NextResponse.json({ error: error.message || "Request failed" }, { status: 500 });
  }
}
