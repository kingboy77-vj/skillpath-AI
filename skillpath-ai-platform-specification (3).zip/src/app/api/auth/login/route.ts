import { NextResponse } from "next/server";
import { cookies } from "next/headers";
import { db } from "@/db";
import { profiles } from "@/db/schema";
import { eq } from "drizzle-orm";

export async function POST(req: Request) {
  try {
    const { email, password } = await req.json();

    if (!email) {
      return NextResponse.json({ error: "Email is required" }, { status: 400 });
    }

    // Lookup user by email
    const users = await db.select().from(profiles).where(eq(profiles.email, email.trim().toLowerCase()));
    
    if (users.length === 0) {
      // If logging in with demo account
      const cleanEmail = email.trim().toLowerCase();
      if (cleanEmail === "alex@kingskill.ai" || cleanEmail === "alex@skillpath.ai") {
        const alex = await db.select().from(profiles).where(eq(profiles.id, "usr_alex_001"));
        if (alex.length > 0) {
          const cookieStore = await cookies();
          cookieStore.set("skillpath_user_id", alex[0].id, {
            path: "/",
            httpOnly: false,
            maxAge: 60 * 60 * 24 * 30, // 30 days
          });
          return NextResponse.json({ success: true, user: alex[0] });
        }
      }
      return NextResponse.json({ error: "Invalid email or password" }, { status: 401 });
    }

    const user = users[0];
    const cookieStore = await cookies();
    cookieStore.set("skillpath_user_id", user.id, {
      path: "/",
      httpOnly: false,
      maxAge: 60 * 60 * 24 * 30,
    });

    return NextResponse.json({ success: true, user });
  } catch (error: any) {
    console.error("Login error:", error);
    return NextResponse.json({ error: error.message || "Login failed" }, { status: 500 });
  }
}
