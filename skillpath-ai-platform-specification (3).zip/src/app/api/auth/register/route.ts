import { NextResponse } from "next/server";
import { cookies } from "next/headers";
import { db } from "@/db";
import { profiles, userSkills, userProgress, learningRoadmaps, roadmapTasks } from "@/db/schema";
import { eq } from "drizzle-orm";
import { orchestrateFullLearningPipeline } from "@/lib/agents/orchestrator";

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const { fullName, email, password, educationLevel, collegeOrOrg, targetCareerId, preferredLearningStyle, initialSkills } = body;

    if (!email || !fullName) {
      return NextResponse.json({ error: "Name and email are required" }, { status: 400 });
    }

    const cleanEmail = email.trim().toLowerCase();
    const existing = await db.select().from(profiles).where(eq(profiles.email, cleanEmail));
    if (existing.length > 0) {
      return NextResponse.json({ error: "An account with this email already exists." }, { status: 409 });
    }

    const newUserId = `usr_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;

    // Create user profile
    await db.insert(profiles).values({
      id: newUserId,
      email: cleanEmail,
      passwordHash: "hash_" + Math.random().toString(36),
      fullName: fullName.trim(),
      educationLevel: educationLevel || "Student / Self-Taught",
      collegeOrOrg: collegeOrOrg || "King Skill AI Learner",
      targetCareerId: targetCareerId || "full-stack-developer",
      targetCareerName: targetCareerId === "ai-engineer" ? "AI Engineer" : "Full Stack Developer",
      preferredLearningStyle: preferredLearningStyle || "Hands-on Projects",
      certifications: [],
      completedProjects: [],
      learningInterests: ["Web Development", "Software Engineering"],
    });

    // Insert user skills if provided
    if (Array.isArray(initialSkills) && initialSkills.length > 0) {
      for (const s of initialSkills) {
        await db.insert(userSkills).values({
          id: `usk_${newUserId}_${s.name.toLowerCase().replace(/[^a-z0-9]/g, "_")}`,
          userId: newUserId,
          skillId: s.skillId || `sk_${s.name.toLowerCase()}`,
          skillName: s.name,
          proficiencyLevel: s.proficiency || "Beginner",
          score: s.score || 45,
          verified: false,
        });
      }
    } else {
      // Default baseline skill
      await db.insert(userSkills).values({
        id: `usk_${newUserId}_html`,
        userId: newUserId,
        skillId: "sk_html",
        skillName: "HTML",
        proficiencyLevel: "Beginner",
        score: 40,
        verified: false,
      });
    }

    // Initialize progress
    await db.insert(userProgress).values({
      id: `prog_${newUserId}`,
      userId: newUserId,
      careerReadiness: 25,
      totalSkillsAcquired: initialSkills?.length || 1,
      missingSkillsCount: 6,
      roadmapCompletionPct: 0,
      weeklyHours: [
        { day: "Mon", hours: 1.0 },
        { day: "Tue", hours: 2.0 },
        { day: "Wed", hours: 1.5 },
        { day: "Thu", hours: 2.5 },
        { day: "Fri", hours: 1.0 },
        { day: "Sat", hours: 3.0 },
        { day: "Sun", hours: 2.0 },
      ],
      monthlyActivity: [
        { week: "Week 1", tasksCompleted: 1, scoreAvg: 75 },
      ],
    });

    // Run orchestrator to set up initial roadmap
    try {
      await orchestrateFullLearningPipeline(newUserId, targetCareerId || "full-stack-developer");
    } catch (e) {
      console.warn("Orchestrator initial pass during registration error (non-fatal):", e);
    }

    // Set session cookie
    const cookieStore = await cookies();
    cookieStore.set("skillpath_user_id", newUserId, {
      path: "/",
      httpOnly: false,
      maxAge: 60 * 60 * 24 * 30,
    });

    const createdUser = await db.select().from(profiles).where(eq(profiles.id, newUserId));

    return NextResponse.json({ success: true, user: createdUser[0] }, { status: 201 });
  } catch (error: any) {
    console.error("Register error:", error);
    return NextResponse.json({ error: error.message || "Registration failed" }, { status: 500 });
  }
}
