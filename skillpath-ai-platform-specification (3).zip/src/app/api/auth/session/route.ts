import { NextResponse } from "next/server";
import { getCurrentProfile, getCurrentUserId } from "@/lib/auth";
import { db } from "@/db";
import { userSkills, userProgress } from "@/db/schema";
import { eq } from "drizzle-orm";

export async function GET() {
  try {
    const profile = await getCurrentProfile();
    if (!profile) {
      return NextResponse.json({ authenticated: false, user: null }, { status: 401 });
    }

    const skills = await db.select().from(userSkills).where(eq(userSkills.userId, profile.id));
    const progress = await db.select().from(userProgress).where(eq(userProgress.userId, profile.id));

    return NextResponse.json({
      authenticated: true,
      user: {
        id: profile.id,
        email: profile.email,
        fullName: profile.fullName,
        educationLevel: profile.educationLevel,
        collegeOrOrg: profile.collegeOrOrg,
        targetCareerId: profile.targetCareerId,
        targetCareerName: profile.targetCareerName,
        preferredLearningStyle: profile.preferredLearningStyle,
        certifications: profile.certifications,
        completedProjects: profile.completedProjects,
        skills,
        progress: progress[0] || null,
      },
    });
  } catch (error: any) {
    console.error("Auth session error:", error);
    return NextResponse.json({ error: error.message || "Failed to fetch session" }, { status: 500 });
  }
}
