import { NextResponse } from "next/server";
import { getCurrentUserId } from "@/lib/auth";
import { db } from "@/db";
import { roadmapTasks, learningRoadmaps, userProgress } from "@/db/schema";
import { eq } from "drizzle-orm";

export async function PUT(req: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const userId = await getCurrentUserId();
    const { id } = await params;
    const { completed } = await req.json();

    const taskList = await db.select().from(roadmapTasks).where(eq(roadmapTasks.id, id));
    if (taskList.length === 0) {
      return NextResponse.json({ error: "Task not found" }, { status: 404 });
    }

    const task = taskList[0];

    // Update task
    await db
      .update(roadmapTasks)
      .set({
        completed: Boolean(completed),
        completedAt: completed ? new Date() : null,
      })
      .where(eq(roadmapTasks.id, id));

    // Recalculate roadmap completion
    const allTasks = await db.select().from(roadmapTasks).where(eq(roadmapTasks.roadmapId, task.roadmapId));
    const doneCount = allTasks.filter((t) => t.id === id ? Boolean(completed) : t.completed).length;
    const pct = allTasks.length > 0 ? Math.round((doneCount / allTasks.length) * 100) : 0;

    await db
      .update(userProgress)
      .set({
        roadmapCompletionPct: pct,
        lastActiveAt: new Date(),
      })
      .where(eq(userProgress.userId, userId));

    const updatedTask = await db.select().from(roadmapTasks).where(eq(roadmapTasks.id, id));

    return NextResponse.json({
      success: true,
      task: updatedTask[0],
      roadmapCompletionPct: pct,
    });
  } catch (error: any) {
    console.error("PUT /api/roadmap/tasks/[id] error:", error);
    return NextResponse.json({ error: error.message || "Failed to update task" }, { status: 500 });
  }
}
