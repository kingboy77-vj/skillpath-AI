import { NextResponse } from "next/server";
import { getCurrentUserId } from "@/lib/auth";
import { db } from "@/db";
import { learningRoadmaps, roadmapTasks, profiles } from "@/db/schema";
import { eq, asc } from "drizzle-orm";
import { orchestrateFullLearningPipeline } from "@/lib/agents/orchestrator";

export async function GET() {
  try {
    const userId = await getCurrentUserId();
    const user = await db.select().from(profiles).where(eq(profiles.id, userId));
    const targetCareerId = user[0]?.targetCareerId || "full-stack-developer";

    let roadmaps = await db
      .select()
      .from(learningRoadmaps)
      .where(eq(learningRoadmaps.userId, userId));

    if (roadmaps.length === 0) {
      await orchestrateFullLearningPipeline(userId, targetCareerId);
      roadmaps = await db.select().from(learningRoadmaps).where(eq(learningRoadmaps.userId, userId));
    }

    const activeRoadmap = roadmaps[0];
    const tasks = await db
      .select()
      .from(roadmapTasks)
      .where(eq(roadmapTasks.roadmapId, activeRoadmap.id))
      .orderBy(asc(roadmapTasks.orderIndex));

    const totalTasks = tasks.length;
    const completedTasks = tasks.filter((t) => t.completed).length;
    const completionPercentage = totalTasks > 0 ? Math.round((completedTasks / totalTasks) * 100) : 0;

    // Group tasks by phase
    const phasesMap: Record<number, { phaseNumber: number; phaseTitle: string; phaseDescription: string; tasks: typeof tasks }> = {};

    for (const t of tasks) {
      if (!phasesMap[t.phaseNumber]) {
        phasesMap[t.phaseNumber] = {
          phaseNumber: t.phaseNumber,
          phaseTitle: t.phaseTitle,
          phaseDescription: t.phaseDescription || "",
          tasks: [],
        };
      }
      phasesMap[t.phaseNumber].tasks.push(t);
    }

    return NextResponse.json({
      roadmap: activeRoadmap,
      phases: Object.values(phasesMap),
      totalTasks,
      completedTasks,
      completionPercentage,
    });
  } catch (error: any) {
    console.error("GET /api/roadmap error:", error);
    return NextResponse.json({ error: error.message || "Failed to fetch roadmap" }, { status: 500 });
  }
}
