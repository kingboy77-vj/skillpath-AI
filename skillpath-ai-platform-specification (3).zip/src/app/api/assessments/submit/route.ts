import { NextResponse } from "next/server";
import { getCurrentUserId } from "@/lib/auth";
import { db } from "@/db";
import {
  assessments,
  assessmentQuestions,
  assessmentResults,
  userSkills,
  userProgress,
  aiAgentLogs,
} from "@/db/schema";
import { eq, and } from "drizzle-orm";
import { runProgressEvaluationAgent } from "@/lib/agents/progress-evaluation-agent";

export async function POST(req: Request) {
  try {
    const userId = await getCurrentUserId();
    const { assessmentId, answers } = await req.json();

    if (!assessmentId || !Array.isArray(answers)) {
      return NextResponse.json({ error: "assessmentId and answers array are required" }, { status: 400 });
    }

    const asmList = await db.select().from(assessments).where(eq(assessments.id, assessmentId));
    if (asmList.length === 0) {
      return NextResponse.json({ error: "Assessment not found" }, { status: 404 });
    }
    const asm = asmList[0];

    const questions = await db
      .select()
      .from(assessmentQuestions)
      .where(eq(assessmentQuestions.assessmentId, assessmentId));

    let correctCount = 0;
    const gradedBreakdown = questions.map((q, idx) => {
      const userSelected = answers[idx] !== undefined ? answers[idx] : -1;
      const isCorrect = userSelected === q.correctOptionIndex;
      if (isCorrect) correctCount++;

      return {
        questionId: q.id,
        questionText: q.questionText,
        options: q.options,
        userSelected,
        userAnswer: q.options[userSelected] || "No Answer",
        correctOptionIndex: q.correctOptionIndex,
        correctAnswer: q.options[q.correctOptionIndex],
        isCorrect,
        explanation: q.explanation,
        topic: q.topic || "Core Theory",
      };
    });

    const totalQuestions = questions.length;
    const percentage = Math.round((correctCount / totalQuestions) * 100);
    const passed = percentage >= 60;

    // Call Progress Evaluation Agent
    const evaluationStart = Date.now();
    const evaluation = await runProgressEvaluationAgent({
      assessmentTitle: asm.title,
      skillName: asm.skillName,
      score: correctCount,
      totalQuestions,
      percentage,
      questionDetails: gradedBreakdown.map((b) => ({
        questionText: b.questionText,
        topic: b.topic,
        isCorrect: b.isCorrect,
        userAnswer: b.userAnswer,
        correctAnswer: b.correctAnswer,
      })),
    });

    // Save AI Agent Log
    await db.insert(aiAgentLogs).values({
      id: `log_pe_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      userId,
      agentName: "Progress Evaluation Agent",
      agentRole: "Evaluate quiz assessment, diagnose deficiencies, update proficiency",
      inputPayload: { assessmentTitle: asm.title, score: correctCount, percentage },
      outputPayload: evaluation as any,
      durationMs: Date.now() - evaluationStart,
    });

    // Save assessment result
    const resultId = `res_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;
    await db.insert(assessmentResults).values({
      id: resultId,
      userId,
      assessmentId,
      assessmentTitle: asm.title,
      score: correctCount,
      totalQuestions,
      percentage,
      passed,
      answers,
      agentFeedback: {
        summary: evaluation.summary,
        strengths: evaluation.strengths,
        topicsToReview: evaluation.topicsToReview,
        recommendedAction: evaluation.recommendedAction,
        newProficiencyLevel: evaluation.proficiencyAdjustment.newLevel,
      },
    });

    // Update user skill proficiency if passed or adjust score
    const existingSkill = await db
      .select()
      .from(userSkills)
      .where(and(eq(userSkills.userId, userId), eq(userSkills.skillName, asm.skillName)));

    if (existingSkill.length > 0) {
      const current = existingSkill[0];
      const newScore = Math.min(Math.max(current.score + evaluation.proficiencyAdjustment.scoreDelta, 20), 100);
      await db
        .update(userSkills)
        .set({
          score: newScore,
          proficiencyLevel: evaluation.proficiencyAdjustment.newLevel,
          verified: passed ? true : current.verified,
        })
        .where(eq(userSkills.id, current.id));
    } else if (passed) {
      await db.insert(userSkills).values({
        id: `usk_${userId}_${asm.skillName.toLowerCase()}`,
        userId,
        skillId: asm.skillId || `sk_${asm.skillName.toLowerCase()}`,
        skillName: asm.skillName,
        proficiencyLevel: evaluation.proficiencyAdjustment.newLevel,
        score: Math.min(percentage, 85),
        verified: true,
      });
    }

    // Refresh user_progress
    const currentProgress = await db.select().from(userProgress).where(eq(userProgress.userId, userId));
    const uSkills = await db.select().from(userSkills).where(eq(userSkills.userId, userId));

    if (currentProgress.length > 0) {
      const bonusReadiness = passed ? 5 : 0;
      await db
        .update(userProgress)
        .set({
          careerReadiness: Math.min(currentProgress[0].careerReadiness + bonusReadiness, 100),
          totalSkillsAcquired: uSkills.length,
          lastActiveAt: new Date(),
        })
        .where(eq(userProgress.userId, userId));
    }

    return NextResponse.json({
      success: true,
      score: correctCount,
      totalQuestions,
      percentage,
      passed,
      evaluation,
      breakdown: gradedBreakdown,
    });
  } catch (error: any) {
    console.error("Assessment submit error:", error);
    return NextResponse.json({ error: error.message || "Failed to submit assessment" }, { status: 500 });
  }
}
