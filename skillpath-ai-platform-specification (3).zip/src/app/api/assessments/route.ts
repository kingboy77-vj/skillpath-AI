import { NextResponse } from "next/server";
import { getCurrentUserId } from "@/lib/auth";
import { db } from "@/db";
import { assessments, assessmentResults } from "@/db/schema";
import { eq, desc } from "drizzle-orm";

export async function GET() {
  try {
    const userId = await getCurrentUserId();
    const list = await db.select().from(assessments);
    const results = await db
      .select()
      .from(assessmentResults)
      .where(eq(assessmentResults.userId, userId))
      .orderBy(desc(assessmentResults.createdAt));

    const assessmentsWithStatus = list.map((a) => {
      const userRes = results.find((r) => r.assessmentId === a.id);
      return {
        ...a,
        completed: Boolean(userRes),
        lastScore: userRes?.percentage ?? null,
        passed: userRes?.passed ?? false,
      };
    });

    return NextResponse.json({
      assessments: assessmentsWithStatus,
      recentResults: results.slice(0, 5),
    });
  } catch (error: any) {
    console.error("GET /api/assessments error:", error);
    return NextResponse.json({ error: error.message || "Failed to fetch assessments" }, { status: 500 });
  }
}
