import { NextResponse } from "next/server";
import { db } from "@/db";
import { assessments, assessmentQuestions } from "@/db/schema";
import { eq } from "drizzle-orm";

export async function GET(req: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params;
    const asmList = await db.select().from(assessments).where(eq(assessments.id, id));

    if (asmList.length === 0) {
      return NextResponse.json({ error: "Assessment not found" }, { status: 404 });
    }

    const asm = asmList[0];
    const questions = await db
      .select({
        id: assessmentQuestions.id,
        questionText: assessmentQuestions.questionText,
        options: assessmentQuestions.options,
        topic: assessmentQuestions.topic,
        difficulty: assessmentQuestions.difficulty,
        // Do not leak correctOptionIndex or explanation before submission
      })
      .from(assessmentQuestions)
      .where(eq(assessmentQuestions.assessmentId, id));

    return NextResponse.json({
      assessment: asm,
      questions,
    });
  } catch (error: any) {
    console.error("GET /api/assessments/[id] error:", error);
    return NextResponse.json({ error: error.message || "Failed to load assessment" }, { status: 500 });
  }
}
