import { NextResponse } from "next/server";
import { getCurrentUserId } from "@/lib/auth";
import { db } from "@/db";
import { careers, careerRequirements, userSkills, profiles } from "@/db/schema";
import { eq } from "drizzle-orm";

export async function GET() {
  try {
    const userId = await getCurrentUserId();
    const allCareers = await db.select().from(careers);
    const allReqs = await db.select().from(careerRequirements);
    const uSkills = await db.select().from(userSkills).where(eq(userSkills.userId, userId));
    const user = await db.select().from(profiles).where(eq(profiles.id, userId));

    const userSkillNames = new Set(uSkills.map((s) => s.skillName.toLowerCase()));

    const careerSummaries = allCareers.map((c) => {
      const cReqs = allReqs.filter((r) => r.careerId === c.id);
      let matchedCount = 0;
      const missingSkills: string[] = [];
      const acquiredSkills: string[] = [];

      for (const req of cReqs) {
        if (userSkillNames.has(req.skillName.toLowerCase())) {
          matchedCount++;
          acquiredSkills.push(req.skillName);
        } else {
          missingSkills.push(req.skillName);
        }
      }

      const totalReq = Math.max(cReqs.length, 1);
      const readiness = Math.round((matchedCount / totalReq) * 100);

      return {
        ...c,
        requirements: cReqs,
        readinessScore: readiness,
        missingSkills,
        acquiredSkills,
        isTarget: user[0]?.targetCareerId === c.id,
      };
    });

    return NextResponse.json({
      careers: careerSummaries,
      currentTargetCareerId: user[0]?.targetCareerId || "full-stack-developer",
    });
  } catch (error: any) {
    console.error("GET /api/careers error:", error);
    return NextResponse.json({ error: error.message || "Failed to fetch careers" }, { status: 500 });
  }
}
