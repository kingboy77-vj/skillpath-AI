import { NextResponse } from "next/server";
import { getCurrentUserId } from "@/lib/auth";
import { orchestrateFullLearningPipeline } from "@/lib/agents/orchestrator";

export async function POST(req: Request) {
  try {
    const userId = await getCurrentUserId();
    const { careerId } = await req.json();

    if (!careerId) {
      return NextResponse.json({ error: "careerId is required" }, { status: 400 });
    }

    const orchestrationResult = await orchestrateFullLearningPipeline(userId, careerId);

    return NextResponse.json({
      success: true,
      message: `Selected career and re-orchestrated AI learning path.`,
      orchestration: orchestrationResult,
    });
  } catch (error: any) {
    console.error("Select career error:", error);
    return NextResponse.json({ error: error.message || "Failed to select career" }, { status: 500 });
  }
}
