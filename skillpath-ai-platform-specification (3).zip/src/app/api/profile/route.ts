import { NextResponse } from "next/server";
import { getCurrentUserId } from "@/lib/auth";
import { db } from "@/db";
import { profiles, userSkills, skills, userProgress } from "@/db/schema";
import { eq } from "drizzle-orm";
import { orchestrateFullLearningPipeline } from "@/lib/agents/orchestrator";

export async function GET() {
  try {
    const userId = await getCurrentUserId();
    const userList = await db.select().from(profiles).where(eq(profiles.id, userId));

    if (userList.length === 0) {
      return NextResponse.json({ error: "Profile not found" }, { status: 404 });
    }

    const user = userList[0];
    const uSkills = await db.select().from(userSkills).where(eq(userSkills.userId, userId));
    const allSkills = await db.select().from(skills);
    const progress = await db.select().from(userProgress).where(eq(userProgress.userId, userId));

    return NextResponse.json({
      profile: user,
      userSkills: uSkills,
      availableSkills: allSkills,
      progress: progress[0] || null,
    });
  } catch (error: any) {
    console.error("GET /api/profile error:", error);
    return NextResponse.json({ error: error.message || "Failed to load profile" }, { status: 500 });
  }
}

export async function PUT(req: Request) {
  try {
    const userId = await getCurrentUserId();
    const body = await req.json();

    const {
      fullName,
      educationLevel,
      collegeOrOrg,
      certifications,
      completedProjects,
      workExperience,
      learningInterests,
      targetCareerId,
      targetCareerName,
      preferredLearningStyle,
      avatarUrl,
      updatedSkills, // [{ skillId, skillName, proficiencyLevel, score }]
    } = body;

    const updateData: Partial<typeof profiles.$inferInsert> = {
      updatedAt: new Date(),
    };

    if (fullName !== undefined) updateData.fullName = fullName;
    if (educationLevel !== undefined) updateData.educationLevel = educationLevel;
    if (collegeOrOrg !== undefined) updateData.collegeOrOrg = collegeOrOrg;
    if (certifications !== undefined) updateData.certifications = certifications;
    if (completedProjects !== undefined) updateData.completedProjects = completedProjects;
    if (workExperience !== undefined) updateData.workExperience = workExperience;
    if (learningInterests !== undefined) updateData.learningInterests = learningInterests;
    if (targetCareerId !== undefined) updateData.targetCareerId = targetCareerId;
    if (targetCareerName !== undefined) updateData.targetCareerName = targetCareerName;
    if (preferredLearningStyle !== undefined) updateData.preferredLearningStyle = preferredLearningStyle;
    if (avatarUrl !== undefined) updateData.avatarUrl = avatarUrl;

    await db.update(profiles).set(updateData).where(eq(profiles.id, userId));

    // Update skills if provided
    if (Array.isArray(updatedSkills)) {
      // Delete existing and re-insert
      await db.delete(userSkills).where(eq(userSkills.userId, userId));
      for (const s of updatedSkills) {
        const sid = s.skillId || `sk_${s.skillName.toLowerCase().replace(/[^a-z0-9]/g, "_")}`;
        await db.insert(userSkills).values({
          id: `usk_${userId}_${Math.random().toString(36).substring(2, 7)}`,
          userId,
          skillId: sid,
          skillName: s.skillName,
          proficiencyLevel: s.proficiencyLevel || "Beginner",
          score: s.score || 50,
          verified: !!s.verified,
        });
      }
    }

    // Trigger AI orchestration pipeline to update roadmap and recommendations according to profile changes
    try {
      await orchestrateFullLearningPipeline(userId, targetCareerId);
    } catch (orchErr) {
      console.warn("Orchestration pipeline update error (handled):", orchErr);
    }

    const updatedUser = await db.select().from(profiles).where(eq(profiles.id, userId));
    const refreshedSkills = await db.select().from(userSkills).where(eq(userSkills.userId, userId));

    return NextResponse.json({
      success: true,
      message: "Profile updated and AI roadmap recalibrated successfully",
      profile: updatedUser[0],
      userSkills: refreshedSkills,
    });
  } catch (error: any) {
    console.error("PUT /api/profile error:", error);
    return NextResponse.json({ error: error.message || "Failed to update profile" }, { status: 500 });
  }
}
