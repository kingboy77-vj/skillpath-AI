import { db } from "@/db";
import { sql } from "drizzle-orm";
import { seedDatabase } from "@/db/seed";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    await db.execute(sql`select 1`);
    // Ensure database seed data is present
    await seedDatabase().catch((err) => console.warn("Seed during health check:", err));
    return Response.json({ ok: true, app: "King Skill AI" });
  } catch {
    return Response.json({ ok: false }, { status: 500 });
  }
}
